import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PUBLIC_CARDS_DIR = path.join(__dirname, 'public', 'cards');
const ROOT_CARDS_DIR = path.join(__dirname, 'cards');

function ensureDirs() {
  if (!fs.existsSync(PUBLIC_CARDS_DIR)) {
    fs.mkdirSync(PUBLIC_CARDS_DIR, { recursive: true });
  }
  if (!fs.existsSync(ROOT_CARDS_DIR)) {
    fs.mkdirSync(ROOT_CARDS_DIR, { recursive: true });
  }
}

function getExistingCardFiles(): string[] {
  ensureDirs();
  const set = new Set<string>();
  for (const dir of [PUBLIC_CARDS_DIR, ROOT_CARDS_DIR]) {
    try {
      const files = fs.readdirSync(dir);
      for (const f of files) {
        if (/\.(png|jpe?g|webp)$/i.test(f)) {
          set.add(f);
        }
      }
    } catch {
      // ignore
    }
  }
  return Array.from(set).sort();
}

async function startServer() {
  ensureDirs();

  // If root /cards has files that /public/cards doesn't have, copy them over
  try {
    const rootFiles = fs.readdirSync(ROOT_CARDS_DIR);
    for (const f of rootFiles) {
      if (/\.(png|jpe?g|webp)$/i.test(f)) {
        const src = path.join(ROOT_CARDS_DIR, f);
        const dest = path.join(PUBLIC_CARDS_DIR, f);
        if (!fs.existsSync(dest)) {
          fs.copyFileSync(src, dest);
        }
      }
    }
  } catch {
    // ignore
  }

  const app = express();
  app.use(express.json({ limit: '50mb' }));

  // Check status of /public/cards on server disk
  app.get('/api/cards-status', (_req, res) => {
    const files = getExistingCardFiles();
    res.json({
      count: files.length,
      files,
    });
  });

  // Save uploaded PNG card directly into /public/cards/<filename>
  app.post('/api/save-card', (req, res) => {
    try {
      const { filename, dataUrl } = req.body as { filename?: string; dataUrl?: string };
      if (!filename || !dataUrl) {
        res.status(400).json({ error: 'Missing filename or dataUrl' });
        return;
      }
      const safeName = path.basename(filename);
      if (!/\.(png|jpe?g|webp)$/i.test(safeName)) {
        res.status(400).json({ error: 'Invalid image extension' });
        return;
      }

      const base64Match = dataUrl.match(/^data:image\/[a-zA-Z0-9.+-]+;base64,(.+)$/);
      const rawBase64 = base64Match ? base64Match[1] : dataUrl;
      const buffer = Buffer.from(rawBase64, 'base64');

      ensureDirs();
      const targetPublic = path.join(PUBLIC_CARDS_DIR, safeName);
      fs.writeFileSync(targetPublic, buffer);

      res.json({ ok: true, filename: safeName, size: buffer.length });
    } catch (err) {
      res.status(500).json({ error: String(err) });
    }
  });

  // Serve card PNGs from /public/cards or /cards, returning 404 (not SPA HTML) when missing
  const serveCardImage = (req: express.Request, res: express.Response) => {
    const safeName = path.basename(req.params.filename || '');
    const candidates = [
      path.join(PUBLIC_CARDS_DIR, safeName),
      path.join(ROOT_CARDS_DIR, safeName),
    ];
    for (const filePath of candidates) {
      if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        res.setHeader('Content-Type', 'image/png');
        res.setHeader('Cache-Control', 'public, max-age=300');
        res.sendFile(filePath);
        return;
      }
    }
    res.status(404).end('Card PNG not found on server');
  };

  app.get('/cards/:filename', serveCardImage);
  app.get('/public/cards/:filename', serveCardImage);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Optimum TurboCards 3D server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
