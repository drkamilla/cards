import React, { useEffect, useRef, useState } from 'react';
import { ValidatorCard, getCardRarity } from '../data/cardsData';
import { renderCardFrontToCanvas } from '../utils/proceduralTextures';
import { cardImageStore } from '../utils/cardImageStore';
import { LanguageCode, TRANSLATIONS } from '../utils/i18n';
import {
  X,
  Search,
  Filter,
  Zap,
  Activity,
  TrendingUp,
  Award,
  CheckCircle2,
  Trophy,
  PackageOpen,
} from 'lucide-react';

export interface PlayerStats {
  packsOpened: number;
  matchesWon: number;
  matchesLost: number;
  winStreak: number;
  mevRating: number;
}

interface CardCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  cards: ValidatorCard[];
  discoveredIds: number[];
  playerStats: PlayerStats;
  initialSelectedCard?: ValidatorCard | null;
  customPngCount: number;
  lang: LanguageCode;
}

export const CardCanvasPreview: React.FC<{
  card: ValidatorCard;
  className?: string;
  version?: number;
}> = ({ card, className = 'w-full h-auto rounded-lg', version = 0 }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [resolvedUrl, setResolvedUrl] = useState<string | undefined>(() =>
    cardImageStore.getResolvedUrl(card.image)
  );

  useEffect(() => {
    const draw = (img?: HTMLImageElement) => {
      const cv = canvasRef.current;
      if (cv) {
        renderCardFrontToCanvas(card, cv, img);
      }
      const url = cardImageStore.getResolvedUrl(card.image);
      if (url) {
        setResolvedUrl(url);
      }
    };

    draw(cardImageStore.getLoadedImage(card.image));

    cardImageStore.probeServerImage(card.image, (loadedImg) => {
      draw(loadedImg);
    });

    const unsub = cardImageStore.subscribe(() => {
      const loaded = cardImageStore.getLoadedImage(card.image);
      if (loaded) {
        draw(loaded);
      }
    });

    return () => {
      unsub();
    };
  }, [card, version]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <canvas ref={canvasRef} className="w-full h-auto block" />
      {resolvedUrl && (
        <img
          src={resolvedUrl}
          alt={card.name}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
          onError={() => setResolvedUrl(undefined)}
        />
      )}
    </div>
  );
};

export const CardCatalogModal: React.FC<CardCatalogModalProps> = ({
  isOpen,
  onClose,
  cards,
  discoveredIds,
  playerStats,
  initialSelectedCard = null,
  customPngCount,
  lang,
}) => {
  const t = TRANSLATIONS[lang];
  const [search, setSearch] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('ALL');
  const [onlyDiscovered, setOnlyDiscovered] = useState<boolean>(false);
  const [activeCard, setActiveCard] = useState<ValidatorCard | null>(
    initialSelectedCard || cards[0] || null
  );
  const [cardTilt, setCardTilt] = useState<{ rx: number; ry: number }>({ rx: 0, ry: 0 });

  useEffect(() => {
    if (initialSelectedCard) {
      setActiveCard(initialSelectedCard);
    } else if (!activeCard && cards.length > 0) {
      setActiveCard(cards[0]);
    }
  }, [initialSelectedCard, cards, activeCard]);

  if (!isOpen) return null;

  const filteredCards = cards.filter((c) => {
    if (onlyDiscovered && !discoveredIds.includes(c.id)) return false;
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      String(c.slot).includes(search) ||
      c.image.toLowerCase().includes(search.toLowerCase());
    if (!matchesSearch) return false;
    if (tierFilter === 'ALL') return true;
    return getCardRarity(c.power).tier === tierFilter;
  });

  const collectionPct = Math.round((discoveredIds.length / Math.max(1, cards.length)) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 sm:p-6">
      <div className="relative flex flex-col w-full max-w-6xl h-[90dvh] bg-[#090a10] border border-white/25 rounded-2xl overflow-hidden shadow-2xl">
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3.5 border-b border-white/15 panel-silver-chrome">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="text-base sm:text-lg font-black tracking-wider text-white uppercase">
              {t.catalogHeader(cards.length)}
            </h2>
            <div className="flex items-center gap-2.5 text-xs text-slate-300">
              <span>{t.discoveredStat(discoveredIds.length, cards.length, collectionPct)}</span>
              <span aria-hidden="true">•</span>
              <span className="text-white">{t.ratingStat(playerStats.mevRating)}</span>
              <span aria-hidden="true">•</span>
              <span className="text-slate-200">{t.winsStat(playerStats.matchesWon)}</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/15 border border-white/20 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Content Split */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          {/* Left Inspector Panel */}
          <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-white/15 p-4 sm:p-6 flex flex-col items-center justify-between bg-[#07080d] overflow-y-auto">
            {activeCard ? (
              <div className="w-full max-w-[250px] flex flex-col items-center gap-3.5">
                <div
                  onMouseMove={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const nx = (e.clientX - rect.left) / rect.width - 0.5;
                    const ny = (e.clientY - rect.top) / rect.height - 0.5;
                    setCardTilt({ rx: -ny * 14, ry: nx * 14 });
                  }}
                  onMouseLeave={() => setCardTilt({ rx: 0, ry: 0 })}
                  style={{
                    transform: `perspective(700px) rotateX(${cardTilt.rx}deg) rotateY(${cardTilt.ry}deg)`,
                    transition: 'transform 140ms ease-out',
                  }}
                  className="w-full rounded-xl overflow-hidden border border-white/30 shadow-2xl cursor-grab"
                >
                  <CardCanvasPreview card={activeCard} version={customPngCount} />
                </div>

                <div className="w-full flex items-center justify-between text-xs pt-1">
                  <span className="text-slate-400">{t.cardFileLabel}</span>
                  <span className="text-slate-200 truncate max-w-[165px]">
                    ./{activeCard.image.replace(/^\.?\//, '')}
                  </span>
                </div>

                <div className="w-full space-y-2 text-xs text-slate-300 pt-2 border-t border-white/15">
                  <div className="flex justify-between">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5 text-slate-200" /> {t.statSlotPower}
                    </span>
                    <span className="font-black text-white">★ {activeCard.power} / 10</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Activity className="w-3.5 h-3.5 text-slate-200" /> {t.statLatency}
                    </span>
                    <span className="font-black text-white">{activeCard.latency} ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-slate-200" /> {t.statSpeedBoost}
                    </span>
                    <span className="font-black text-white">{activeCard.speedBoost}x</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <TrendingUp className="w-3.5 h-3.5 text-slate-200" /> {t.statBidUplift}
                    </span>
                    <span className="font-black text-white">+{activeCard.bidUplift}%</span>
                  </div>
                </div>
              </div>
            ) : null}

            {/* Player Career Stats */}
            <div className="w-full mt-5 pt-4 border-t border-white/15 space-y-3">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-lg card-slot-silver">
                  <div className="text-slate-300 flex items-center gap-1">
                    <PackageOpen className="w-3.5 h-3.5 text-white" /> {t.packsOpenedLabel}
                  </div>
                  <div className="text-base font-black text-white mt-0.5">
                    {playerStats.packsOpened}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg card-slot-silver">
                  <div className="text-slate-300 flex items-center gap-1">
                    <Trophy className="w-3.5 h-3.5 text-white" /> {t.winsCount}
                  </div>
                  <div className="text-base font-black text-white mt-0.5">
                    {t.winStreakLabel(playerStats.winStreak)}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Filter & Visual Card Gallery Grid */}
          <div className="lg:col-span-8 flex flex-col h-full overflow-hidden">
            {/* Filter Controls */}
            <div className="p-3.5 sm:p-4 border-b border-white/15 flex flex-wrap items-center justify-between gap-2.5 bg-[#0b0d14]">
              <div className="relative flex-1 min-w-[160px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  className="w-full bg-[#121520] border border-white/25 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-white"
                />
              </div>

              <button
                onClick={() => setOnlyDiscovered((prev) => !prev)}
                className={`px-3.5 py-2 rounded-xl text-xs uppercase transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  onlyDiscovered
                    ? 'btn-liquid-silver'
                    : 'card-slot-silver text-slate-200 hover:text-white'
                }`}
              >
                {t.filterDiscoveredBtn(discoveredIds.length)}
              </button>

              <div className="flex items-center gap-1 bg-[#121520] p-1 rounded-xl border border-white/20 overflow-x-auto">
                <Filter className="w-3.5 h-3.5 text-slate-300 ml-2 mr-1 shrink-0" />
                {(['ALL', 'MYTHIC', 'EPIC', 'RARE', 'COMMON'] as const).map((tier) => (
                  <button
                    key={tier}
                    onClick={() => setTierFilter(tier)}
                    className={`px-2.5 py-1 text-xs rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 uppercase ${
                      tierFilter === tier
                        ? 'btn-liquid-silver'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {tier === 'ALL' ? t.filterAllBtn(cards.length) : tier}
                  </button>
                ))}
              </div>
            </div>

            {/* Visual Cards Grid */}
            <div className="flex-1 overflow-y-auto p-3.5 sm:p-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 content-start">
              {filteredCards.length === 0 ? (
                <div className="col-span-full py-16 text-center text-sm text-slate-300">
                  {t.noCardsFoundMsg}
                </div>
              ) : (
                filteredCards.map((c) => {
                  const isSelected = activeCard?.id === c.id;
                  const isDiscovered = discoveredIds.includes(c.id);
                  return (
                    <button
                      key={c.id}
                      onClick={() => setActiveCard(c)}
                      className={`group text-left p-2.5 rounded-xl transition-all cursor-pointer flex flex-col gap-2 ${
                        isSelected
                          ? 'card-slot-silver-active scale-[1.02]'
                          : 'card-slot-silver hover:border-white/50'
                      }`}
                    >
                      <div className="w-full rounded-lg overflow-hidden border border-white/15 bg-[#06070c]">
                        <CardCanvasPreview
                          card={c}
                          version={customPngCount}
                          className="w-full h-auto"
                        />
                      </div>

                      <div className="flex items-center justify-between gap-1 px-0.5">
                        <span className="font-black text-xs text-white truncate flex items-center gap-1">
                          {c.name}
                          {isDiscovered && (
                            <CheckCircle2 className="w-3 h-3 text-slate-200 shrink-0" />
                          )}
                        </span>
                        <span className="text-xs font-black text-white shrink-0">
                          ★ {c.power}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-300 px-0.5">
                        <span>{c.latency}ms</span>
                        <span>{c.speedBoost}x</span>
                        <span>+{c.bidUplift}%</span>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
