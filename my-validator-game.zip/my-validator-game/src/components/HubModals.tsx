import React, { useEffect, useRef, useState } from 'react';
import { ValidatorCard } from '../data/cardsData';
import {
  UserProfile,
  LeaderboardEntry,
  formatRatingRP,
  generateBattleSharePosterDataUrl,
  generateBattleSharePosterAsync,
} from '../utils/accountStore';
import {
  LanguageCode,
  TRANSLATIONS,
  getRankTitle,
} from '../utils/i18n';
import { CardCanvasPreview } from './CardCatalogModal';
import {
  Sparkles,
  Trophy,
  Share2,
  Home,
  CheckCircle2,
  Eye,
  Download,
  Lock,
  User,
  Layers,
  Swords,
  KeyRound,
  LockOpen,
  Bot,
  Loader2,
  Copy,
  Check,
  ChevronLeft,
  ChevronRight,
  X,
} from 'lucide-react';

interface LoginScreenModalProps {
  lang: LanguageCode;
  onChangeLang: (lang: LanguageCode) => void;
  onLoginSuccess: (nickname: string, password: string) => Promise<{ error?: string }>;
}

export const LoginScreenModal: React.FC<LoginScreenModalProps> = ({
  lang,
  onChangeLang,
  onLoginSuccess,
}) => {
  const t = TRANSLATIONS[lang];
  const [nickname, setNickname] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setError(null);
    if (!nickname.trim()) {
      setError(t.errEnterNickname);
      return;
    }
    if (!password.trim()) {
      setError(t.errEnterPassword);
      return;
    }
    setLoading(true);
    try {
      const res = await onLoginSuccess(nickname, password);
      if (res.error) {
        setError(t.errWrongPassword);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl">
      <div className="w-full max-w-md panel-silver-chrome rounded-3xl p-6 sm:p-8 flex flex-col items-center gap-5 border border-white/30">
        {/* Top Row: Brand & Language Selector */}
        <div className="w-full flex items-center justify-between gap-2">
          <span className="text-sm font-black tracking-[1.5px] text-white uppercase">
            {t.brandLogo}
          </span>
          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/25">
            {(['RU', 'EN', 'KO', 'VI'] as LanguageCode[]).map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => onChangeLang(code)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-black uppercase transition-all cursor-pointer ${
                  lang === code
                    ? 'btn-liquid-silver'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {code}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center text-center gap-2">
          <div className="px-3.5 py-1 rounded-full card-slot-silver text-[11px] font-black tracking-[2px] text-slate-200 uppercase">
            {t.loginBadge}
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-[1.5px] text-white uppercase mt-1">
            {t.loginTitle}
          </h1>
          <p className="text-xs text-slate-300 max-w-xs leading-relaxed">
            {t.loginSubtitle}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-black tracking-[1.2px] text-slate-200 uppercase flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-white" />
              <span>{t.nicknameLabel}</span>
            </label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder={t.nicknamePlaceholder}
              maxLength={24}
              autoFocus
              disabled={loading}
              className="w-full px-4 py-3 rounded-xl card-slot-silver text-white placeholder-slate-400 text-sm focus:outline-none focus:border-white/70 transition-colors"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-black tracking-[1.2px] text-slate-200 uppercase flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-white" />
              <span>{t.passwordLabel}</span>
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t.passwordPlaceholder}
              maxLength={32}
              disabled={loading}
              className="w-full px-4 py-3 rounded-xl card-slot-silver text-white placeholder-slate-400 text-sm focus:outline-none focus:border-white/70 transition-colors"
            />
          </div>

          {error && (
            <div className="px-3.5 py-2 rounded-xl bg-white/10 border border-white/40 text-xs text-white text-center font-black uppercase tracking-wider">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="btn-liquid-silver w-full py-3.5 rounded-xl text-sm uppercase cursor-pointer mt-1 disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{loading ? t.loginLoadingBtn : t.loginSubmitBtn}</span>
          </button>
        </form>
      </div>
    </div>
  );
};

interface RulesFormulaModalProps {
  isOpen: boolean;
  lang: LanguageCode;
  onClose: () => void;
}

export const RulesFormulaModal: React.FC<RulesFormulaModalProps> = ({
  isOpen,
  lang,
  onClose,
}) => {
  const t = TRANSLATIONS[lang];
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xl"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl panel-silver-chrome rounded-3xl p-5 sm:p-7 flex flex-col gap-4 border border-white/40 max-h-[92dvh] overflow-y-auto"
        style={{
          boxShadow:
            '0 24px 64px rgba(0, 0, 0, 0.95), 0 0 38px rgba(255, 255, 255, 0.16), inset 0 1px 2px rgba(255, 255, 255, 0.45)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-white/20 pb-3">
          <h2 className="text-base sm:text-xl font-black tracking-[1.4px] text-white uppercase">
            {t.rulesModalTitle}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="card-slot-silver-active hover:border-white p-2 rounded-xl text-white cursor-pointer shrink-0"
            aria-label="Close"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Section 1: Match Format (3 Rounds) */}
        <div className="card-slot-silver rounded-2xl p-4 flex flex-col gap-2">
          <h3 className="text-xs sm:text-sm font-black tracking-[1.2px] text-white uppercase">
            {t.rulesSec1Title}
          </h3>
          <ul className="flex flex-col gap-1.5 text-xs sm:text-sm text-slate-200 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="text-white font-black">•</span>
              <span>{t.rulesSec1Bullet1}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-white font-black">•</span>
              <span>{t.rulesSec1Bullet2}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-white font-black">•</span>
              <span>{t.rulesSec1Bullet3}</span>
            </li>
          </ul>
        </div>

        {/* Section 2: Card Power Formula */}
        <div className="card-slot-silver-active rounded-2xl p-4 flex flex-col gap-2.5">
          <h3 className="text-xs sm:text-sm font-black tracking-[1.2px] text-white uppercase">
            {t.rulesSec2Title}
          </h3>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
            {t.rulesSec2Intro}
          </p>
          <div className="w-full px-3.5 py-3 rounded-xl bg-black/75 border border-white/40 text-center font-black text-xs sm:text-sm text-white tracking-wide shadow-inner">
            {t.rulesSec2Formula}
          </div>
          <ul className="flex flex-col gap-1.5 text-xs sm:text-sm text-slate-200 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="text-white font-black">•</span>
              <span>{t.rulesSec2Bullet1}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-white font-black">•</span>
              <span>{t.rulesSec2Bullet2}</span>
            </li>
          </ul>
        </div>

        {/* Section 3: Tie-Breaker Rules */}
        <div className="card-slot-silver rounded-2xl p-4 flex flex-col gap-2">
          <h3 className="text-xs sm:text-sm font-black tracking-[1.2px] text-white uppercase">
            {t.rulesSec3Title}
          </h3>
          <ul className="flex flex-col gap-1.5 text-xs sm:text-sm text-slate-200 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="text-white font-black">•</span>
              <span>{t.rulesSec3Bullet1}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-white font-black">•</span>
              <span>{t.rulesSec3Bullet2}</span>
            </li>
          </ul>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="btn-liquid-silver w-full py-3 rounded-xl text-xs sm:text-sm uppercase cursor-pointer mt-1"
        >
          {t.rulesCloseBtn}
        </button>
      </div>
    </div>
  );
};

export type MatchmakingSubState =
  | 'MENU'
  | 'QUICK_SEARCHING'
  | 'AI_FALLBACK_NOTICE'
  | 'LOBBY_WAITING'
  | 'ENTER_CODE_FORM';

interface BattleModeSelectViewProps {
  lang: LanguageCode;
  subState: MatchmakingSubState;
  quickSearchSecondsLeft: number;
  createdRoomCode: string | null;
  codeError: string | null;
  isBusy: boolean;
  onStartQuickMatch: () => void;
  onCreateLobby: () => void;
  onOpenEnterCode: () => void;
  onSubmitJoinCode: (code: string) => void;
  onStartAiTraining: () => void;
  onCancelMatchmaking: () => void;
  onOpenRules: () => void;
}

export const BattleModeSelectView: React.FC<BattleModeSelectViewProps> = ({
  lang,
  subState,
  quickSearchSecondsLeft,
  createdRoomCode,
  codeError,
  isBusy,
  onStartQuickMatch,
  onCreateLobby,
  onOpenEnterCode,
  onSubmitJoinCode,
  onStartAiTraining,
  onCancelMatchmaking,
  onOpenRules,
}) => {
  const t = TRANSLATIONS[lang];
  const [inputCode, setInputCode] = useState('');
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    if (!createdRoomCode) return;
    navigator.clipboard?.writeText(createdRoomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="fixed inset-x-0 top-20 bottom-20 z-20 mx-auto w-[94vw] max-w-[620px] flex items-center justify-center pointer-events-auto">
      <div className="w-full panel-silver-chrome rounded-3xl p-5 sm:p-7 flex flex-col items-center gap-5 border border-white/35 max-h-full overflow-y-auto">
        <div className="w-full flex flex-col items-center text-center gap-1.5">
          <div className="w-full flex items-center justify-between gap-2">
            <div className="px-3 py-1 rounded-full card-slot-silver text-[10px] sm:text-[11px] font-black tracking-[2px] text-slate-200 uppercase">
              {t.arenaMenuBadge}
            </div>
            <button
              type="button"
              onClick={onOpenRules}
              className="card-slot-silver-active hover:border-white px-3 py-1.5 rounded-xl text-[11px] sm:text-xs font-black text-white uppercase cursor-pointer transition-all"
            >
              {t.rulesBtnLabel}
            </button>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-[1.5px] text-white uppercase mt-1">
            {t.arenaMenuTitle}
          </h2>
          <p className="text-xs text-slate-300 max-w-md leading-relaxed">
            {t.arenaMenuSubtitle}
          </p>
        </div>

        {/* STATE 1: MAIN 3-OPTION BATTLE MENU */}
        {subState === 'MENU' && (
          <div className="w-full flex flex-col gap-3.5">
            {/* Option 1: Quick Search (PvP) with 50s AI fallback */}
            <button
              type="button"
              disabled={isBusy}
              onClick={onStartQuickMatch}
              className="btn-liquid-silver w-full py-4 px-5 rounded-2xl flex items-center justify-between gap-3 cursor-pointer disabled:opacity-60"
            >
              <div className="flex items-center gap-3 text-left">
                <Swords className="w-5 h-5 shrink-0" />
                <div className="flex flex-col">
                  <span className="text-sm sm:text-base uppercase tracking-wider">
                    {t.quickMatchBtn}
                  </span>
                  <span className="text-[11px] opacity-80 font-bold tracking-normal">
                    {t.quickMatchDesc}
                  </span>
                </div>
              </div>
              <span className="text-xs uppercase shrink-0">→</span>
            </button>

            {/* Option 2: Create Lobby / Enter Code */}
            <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                disabled={isBusy}
                onClick={onCreateLobby}
                className="card-slot-silver-active hover:border-white py-3.5 px-4 rounded-2xl flex items-center justify-center gap-2.5 text-white text-xs sm:text-sm font-black uppercase tracking-wider cursor-pointer transition-all disabled:opacity-60"
              >
                <KeyRound className="w-4 h-4 text-white shrink-0" />
                <span>{t.createLobbyBtn}</span>
              </button>

              <button
                type="button"
                disabled={isBusy}
                onClick={onOpenEnterCode}
                className="card-slot-silver-active hover:border-white py-3.5 px-4 rounded-2xl flex items-center justify-center gap-2.5 text-white text-xs sm:text-sm font-black uppercase tracking-wider cursor-pointer transition-all disabled:opacity-60"
              >
                <LockOpen className="w-4 h-4 text-white shrink-0" />
                <span>{t.enterCodeBtn}</span>
              </button>
            </div>

            {/* Option 3: AI Training */}
            <button
              type="button"
              disabled={isBusy}
              onClick={onStartAiTraining}
              className="card-slot-silver hover:border-white/70 w-full py-3.5 px-5 rounded-2xl flex items-center justify-between gap-3 text-white cursor-pointer transition-all disabled:opacity-60"
            >
              <div className="flex items-center gap-3 text-left">
                <Bot className="w-5 h-5 text-white shrink-0" />
                <div className="flex flex-col">
                  <span className="text-xs sm:text-sm font-black uppercase tracking-wider text-white">
                    {t.aiTrainingBtn}
                  </span>
                  <span className="text-[11px] text-slate-300">
                    {t.aiTrainingDesc}
                  </span>
                </div>
              </div>
              <span className="text-xs font-black text-white uppercase shrink-0">→</span>
            </button>
          </div>
        )}

        {/* STATE 2: QUICK MATCH 50-SECOND COUNTDOWN */}
        {subState === 'QUICK_SEARCHING' && (
          <div className="w-full card-slot-silver-active rounded-2xl p-6 flex flex-col items-center text-center gap-4">
            <Loader2 className="w-8 h-8 text-white animate-spin" />
            <div className="flex flex-col gap-1">
              <span className="text-sm sm:text-base font-black tracking-wider text-white uppercase">
                {t.searchingOpponentTitle}
              </span>
              <span className="text-xs text-slate-300">
                {t.searchingCountdownLabel(quickSearchSecondsLeft)}
              </span>
            </div>

            <div className="text-4xl sm:text-5xl score-platinum">
              00:{String(quickSearchSecondsLeft).padStart(2, '0')}
            </div>

            {/* Progress bar */}
            <div className="w-full h-2.5 rounded-full bg-white/10 overflow-hidden border border-white/20">
              <div
                className="h-full btn-liquid-silver transition-all duration-700"
                style={{ width: `${Math.max(0, (quickSearchSecondsLeft / 50) * 100)}%` }}
              />
            </div>

            <button
              type="button"
              onClick={onCancelMatchmaking}
              className="card-slot-silver px-6 py-2.5 rounded-xl text-xs text-white uppercase hover:border-white/70 cursor-pointer mt-1"
            >
              {t.cancelSearchBtn}
            </button>
          </div>
        )}

        {/* STATE 3: 50s EXPIRED -> AI FALLBACK NOTIFICATION */}
        {subState === 'AI_FALLBACK_NOTICE' && (
          <div className="w-full card-slot-silver-active rounded-2xl p-6 flex flex-col items-center text-center gap-3">
            <Bot className="w-9 h-9 text-white animate-bounce" />
            <span className="text-sm sm:text-base font-black tracking-wider text-white uppercase">
              {t.opponentNotFoundAiFallback}
            </span>
          </div>
        )}

        {/* STATE 4: CREATED PRIVATE LOBBY ROOM CODE */}
        {subState === 'LOBBY_WAITING' && createdRoomCode && (
          <div className="w-full card-slot-silver-active rounded-2xl p-6 flex flex-col items-center text-center gap-4">
            <Loader2 className="w-7 h-7 text-white animate-spin" />
            <span className="text-xs sm:text-sm font-black tracking-wider text-white uppercase">
              {t.roomCodeCreatedMsg(createdRoomCode)}
            </span>

            <div className="flex items-center gap-3">
              <div className="px-6 py-3 rounded-2xl bg-black/50 border border-white/40 text-3xl sm:text-4xl score-platinum tracking-[6px]">
                {createdRoomCode}
              </div>
              <button
                type="button"
                onClick={handleCopyCode}
                className="btn-liquid-silver p-3.5 rounded-xl cursor-pointer"
                title="Copy Code"
              >
                {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>

            <button
              type="button"
              onClick={onCancelMatchmaking}
              className="card-slot-silver px-6 py-2.5 rounded-xl text-xs text-white uppercase hover:border-white/70 cursor-pointer"
            >
              {t.cancelSearchBtn}
            </button>
          </div>
        )}

        {/* STATE 5: ENTER FRIEND'S ROOM CODE */}
        {subState === 'ENTER_CODE_FORM' && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSubmitJoinCode(inputCode);
            }}
            className="w-full card-slot-silver rounded-2xl p-5 flex flex-col items-center gap-4"
          >
            <input
              type="text"
              value={inputCode}
              onChange={(e) => setInputCode(e.target.value.toUpperCase())}
              placeholder={t.enterFriendCodePlaceholder}
              maxLength={6}
              autoFocus
              className="w-full text-center text-2xl font-black tracking-[6px] uppercase py-3 px-4 rounded-xl bg-black/50 border border-white/35 text-white placeholder-slate-500 focus:outline-none focus:border-white"
            />

            {codeError && (
              <div className="w-full px-3 py-2 rounded-xl bg-white/10 border border-white/35 text-xs text-white text-center font-black uppercase">
                {codeError}
              </div>
            )}

            <div className="w-full grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={onCancelMatchmaking}
                className="card-slot-silver py-3 rounded-xl text-xs text-white uppercase hover:border-white/70 cursor-pointer"
              >
                {t.cancelSearchBtn}
              </button>

              <button
                type="submit"
                disabled={isBusy || inputCode.trim().length < 3}
                className="btn-liquid-silver py-3 rounded-xl text-xs uppercase cursor-pointer disabled:opacity-50"
              >
                {t.joinRoomSubmitBtn}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

interface PostBattleModalProps {
  isOpen: boolean;
  lang: LanguageCode;
  profile: UserProfile;
  oldRating: number;
  newRating: number;
  playerScore: number;
  enemyScore: number;
  winsProgressAfter: number;
  bonusPackEarned: boolean;
  deckCards: ValidatorCard[];
  onReturnToHub: () => void;
}

export const PostBattleModal: React.FC<PostBattleModalProps> = ({
  isOpen,
  lang,
  profile,
  oldRating,
  newRating,
  playerScore,
  enemyScore,
  winsProgressAfter,
  bonusPackEarned,
  deckCards,
  onReturnToHub,
}) => {
  const t = TRANSLATIONS[lang];
  const [animatedRP, setAnimatedRP] = useState(oldRating);
  const [posterUrl, setPosterUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setAnimatedRP(oldRating);

    const duration = 900;
    const startTime = performance.now();

    let raf = 0;
    const step = (now: number) => {
      const ratio = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - ratio, 3);
      const current = Math.round(oldRating + (newRating - oldRating) * eased);
      setAnimatedRP(current);
      if (ratio < 1) {
        raf = requestAnimationFrame(step);
      }
    };
    raf = requestAnimationFrame(step);

    let cancelled = false;
    try {
      // Immediate synchronous render first
      const syncUrl = generateBattleSharePosterDataUrl({
        profile,
        oldRating,
        newRating,
        playerScore,
        enemyScore,
        deckCards,
      });
      setPosterUrl(syncUrl);

      // Then async render with decoded circular avatar portrait
      generateBattleSharePosterAsync({
        profile,
        oldRating,
        newRating,
        playerScore,
        enemyScore,
        deckCards,
      }).then((asyncUrl) => {
        if (!cancelled && asyncUrl) {
          setPosterUrl(asyncUrl);
        }
      });
    } catch {
      setPosterUrl(null);
    }

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
    };
  }, [isOpen, oldRating, newRating, profile, playerScore, enemyScore, deckCards]);

  if (!isOpen) return null;

  const isWin = playerScore > enemyScore;
  const isLoss = playerScore < enemyScore;
  const diff = newRating - oldRating;
  const diffLabel = diff >= 0 ? `+${diff} RP` : `${diff} RP`;

  const displayWinsBar = bonusPackEarned ? 3 : winsProgressAfter;

  const handleShareOnX = async () => {
    const dataUrl =
      posterUrl ||
      (await generateBattleSharePosterAsync({
        profile,
        oldRating,
        newRating,
        playerScore,
        enemyScore,
        deckCards,
      }));

    if (dataUrl) {
      const dl = document.createElement('a');
      dl.href = dataUrl;
      dl.download = `turbo_charging_battle_${profile.nickname}_${Date.now()}.png`;
      document.body.appendChild(dl);
      dl.click();
      document.body.removeChild(dl);
    }

    const statusTag = isWin ? 'VICTORY' : isLoss ? 'MATCH COMPLETED' : 'DRAW';
    const cardNames = deckCards.map((c) => c.name).join(', ');
    const tweetText = `${statusTag} in TURBO-CHARGING // VALIDATOR ARENA!\nPlayer: ${
      profile.nickname
    } (${playerScore}:${enemyScore})\nRating: ★ ${formatRatingRP(
      oldRating
    )} ➔ ★ ${formatRatingRP(newRating)} (${diffLabel})\nDeck: ${cardNames}`;

    const intentUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetText)}`;
    const link = document.createElement('a');
    link.href = intentUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xl">
      <div className="w-full max-w-lg panel-silver-chrome rounded-3xl p-5 sm:p-7 flex flex-col items-center gap-4 border border-white/35 max-h-[94dvh] overflow-y-auto">
        {/* Title & Monolithic Symmetrical Score Banner */}
        <div className="w-full flex flex-col items-center text-center gap-2">
          <div className="px-3.5 py-1 rounded-full card-slot-silver text-[11px] font-black tracking-[2px] text-slate-200 uppercase">
            {t.postBattleBadge}
          </div>
          <h2 className="text-xl sm:text-3xl font-black tracking-[1.5px] text-white uppercase">
            {isWin ? t.postBattleVictory : isLoss ? t.postBattleDefeat : t.postBattleDraw}
          </h2>

          {/* Symmetrical Monolithic Score Bar: YOU 1 • MATCH FINAL • 2 OPPONENT */}
          <div className="w-full card-slot-silver rounded-2xl px-4 py-2.5 grid grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-4 mt-0.5">
            <div className="flex items-center justify-end gap-2 sm:gap-2.5">
              <span className="text-xs sm:text-sm font-black tracking-[1.4px] uppercase text-slate-200">
                {t.youLabel}
              </span>
              <span className="text-xl sm:text-2xl score-platinum leading-none">
                {playerScore}
              </span>
            </div>

            <div className="flex items-center justify-center gap-2 sm:gap-3 px-1">
              <span className="text-slate-400 text-xs">•</span>
              <span className="text-[11px] sm:text-xs font-black tracking-[1.6px] text-white uppercase whitespace-nowrap">
                {t.matchFinalLabel}
              </span>
              <span className="text-slate-400 text-xs">•</span>
            </div>

            <div className="flex items-center justify-start gap-2 sm:gap-2.5">
              <span className="text-xl sm:text-2xl score-platinum leading-none">
                {enemyScore}
              </span>
              <span className="text-xs sm:text-sm font-black tracking-[1.4px] uppercase text-slate-200 truncate">
                {t.opponentLabel}
              </span>
            </div>
          </div>
        </div>

        {/* Clean Minimal Luxury Rating Change Block (Zero technical labels) */}
        <div className="w-full card-slot-silver-active rounded-2xl p-4 flex flex-col items-center justify-center gap-2 text-center">
          <span className="text-xs font-black tracking-[1.8px] text-slate-200 uppercase">
            {t.ratingChangeLabel}
          </span>
          <div className="flex flex-wrap items-center justify-center gap-3 text-xl sm:text-2xl font-black text-white">
            <span className="score-platinum">★ {formatRatingRP(oldRating)}</span>
            <span className="text-slate-300 text-lg">➔</span>
            <span className="score-platinum text-2xl sm:text-3xl">
              ★ {formatRatingRP(animatedRP)}
            </span>
            <span
              className={`px-3 py-1 rounded-xl text-xs sm:text-sm font-black tracking-wider border ${
                diff >= 0
                  ? 'bg-emerald-500/20 border-emerald-400/70 text-emerald-300 shadow-[0_0_16px_rgba(16,185,129,0.28)]'
                  : 'bg-rose-500/20 border-rose-400/70 text-rose-300 shadow-[0_0_16px_rgba(244,63,94,0.28)]'
              }`}
            >
              ({diffLabel})
            </span>
          </div>
        </div>

        {/* Wins Progress Bar (X/3 to Bonus Booster) */}
        <div className="w-full card-slot-silver rounded-2xl p-3.5 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-black uppercase tracking-wider text-slate-200">
              {t.winsToBonusBooster}
            </span>
            <span className="font-black text-white">{displayWinsBar}/3</span>
          </div>
          <div className="w-full grid grid-cols-3 gap-2">
            {[1, 2, 3].map((step) => {
              const filled = step <= displayWinsBar;
              return (
                <div
                  key={step}
                  className={`h-3 rounded-full transition-all duration-500 ${
                    filled
                      ? 'btn-liquid-silver'
                      : 'bg-white/10 border border-white/20'
                  }`}
                />
              );
            })}
          </div>
          {bonusPackEarned && (
            <div className="flex items-center justify-center gap-2 text-xs font-black text-white uppercase tracking-wider pt-1">
              <Sparkles className="w-4 h-4 text-white" />
              <span>{t.bonusBoosterEarnedMsg}</span>
            </div>
          )}
        </div>

        {/* Luxury 3D Cyberpunk Chrome Poster Preview */}
        {posterUrl && (
          <div
            className="w-full rounded-2xl p-[2px] relative group transition-transform duration-300 hover:scale-[1.01]"
            style={{
              background:
                'linear-gradient(135deg, #ffffff 0%, #cbd5e1 25%, #ff8bf3 50%, #bae6fd 75%, #f8fafc 100%)',
              boxShadow:
                '0 18px 42px rgba(0, 0, 0, 0.92), 0 0 28px rgba(255, 139, 243, 0.25), 0 0 18px rgba(255, 255, 255, 0.2)',
            }}
          >
            <div className="w-full rounded-[14px] overflow-hidden bg-[#020204] relative">
              <img
                src={posterUrl}
                alt="Battle Poster"
                className="w-full h-auto aspect-[16/9] object-contain bg-[#020204] block"
              />
              <a
                href={posterUrl}
                download={`turbo_charging_battle_${profile.nickname}.png`}
                className="absolute bottom-2.5 right-2.5 px-3 py-1.5 rounded-xl btn-liquid-silver text-[11px] flex items-center gap-1.5 shadow-lg opacity-95 hover:opacity-100"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t.downloadPngPoster}</span>
              </a>
            </div>
          </div>
        )}

        {/* Two Action Buttons */}
        <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <button
            type="button"
            onClick={handleShareOnX}
            className="btn-liquid-silver py-3.5 px-4 rounded-xl text-xs uppercase flex items-center justify-center gap-2 cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            <span>{t.shareOnXBtn}</span>
          </button>

          <button
            type="button"
            onClick={onReturnToHub}
            className="btn-liquid-silver py-3.5 px-4 rounded-xl text-xs uppercase flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>{t.returnToMainMenuBtn}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

interface LeaderboardViewProps {
  lang: LanguageCode;
  entries: LeaderboardEntry[];
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ lang, entries }) => {
  const t = TRANSLATIONS[lang];

  return (
    <div className="fixed inset-x-0 top-20 bottom-20 z-20 mx-auto w-[94vw] max-w-[780px] flex flex-col pointer-events-auto">
      <div className="w-full h-full panel-silver-chrome rounded-3xl p-4 sm:p-6 flex flex-col gap-3.5 overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/15 pb-3">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-5 h-5 text-white shrink-0" />
            <h2 className="text-base sm:text-xl font-black tracking-[1.5px] text-white uppercase">
              {t.rankingHeader}
            </h2>
          </div>
          <span className="text-xs text-slate-300 uppercase tracking-wider">
            Sub-node ➜ OPTIMUM MASTER
          </span>
        </div>

        <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-2">
          {entries.map((entry, idx) => {
            const rank = idx + 1;
            const rankTitle = getRankTitle(entry.ratingRP);
            return (
              <div
                key={entry.nickname}
                className={`w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-2xl flex items-center justify-between gap-3 transition-all ${
                  entry.isCurrentUser ? 'card-slot-silver-active' : 'card-slot-silver'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-7 text-center font-black text-sm sm:text-base text-white shrink-0">
                    #{rank}
                  </div>
                  <img
                    src={entry.avatarUrl}
                    alt={entry.nickname}
                    className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl object-cover border border-white/35 shrink-0 bg-black/40"
                  />
                  <div className="flex flex-col min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-black text-sm sm:text-base text-white truncate">
                        {entry.nickname}
                      </span>
                      {entry.isCurrentUser && (
                        <span className="px-2 py-0.5 rounded-md bg-white/20 text-[10px] font-black text-white uppercase">
                          {t.youBadge}
                        </span>
                      )}
                      <span className="px-2 py-0.5 rounded-md card-slot-silver text-[10px] font-black text-slate-200 uppercase">
                        {rankTitle}
                      </span>
                    </div>
                    <span className="text-xs text-slate-300">
                      {t.arenaWinsCount(entry.matchesWon)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-sm sm:text-lg score-platinum">
                    ★ {formatRatingRP(entry.ratingRP)} RP
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

interface MyDeckViewProps {
  lang: LanguageCode;
  allCards: ValidatorCard[];
  collectionIds: number[];
  battleDeckIds: number[];
  customPngCount: number;
  onToggleDeckCard: (cardId: number) => void;
  onAutoPickBest: () => void;
  onInspectCard: (card: ValidatorCard) => void;
  onOpenFullCatalog: () => void;
  onGoToBoosters: () => void;
}

export const MyDeckView: React.FC<MyDeckViewProps> = ({
  lang,
  allCards,
  collectionIds,
  battleDeckIds,
  customPngCount,
  onToggleDeckCard,
  onAutoPickBest,
  onInspectCard,
  onOpenFullCatalog,
  onGoToBoosters,
}) => {
  const t = TRANSLATIONS[lang];
  const ownedCards = allCards.filter((c) => collectionIds.includes(c.id));
  const [isCollapsed, setIsCollapsed] = useState(false);
  const carouselRef = useRef<HTMLDivElement | null>(null);

  const handleScrollCarousel = (direction: 'left' | 'right') => {
    const el = carouselRef.current;
    if (!el) return;
    const scrollAmount = Math.max(260, el.clientWidth * 0.65);
    el.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  if (isCollapsed) {
    return (
      <div className="fixed bottom-20 right-4 sm:right-8 z-20 pointer-events-auto">
        <button
          type="button"
          onClick={() => setIsCollapsed(false)}
          className="btn-liquid-silver px-4 py-2.5 rounded-2xl text-xs uppercase flex items-center gap-2 cursor-pointer shadow-xl"
        >
          <Layers className="w-4 h-4" />
          <span>
            {t.showDeckPanelBtn} ({battleDeckIds.length}/3)
          </span>
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-x-0 bottom-18 sm:bottom-20 z-20 mx-auto w-[95vw] max-w-[980px] flex flex-col pointer-events-auto">
      <div className="w-full panel-silver-chrome rounded-3xl p-3.5 sm:p-4 flex flex-col gap-2.5 overflow-hidden">
        {/* Top Header Row with Hide / Close Button in Top-Right */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/15 pb-2">
          <div className="flex flex-col sm:flex-row sm:items-center gap-0.5 sm:gap-3 min-w-0">
            <h2 className="text-xs sm:text-sm font-black tracking-[1.2px] text-white uppercase truncate">
              {t.myDeckHeader(battleDeckIds.length, ownedCards.length, allCards.length)}
            </h2>
            <span className="text-[10px] sm:text-xs text-slate-300">
              {t.myDeckSubheader}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={onOpenFullCatalog}
              className="card-slot-silver px-2.5 sm:px-3 py-1.5 rounded-xl text-[11px] sm:text-xs text-white uppercase flex items-center gap-1.5 hover:border-white/60 cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{t.all103CardsBtn}</span>
            </button>
            {ownedCards.length > 0 && (
              <button
                type="button"
                onClick={onAutoPickBest}
                className="btn-liquid-silver px-3 py-1.5 rounded-xl text-[11px] sm:text-xs uppercase cursor-pointer"
              >
                {t.autoPickTop3Btn}
              </button>
            )}
            <button
              type="button"
              onClick={() => setIsCollapsed(true)}
              className="card-slot-silver-active hover:border-white px-3 py-1.5 rounded-xl text-[11px] sm:text-xs text-white font-black uppercase flex items-center gap-1 cursor-pointer transition-all"
              title={t.hideDeckPanelBtn}
            >
              <span>{t.hideDeckPanelBtn}</span>
              <X className="w-3.5 h-3.5 text-white" />
            </button>
          </div>
        </div>

        {/* Horizontal Carousel Body (Zero Vertical Scroll) */}
        {ownedCards.length === 0 ? (
          <div className="py-5 flex flex-col items-center justify-center text-center gap-2">
            <p className="text-xs sm:text-sm text-slate-200 font-black uppercase tracking-wider">
              {t.noCardsOwnedTitle}
            </p>
            <p className="text-xs text-slate-300 max-w-md">
              {t.noCardsOwnedSubtitle}
            </p>
            <button
              type="button"
              onClick={onGoToBoosters}
              className="btn-liquid-silver px-5 py-2 rounded-xl text-xs uppercase cursor-pointer mt-1"
            >
              {t.goToBoostersBtn}
            </button>
          </div>
        ) : (
          <div className="relative w-full flex items-center">
            {/* Left Semi-Transparent White Arrow */}
            <button
              type="button"
              onClick={() => handleScrollCarousel('left')}
              className="absolute left-1 z-10 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white/15 hover:bg-white/30 border border-white/50 text-white flex items-center justify-center backdrop-blur-md shadow-lg transition-all cursor-pointer"
              aria-label="Previous cards"
            >
              <ChevronLeft className="w-5 h-5 text-white" />
            </button>

            {/* Horizontal Card Track (No vertical scroll) */}
            <div
              ref={carouselRef}
              className="w-full flex items-stretch gap-3 overflow-x-auto overflow-y-hidden scroll-smooth px-11 sm:px-12 py-1"
              style={{ scrollbarWidth: 'none' }}
            >
              {ownedCards.map((card) => {
                const isSelected = battleDeckIds.includes(card.id);
                return (
                  <div
                    key={card.id}
                    onClick={() => onToggleDeckCard(card.id)}
                    className={`w-[132px] sm:w-[148px] shrink-0 p-2 rounded-2xl transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
                      isSelected
                        ? 'card-slot-silver-active -translate-y-0.5'
                        : 'card-slot-silver hover:border-white/55'
                    }`}
                  >
                    <div className="w-full rounded-lg overflow-hidden border border-white/20">
                      <CardCanvasPreview card={card} version={customPngCount} />
                    </div>
                    <div className="flex items-center justify-between gap-1 px-0.5">
                      <span className="font-black text-[11px] text-white truncate">
                        {card.name}
                      </span>
                      {isSelected ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-white shrink-0" />
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onInspectCard(card);
                          }}
                          className="text-slate-300 hover:text-white"
                          title={t.inspectCardTooltip}
                        >
                          <Eye className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <div className="flex items-center justify-between px-0.5">
                      <span className="text-[11px] font-black text-white">★ {card.power}</span>
                      <span className="text-[10px] text-slate-300">
                        {card.latency}ms • {card.speedBoost}x
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Right Semi-Transparent White Arrow */}
            <button
              type="button"
              onClick={() => handleScrollCarousel('right')}
              className="absolute right-1 z-10 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white/15 hover:bg-white/30 border border-white/50 text-white flex items-center justify-center backdrop-blur-md shadow-lg transition-all cursor-pointer"
              aria-label="Next cards"
            >
              <ChevronRight className="w-5 h-5 text-white" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

