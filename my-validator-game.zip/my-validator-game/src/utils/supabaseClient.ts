import { createClient, RealtimeChannel } from '@supabase/supabase-js';

export const SUPABASE_URL = 'https://iodtafoeyesozgangjxt.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_i1MTEKYg_IGFhHvcY3xypA_I49bMGmy';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

export interface MatchRow {
  id: string;
  room_code: string;
  player1: string;
  player2: string | null;
  p1_moves: number[];
  p2_moves: number[];
  status: 'waiting' | 'playing' | 'finished';
  winner: string | null;
  created_at?: string;
}

/**
 * Generates a 4-character uppercase room code as requested:
 * Math.random().toString(36).substring(2, 6).toUpperCase()
 */
export function generateRoomCode(): string {
  return Math.random().toString(36).substring(2, 6).toUpperCase();
}

/**
 * Quick Match (PvP):
 * 1) Searches `matches` for an existing room with status='waiting', player2 IS NULL, room_code='QUICK'
 *    created within the last 2 minutes and where player1 !== currentUsername.
 * 2) If found, joins as player2 and sets status='playing'.
 * 3) Otherwise creates a new waiting room with room_code='QUICK' and player1=currentUsername.
 */
export async function findOrCreateQuickMatch(
  currentUsername: string
): Promise<{ match: MatchRow; role: 'p1' | 'p2'; joinedImmediately: boolean }> {
  const twoMinAgo = new Date(Date.now() - 2 * 60 * 1000).toISOString();

  const { data: waitingRooms } = await supabase
    .from('matches')
    .select('*')
    .eq('status', 'waiting')
    .eq('room_code', 'QUICK')
    .is('player2', null)
    .neq('player1', currentUsername)
    .gte('created_at', twoMinAgo)
    .order('created_at', { ascending: false })
    .limit(1);

  if (waitingRooms && waitingRooms.length > 0) {
    const candidate = waitingRooms[0] as MatchRow;
    const { data: updated, error: updateErr } = await supabase
      .from('matches')
      .update({
        player2: currentUsername,
        status: 'playing',
      })
      .eq('id', candidate.id)
      .is('player2', null)
      .select('*')
      .single();

    if (!updateErr && updated) {
      return {
        match: updated as MatchRow,
        role: 'p2',
        joinedImmediately: true,
      };
    }
  }

  // Create a new waiting room for Quick Match
  const { data: created, error: createErr } = await supabase
    .from('matches')
    .insert({
      room_code: 'QUICK',
      player1: currentUsername,
      player2: null,
      status: 'waiting',
      p1_moves: [],
      p2_moves: [],
    })
    .select('*')
    .single();

  if (createErr || !created) {
    throw new Error(createErr?.message || 'Failed to create quick match room');
  }

  return {
    match: created as MatchRow,
    role: 'p1',
    joinedImmediately: false,
  };
}

/**
 * Private Lobby by Code — Create Room:
 * Generates 4-char code via Math.random().toString(36).substring(2, 6).toUpperCase(),
 * inserts row into `matches` with status='waiting'.
 */
export async function createPrivateLobbyMatch(
  currentUsername: string
): Promise<{ match: MatchRow; role: 'p1' }> {
  const code = generateRoomCode();
  const { data, error } = await supabase
    .from('matches')
    .insert({
      room_code: code,
      player1: currentUsername,
      player2: null,
      status: 'waiting',
      p1_moves: [],
      p2_moves: [],
    })
    .select('*')
    .single();

  if (error || !data) {
    throw new Error(error?.message || 'Failed to create lobby');
  }

  return {
    match: data as MatchRow,
    role: 'p1',
  };
}

/**
 * Private Lobby by Code — Join Room:
 * Finds `matches` row by `room_code` with status='waiting', sets player2=currentUsername and status='playing'.
 */
export async function joinPrivateLobbyByCode(
  rawCode: string,
  currentUsername: string
): Promise<{ match?: MatchRow; role?: 'p2'; error?: string }> {
  const cleanCode = rawCode.trim().toUpperCase();
  if (!cleanCode) {
    return { error: 'EMPTY_CODE' };
  }

  const { data: rooms, error: findErr } = await supabase
    .from('matches')
    .select('*')
    .eq('room_code', cleanCode)
    .eq('status', 'waiting')
    .is('player2', null)
    .order('created_at', { ascending: false })
    .limit(1);

  if (findErr || !rooms || rooms.length === 0) {
    return { error: 'NOT_FOUND' };
  }

  const room = rooms[0] as MatchRow;

  const { data: updated, error: joinErr } = await supabase
    .from('matches')
    .update({
      player2: currentUsername,
      status: 'playing',
    })
    .eq('id', room.id)
    .select('*')
    .single();

  if (joinErr || !updated) {
    return { error: 'JOIN_FAILED' };
  }

  return {
    match: updated as MatchRow,
    role: 'p2',
  };
}

/**
 * Deletes or cancels a waiting match if the host cancels or times out into AI fallback.
 */
export async function cancelWaitingMatch(matchId: string): Promise<void> {
  try {
    await supabase.from('matches').delete().eq('id', matchId).eq('status', 'waiting');
  } catch {
    // ignore
  }
}

/**
 * Submits a player's move (card ID) for the current round to `p1_moves` or `p2_moves`.
 */
export async function submitPvPMove(
  matchId: string,
  role: 'p1' | 'p2',
  nextMoves: number[]
): Promise<MatchRow | null> {
  const updatePayload =
    role === 'p1' ? { p1_moves: nextMoves } : { p2_moves: nextMoves };

  const { data, error } = await supabase
    .from('matches')
    .update(updatePayload)
    .eq('id', matchId)
    .select('*')
    .single();

  if (error || !data) return null;
  return data as MatchRow;
}

/**
 * Marks a PvP match as finished with the winner's username.
 */
export async function completePvPMatch(
  matchId: string,
  winner: string | null
): Promise<void> {
  try {
    await supabase
      .from('matches')
      .update({
        status: 'finished',
        winner,
      })
      .eq('id', matchId);
  } catch {
    // ignore
  }
}

/**
 * Subscribes to changes on a specific match row using Supabase Realtime (.channel())
 * plus a lightweight polling interval so updates arrive even if Realtime replication is toggled off.
 */
export function subscribeToMatchUpdates(
  matchId: string,
  onUpdate: (match: MatchRow) => void
): () => void {
  let active = true;

  const channel: RealtimeChannel = supabase
    .channel(`match_room_${matchId}`)
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'matches',
        filter: `id=eq.${matchId}`,
      },
      (payload) => {
        if (active && payload.new) {
          onUpdate(payload.new as MatchRow);
        }
      }
    )
    .subscribe();

  const pollInterval = window.setInterval(async () => {
    if (!active) return;
    const { data } = await supabase
      .from('matches')
      .select('*')
      .eq('id', matchId)
      .maybeSingle();
    if (active && data) {
      onUpdate(data as MatchRow);
    }
  }, 1400);

  return () => {
    active = false;
    window.clearInterval(pollInterval);
    supabase.removeChannel(channel);
  };
}
