class SoundEngine {
  private ctx: AudioContext | null = null;
  public muted: boolean = false;

  public init() {
    if (this.muted) return;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private createSaturationCurve(amount = 24): Float32Array {
    const nSamples = 1024;
    const curve = new Float32Array(nSamples);
    for (let i = 0; i < nSamples; i++) {
      const x = (i * 2) / nSamples - 1;
      curve[i] = ((3 + amount) * x * 20 * (Math.PI / 180)) / (Math.PI + amount * Math.abs(x));
    }
    return curve;
  }

  /**
   * UI Click: Short, soft futuristic tactile click (no primitive high-pitched beep).
   */
  public select() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // 1. Soft low-mid tactile thump body
    const bodyOsc = this.ctx.createOscillator();
    const bodyGain = this.ctx.createGain();
    bodyOsc.type = 'sine';
    bodyOsc.frequency.setValueAtTime(240, now);
    bodyOsc.frequency.exponentialRampToValueAtTime(68, now + 0.038);

    bodyGain.gain.setValueAtTime(0.18, now);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    bodyOsc.connect(bodyGain);
    bodyGain.connect(this.ctx.destination);
    bodyOsc.start(now);
    bodyOsc.stop(now + 0.042);

    // 2. Crisp micro-transient filtered noise click
    const clickBuf = this.ctx.createBuffer(
      1,
      Math.floor(this.ctx.sampleRate * 0.018),
      this.ctx.sampleRate
    );
    const data = clickBuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (data.length * 0.25));
    }

    const noiseSrc = this.ctx.createBufferSource();
    noiseSrc.buffer = clickBuf;

    const lpFilter = this.ctx.createBiquadFilter();
    lpFilter.type = 'bandpass';
    lpFilter.frequency.setValueAtTime(1350, now);
    lpFilter.Q.setValueAtTime(1.8, now);

    const clickGain = this.ctx.createGain();
    clickGain.gain.setValueAtTime(0.14, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.018);

    noiseSrc.connect(lpFilter);
    lpFilter.connect(clickGain);
    clickGain.connect(this.ctx.destination);
    noiseSrc.start(now);
  }

  /**
   * Pack Tear: Deep rustling of thick metallic foil with a sweeping low-pass filter and sub body.
   */
  public tear() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const duration = 0.52;
    const sampleCount = Math.floor(this.ctx.sampleRate * duration);
    const buf = this.ctx.createBuffer(1, sampleCount, this.ctx.sampleRate);
    const data = buf.getChannelData(0);

    // Generate textured pink-ish foil crinkle noise with amplitude modulations
    let b0 = 0;
    let b1 = 0;
    let b2 = 0;
    for (let i = 0; i < sampleCount; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.997 * b0 + white * 0.029;
      b1 = 0.985 * b1 + white * 0.032;
      b2 = 0.95 * b2 + white * 0.048;
      const crinkle =
        0.55 +
        0.45 * Math.sin(i * 0.0045) * Math.cos(i * 0.013);
      const env = Math.sin((i / sampleCount) * Math.PI);
      data[i] = (b0 + b1 + b2 + white * 0.18) * crinkle * env;
    }

    const src = this.ctx.createBufferSource();
    src.buffer = buf;

    // Low-pass filter sweeping down for heavy foil texture
    const lowpass = this.ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.setValueAtTime(1950, now);
    lowpass.frequency.exponentialRampToValueAtTime(680, now + 0.25);
    lowpass.frequency.exponentialRampToValueAtTime(240, now + duration);
    lowpass.Q.setValueAtTime(2.4, now);

    // High-pass at 75Hz to keep foil warm without DC rumble
    const highpass = this.ctx.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.setValueAtTime(75, now);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.01, now);
    gain.gain.linearRampToValueAtTime(0.68, now + 0.06);
    gain.gain.exponentialRampToValueAtTime(0.008, now + duration);

    src.connect(highpass);
    highpass.connect(lowpass);
    lowpass.connect(gain);
    gain.connect(this.ctx.destination);
    src.start(now);

    // Deep sub-bass vacuum seal release
    const sealOsc = this.ctx.createOscillator();
    const sealGain = this.ctx.createGain();
    sealOsc.type = 'sine';
    sealOsc.frequency.setValueAtTime(110, now);
    sealOsc.frequency.exponentialRampToValueAtTime(34, now + 0.32);
    sealGain.gain.setValueAtTime(0.38, now);
    sealGain.gain.exponentialRampToValueAtTime(0.001, now + 0.34);
    sealOsc.connect(sealGain);
    sealGain.connect(this.ctx.destination);
    sealOsc.start(now);
    sealOsc.stop(now + 0.35);
  }

  /**
   * Card Flip: Pure crystalline FM-synthesis shimmer (Carrier + Harmonic Modulator).
   */
  public chime(pitchMultiplier = 1) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const baseFreq = 528 * pitchMultiplier;

    // FM Carrier 1 (Fundamental crystal)
    const carrier1 = this.ctx.createOscillator();
    const mod1 = this.ctx.createOscillator();
    const modGain1 = this.ctx.createGain();
    const outGain1 = this.ctx.createGain();

    carrier1.type = 'sine';
    carrier1.frequency.setValueAtTime(baseFreq, now);
    carrier1.frequency.exponentialRampToValueAtTime(baseFreq * 1.008, now + 0.55);

    // Non-integer harmonic ratio for crystalline metallic bell timbre
    mod1.type = 'sine';
    mod1.frequency.setValueAtTime(baseFreq * 2.0, now);

    modGain1.gain.setValueAtTime(baseFreq * 1.15, now);
    modGain1.gain.exponentialRampToValueAtTime(1.0, now + 0.32);

    outGain1.gain.setValueAtTime(0.001, now);
    outGain1.gain.linearRampToValueAtTime(0.18, now + 0.015);
    outGain1.gain.exponentialRampToValueAtTime(0.0008, now + 0.58);

    mod1.connect(modGain1);
    modGain1.connect(carrier1.frequency);
    carrier1.connect(outGain1);
    outGain1.connect(this.ctx.destination);

    // FM Carrier 2 (Fifth interval shimmer)
    const carrier2 = this.ctx.createOscillator();
    const mod2 = this.ctx.createOscillator();
    const modGain2 = this.ctx.createGain();
    const outGain2 = this.ctx.createGain();

    const fifthFreq = baseFreq * 1.498;
    carrier2.type = 'sine';
    carrier2.frequency.setValueAtTime(fifthFreq, now + 0.035);
    mod2.type = 'sine';
    mod2.frequency.setValueAtTime(fifthFreq * 3.0, now + 0.035);

    modGain2.gain.setValueAtTime(fifthFreq * 0.75, now + 0.035);
    modGain2.gain.exponentialRampToValueAtTime(0.5, now + 0.4);

    outGain2.gain.setValueAtTime(0.001, now + 0.035);
    outGain2.gain.linearRampToValueAtTime(0.11, now + 0.055);
    outGain2.gain.exponentialRampToValueAtTime(0.0008, now + 0.65);

    mod2.connect(modGain2);
    modGain2.connect(carrier2.frequency);
    carrier2.connect(outGain2);
    outGain2.connect(this.ctx.destination);

    carrier1.start(now);
    mod1.start(now);
    carrier1.stop(now + 0.6);
    mod1.stop(now + 0.6);

    carrier2.start(now + 0.035);
    mod2.start(now + 0.035);
    carrier2.stop(now + 0.68);
    mod2.stop(now + 0.68);
  }

  /**
   * Card Battle Impact: Dense, deep cinematic 808-style sub-bass drop with warm saturation and haptic vibration.
   */
  public impact() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      try {
        navigator.vibrate([45, 25, 65]);
      } catch {
        // ignore
      }
    }

    const now = this.ctx.currentTime;

    // 1. 808 Sub-Bass Core (Pitch envelope 145Hz -> 46Hz -> 28Hz)
    const subOsc = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    const shaper = this.ctx.createWaveShaper();
    shaper.curve = this.createSaturationCurve(18);
    shaper.oversample = '2x';

    const subLp = this.ctx.createBiquadFilter();
    subLp.type = 'lowpass';
    subLp.frequency.setValueAtTime(220, now);
    subLp.frequency.exponentialRampToValueAtTime(85, now + 0.55);

    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(145, now);
    subOsc.frequency.exponentialRampToValueAtTime(48, now + 0.065);
    subOsc.frequency.exponentialRampToValueAtTime(28, now + 0.68);

    subGain.gain.setValueAtTime(0.01, now);
    subGain.gain.linearRampToValueAtTime(0.85, now + 0.008);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.72);

    subOsc.connect(shaper);
    shaper.connect(subLp);
    subLp.connect(subGain);
    subGain.connect(this.ctx.destination);

    subOsc.start(now);
    subOsc.stop(now + 0.75);

    // 2. Low-Mid Punch Transient (Chest hit at 90Hz -> 40Hz)
    const punchOsc = this.ctx.createOscillator();
    const punchGain = this.ctx.createGain();
    punchOsc.type = 'triangle';
    punchOsc.frequency.setValueAtTime(95, now);
    punchOsc.frequency.exponentialRampToValueAtTime(36, now + 0.11);

    punchGain.gain.setValueAtTime(0.42, now);
    punchGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    punchOsc.connect(punchGain);
    punchGain.connect(this.ctx.destination);
    punchOsc.start(now);
    punchOsc.stop(now + 0.13);
  }

  /**
   * Match Victory: Rich warm FM chord with deep sub foundation.
   */
  public victory() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // Warm sub foundation
    const bass = this.ctx.createOscillator();
    const bassGain = this.ctx.createGain();
    bass.type = 'sine';
    bass.frequency.setValueAtTime(65.41, now); // C2
    bassGain.gain.setValueAtTime(0.45, now);
    bassGain.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
    bass.connect(bassGain);
    bassGain.connect(this.ctx.destination);
    bass.start(now);
    bass.stop(now + 1.15);

    // Crystalline FM chord notes
    const chord = [261.63, 329.63, 392.0, 523.25];
    chord.forEach((freq, idx) => {
      if (!this.ctx) return;
      const start = now + idx * 0.075;
      const osc = this.ctx.createOscillator();
      const mod = this.ctx.createOscillator();
      const modGain = this.ctx.createGain();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);
      mod.type = 'sine';
      mod.frequency.setValueAtTime(freq * 2, start);

      modGain.gain.setValueAtTime(freq * 0.6, start);
      modGain.gain.exponentialRampToValueAtTime(1, start + 0.45);

      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(0.14, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0008, start + 0.85);

      mod.connect(modGain);
      modGain.connect(osc.frequency);
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(start);
      mod.start(start);
      osc.stop(start + 0.9);
      mod.stop(start + 0.9);
    });
  }
}

export const Sound = new SoundEngine();

