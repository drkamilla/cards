import * as THREE from 'three';
import { ValidatorCard } from '../data/cardsData';

const sharedTextureLoader = new THREE.TextureLoader();

export function toRelativeCardUrl(imagePath: string): string {
  const clean = imagePath.replace(/\\/g, '/').replace(/^\.?\/+/, '').trim();
  const parts = clean.split('/');
  const filename = parts[parts.length - 1];
  const folder = parts.length > 1 ? parts.slice(0, -1).join('/') : 'cards';
  return `./${folder}/${encodeURIComponent(filename)}`;
}

function normalizeCardKey(pathOrName: string): string {
  const clean = pathOrName.replace(/\\/g, '/').trim();
  const parts = clean.split('/');
  return parts[parts.length - 1].toLowerCase();
}

class CardImageStore {
  private loadedTextures = new Map<string, THREE.Texture>();
  private loadedImages = new Map<string, HTMLImageElement>();
  private resolvedUrls = new Map<string, string>();
  private loadingPromises = new Map<string, Promise<HTMLImageElement | null>>();
  private listeners = new Set<() => void>();
  private notifyTimer: number | null = null;

  public async init(cards?: ValidatorCard[]): Promise<void> {
    if (cards && cards.length > 0) {
      this.preloadAllCards(cards);
    }
  }

  public preloadAllCards(cards: ValidatorCard[]): void {
    cards.forEach((card) => {
      this.probeServerImage(card.image);
    });
  }

  public getLoadedTexture(imagePath: string): THREE.Texture | undefined {
    const key = normalizeCardKey(imagePath);
    return this.loadedTextures.get(key);
  }

  public getLoadedImage(imagePath: string): HTMLImageElement | undefined {
    const key = normalizeCardKey(imagePath);
    return this.loadedImages.get(key);
  }

  public getResolvedUrl(imagePath: string): string {
    const key = normalizeCardKey(imagePath);
    return this.resolvedUrls.get(key) || toRelativeCardUrl(imagePath);
  }

  public getCustomCount(): number {
    return this.loadedImages.size;
  }

  public probeServerImage(
    imagePath: string,
    onLoaded?: (img: HTMLImageElement, tex?: THREE.Texture) => void
  ): void {
    const key = normalizeCardKey(imagePath);
    const existingImg = this.loadedImages.get(key);
    const existingTex = this.loadedTextures.get(key);
    if (existingImg) {
      onLoaded?.(existingImg, existingTex);
      return;
    }

    const inFlight = this.loadingPromises.get(key);
    if (inFlight) {
      if (onLoaded) {
        inFlight.then((img) => {
          if (img) onLoaded(img, this.loadedTextures.get(key));
        });
      }
      return;
    }

    const relativeUrl = toRelativeCardUrl(imagePath);
    this.resolvedUrls.set(key, relativeUrl);

    const p = new Promise<HTMLImageElement | null>((resolve) => {
      sharedTextureLoader.load(
        relativeUrl,
        (texture) => {
          texture.colorSpace = THREE.SRGBColorSpace;
          const img = texture.image as HTMLImageElement | undefined;
          if (img && img.width > 0 && img.height > 0) {
            this.loadedTextures.set(key, texture);
            this.loadedImages.set(key, img);
            this.scheduleNotify();
            onLoaded?.(img, texture);
            resolve(img);
          } else {
            resolve(null);
          }
        },
        undefined,
        () => {
          resolve(null);
        }
      );
    }).finally(() => {
      this.loadingPromises.delete(key);
    });

    this.loadingPromises.set(key, p);
  }

  public subscribe(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private scheduleNotify() {
    if (this.notifyTimer !== null) return;
    this.notifyTimer = window.setTimeout(() => {
      this.notifyTimer = null;
      this.listeners.forEach((cb) => cb());
    }, 30);
  }
}

export const cardImageStore = new CardImageStore();
