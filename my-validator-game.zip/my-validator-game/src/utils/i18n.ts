export type LanguageCode = 'RU' | 'EN' | 'KO' | 'VI';

const LANG_STORAGE_KEY = 'turbo_charging_lang_v2';

export function getInitialLanguage(): LanguageCode {
  try {
    const saved = localStorage.getItem(LANG_STORAGE_KEY);
    if (saved === 'RU' || saved === 'EN' || saved === 'KO' || saved === 'VI') {
      return saved;
    }
  } catch {
    // ignore
  }
  return 'RU';
}

export function saveLanguage(lang: LanguageCode): void {
  try {
    localStorage.setItem(LANG_STORAGE_KEY, lang);
  } catch {
    // ignore
  }
}

export function getRankTitle(rp: number): string {
  if (rp >= 1300) return 'OPTIMUM MASTER';
  if (rp >= 1150) return 'Prime Sequencer';
  if (rp >= 1050) return 'Turbo Validator';
  if (rp >= 950) return 'Relay Node';
  return 'Sub-node';
}

export interface TranslationDictionary {
  brandLogo: string;
  // Login Screen
  loginBadge: string;
  loginTitle: string;
  loginSubtitle: string;
  nicknameLabel: string;
  nicknamePlaceholder: string;
  passwordLabel: string;
  passwordPlaceholder: string;
  loginSubmitBtn: string;
  loginLoadingBtn: string;
  errEnterNickname: string;
  errEnterPassword: string;
  errWrongPassword: string;

  // Header & Hub
  uploadAvatarHint: string;
  collectionCount: string;
  winsCount: string;
  nextFreePackIn: string;
  winsToBonusBooster: string;
  catalogBtn: string;
  muteTooltip: string;
  unmuteTooltip: string;
  logoutTooltip: string;
  dropCardsTitle: string;
  dropCardsSubtitle: string;

  // Bottom Navigation Tabs (Clean text, no emojis)
  tabBoosters: string;
  tabMyDeck: string;
  tabBattleArena: string;
  tabRanking: string;

  // Boosters Tab
  boosterPedestalTitle: string;
  boosterSwipeOrClickHint: string;
  openPackBtn: (count: number) => string;
  noPacksAvailableBtn: (timer: string) => string;
  packTornPrompt: string;
  allCardsAddedPrompt: string;
  openAll3Btn: string;
  openNextPackBtn: (count: number) => string;
  backToPedestalBtn: string;
  slotHiddenLabel: (idx: number) => string;
  revealCardBtn: string;
  inspectCardTooltip: string;

  // My Deck Tab
  myDeckHeader: (selected: number, owned: number, total: number) => string;
  myDeckSubheader: string;
  all103CardsBtn: string;
  autoPickTop3Btn: string;
  hideDeckPanelBtn: string;
  showDeckPanelBtn: string;
  noCardsOwnedTitle: string;
  noCardsOwnedSubtitle: string;
  goToBoostersBtn: string;

  // Battle Mode Selection & Online PvP Lobby
  arenaMenuBadge: string;
  arenaMenuTitle: string;
  arenaMenuSubtitle: string;
  quickMatchBtn: string;
  quickMatchDesc: string;
  createLobbyBtn: string;
  enterCodeBtn: string;
  aiTrainingBtn: string;
  aiTrainingDesc: string;
  searchingOpponentTitle: string;
  searchingCountdownLabel: (sec: number) => string;
  opponentNotFoundAiFallback: string;
  roomCodeCreatedMsg: (code: string) => string;
  enterFriendCodePlaceholder: string;
  joinRoomSubmitBtn: string;
  cancelSearchBtn: string;
  roomNotFoundError: string;
  waitingForOpponentMove: string;

  // Battle Arena & Timers
  youLabel: string;
  opponentLabel: string;
  roundCounter: (round: number) => string;
  matchFinalLabel: string;
  countdownReadyLabel: string;
  nextRoundBannerText: string;
  turnTimerLabel: (sec: number) => string;
  autoMoveNotice: string;
  roundReviewPauseLabel: (sec: number) => string;
  nextRoundNowBtn: string;
  chooseCardPrompt: (round: number, modTitle: string) => string;
  playCardAction: string;
  roundWonMsg: (round: number, pPow: number, ePow: number, fasterPing: boolean) => string;
  roundLostMsg: (round: number, pPow: number, ePow: number) => string;
  roundWonByPingMsg: (round: number, pPing: number, ePing: number) => string;
  roundLostByPingMsg: (round: number, pPing: number, ePing: number) => string;
  roundDrawMsg: (round: number, pow: number) => string;
  reasonHigherPower: (pPow: number, bonus: boolean, ePow: number, faster: boolean) => string;
  reasonEnemyHigherPower: (ePow: number, bonus: boolean, pPow: number) => string;
  reasonFasterPing: (pow: number, pPing: number, ePing: number) => string;
  reasonEnemyFasterPing: (pow: number, ePing: number, pPing: number) => string;
  reasonExactTie: (pow: number, ping: number) => string;
  matchVictoryStatus: string;
  matchDefeatStatus: string;
  matchDrawStatus: string;

  // Round Modifiers
  modStandardTitle: string;
  modStandardRule: string;
  modLowLatencyTitle: string;
  modLowLatencyRule: string;
  modTurboSpeedTitle: string;
  modTurboSpeedRule: string;
  modHighBidTitle: string;
  modHighBidRule: string;

  // Post-Battle Modal
  postBattleBadge: string;
  postBattleVictory: string;
  postBattleDefeat: string;
  postBattleDraw: string;
  ratingChangeLabel: string;
  bonusBoosterEarnedMsg: string;
  downloadPngPoster: string;
  shareOnXBtn: string;
  returnToMainMenuBtn: string;

  // Ranking / Leaderboard
  rankingHeader: string;
  rankColumnTitle: string;
  youBadge: string;
  arenaWinsCount: (wins: number) => string;

  // Card Catalog & Stats
  catalogHeader: (total: number) => string;
  discoveredStat: (disc: number, total: number, pct: number) => string;
  ratingStat: (rp: number) => string;
  winsStat: (wins: number) => string;
  cardsFolderBtn: string;
  cardFileLabel: string;
  statSlotPower: string;
  statLatency: string;
  statSpeedBoost: string;
  statBidUplift: string;
  packsOpenedLabel: string;
  winStreakLabel: (streak: number) => string;
  searchPlaceholder: string;
  filterDiscoveredBtn: (count: number) => string;
  filterAllBtn: (count: number) => string;
  noCardsFoundMsg: string;

  // Rules & Formula Modal
  rulesBtnLabel: string;
  rulesModalTitle: string;
  rulesSec1Title: string;
  rulesSec1Bullet1: string;
  rulesSec1Bullet2: string;
  rulesSec1Bullet3: string;
  rulesSec2Title: string;
  rulesSec2Intro: string;
  rulesSec2Formula: string;
  rulesSec2Bullet1: string;
  rulesSec2Bullet2: string;
  rulesSec3Title: string;
  rulesSec3Bullet1: string;
  rulesSec3Bullet2: string;
  rulesCloseBtn: string;
}

export const TRANSLATIONS: Record<LanguageCode, TranslationDictionary> = {
  RU: {
    brandLogo: 'Turbo-Charging',
    loginBadge: 'TURBO-CHARGING // SUPABASE CLOUD',
    loginTitle: 'АВТОРИЗАЦИЯ ИГРОКА',
    loginSubtitle:
      'Войдите в существующий аккаунт или создайте новый профиль в 1 клик. Новичкам начисляется 3 стартовых бустер-пака и ★ 1,000 RP.',
    nicknameLabel: 'Логин (Никнейм)',
    nicknamePlaceholder: 'Например: CyberValidator',
    passwordLabel: 'Пароль',
    passwordPlaceholder: '••••••••',
    loginSubmitBtn: 'ВОЙТИ / СОЗДАТЬ',
    loginLoadingBtn: 'ПОДКЛЮЧЕНИЕ К SUPABASE...',
    errEnterNickname: 'Введите никнейм',
    errEnterPassword: 'Введите пароль',
    errWrongPassword: 'Неверный пароль для этого никнейма',

    uploadAvatarHint: 'Нажмите, чтобы загрузить свой аватар',
    collectionCount: 'Коллекция',
    winsCount: 'Побед',
    nextFreePackIn: 'Следующий бесплатный пак через:',
    winsToBonusBooster: 'Побед до бонус-бустера:',
    catalogBtn: 'База',
    muteTooltip: 'Выключить звук',
    unmuteTooltip: 'Включить звук',
    logoutTooltip: 'Сменить аккаунт / Выйти',
    dropCardsTitle: 'Отпустите папку «cards» или PNG-файлы карточек здесь',
    dropCardsSubtitle:
      'Все текстуры card_002.png ... card_104.png автоматически применятся к 3D-картам',

    tabBoosters: 'БУСТЕРЫ',
    tabMyDeck: 'МОЯ КОЛОДА',
    tabBattleArena: 'АРЕНА БОЯ',
    tabRanking: 'РЕЙТИНГ',

    boosterPedestalTitle: 'БУСТЕР-ПАК ВАЛИДАТОРОВ',
    boosterSwipeOrClickHint: 'Проведите линию разреза по бустеру или нажмите кнопку справа',
    openPackBtn: (count) => `ОТКРЫТЬ ПАК (Доступно: ${count})`,
    noPacksAvailableBtn: (timer) => `ОТКРЫТЬ ПАК (0) • ${timer}`,
    packTornPrompt: 'БУСТЕР ВСКРЫТ! НАЖМИТЕ НА КАРТЫ В 3D ИЛИ ВНИЗУ, ЧТОБЫ ПЕРЕВЕРНУТЬ',
    allCardsAddedPrompt:
      'ВСЕ 3 КАРТЫ СОХРАНЕНЫ В БАЗУ! ОТКРОЙТЕ ЕЩЁ ПАК ИЛИ НАСТРОЙТЕ КОЛОДУ',
    openAll3Btn: 'Открыть все (3)',
    openNextPackBtn: (count) => `ОТКРЫТЬ ПАК (Доступно: ${count})`,
    backToPedestalBtn: 'К БУСТЕРУ',
    slotHiddenLabel: (idx) => `Слот скрыт #${idx}`,
    revealCardBtn: 'Открыть →',
    inspectCardTooltip: 'Осмотреть карту',

    myDeckHeader: (sel, owned, total) =>
      `МОЯ БОЕВАЯ КОЛОДА (${sel}/3) • ОТКРЫТО КАРТ: ${owned}/${total}`,
    myDeckSubheader: 'Выберите 3 карты для дуэли в Арене Боя',
    all103CardsBtn: 'Все 103 карты',
    autoPickTop3Btn: 'Автовыбор топ-3',
    hideDeckPanelBtn: 'Скрыть',
    showDeckPanelBtn: 'Показать колоду',
    noCardsOwnedTitle: 'У вас пока нет открытых карт в коллекции',
    noCardsOwnedSubtitle:
      'Перейдите во вкладку «БУСТЕРЫ», чтобы открыть свои 3 стартовых пака и собрать колоду!',
    goToBoostersBtn: 'Перейти к бустерам',

    arenaMenuBadge: 'SUPABASE REALTIME PVP',
    arenaMenuTitle: 'ВЫБОР РЕЖИМА БОЯ',
    arenaMenuSubtitle: 'Сразитесь с реальным игроком онлайн, создайте комнату по коду или тренируйтесь с AI',
    quickMatchBtn: 'БЫСТРЫЙ ПОИСК (PvP)',
    quickMatchDesc: 'Поиск реального соперника (50 сек, затем авто-переход к AI)',
    createLobbyBtn: 'СОЗДАТЬ ЛОББИ',
    enterCodeBtn: 'ВВОД КОДА',
    aiTrainingBtn: 'ТРЕНИРОВКА С AI',
    aiTrainingDesc: 'Мгновенный 3-раундовый матч против кибер-оппонента',
    searchingOpponentTitle: 'ПОИСК ОНЛАЙН-СОПЕРНИКА...',
    searchingCountdownLabel: (sec) => `Ожидание игрока: ${sec} сек`,
    opponentNotFoundAiFallback: 'Соперник не найден. Запуск тренировочного AI...',
    roomCodeCreatedMsg: (code) => `Код комнаты: ${code}. Ожидание соперника...`,
    enterFriendCodePlaceholder: 'Введите 4-значный код комнаты',
    joinRoomSubmitBtn: 'ВОЙТИ В МАТЧ',
    cancelSearchBtn: 'ОТМЕНА',
    roomNotFoundError: 'Комната с таким кодом не найдена или уже занята',
    waitingForOpponentMove: 'КАРТА ВЫБРАНА • ОЖИДАНИЕ ХОДА СОПЕРНИКА...',

    youLabel: 'YOU',
    opponentLabel: 'ОППОНЕНТ',
    roundCounter: (r) => `РАУНД ${r}/3`,
    matchFinalLabel: 'ФИНАЛ МАТЧА',
    countdownReadyLabel: 'ПРИГОТОВЬТЕСЬ',
    nextRoundBannerText: 'СЛЕДУЮЩИЙ РАУНД',
    turnTimerLabel: (s) => `ВРЕМЯ НА ХОД: ${s}с`,
    autoMoveNotice: 'ВРЕМЯ ВЫШЛО — АВТОМАТИЧЕСКИЙ ХОД!',
    roundReviewPauseLabel: (s) => `СЛЕДУЮЩИЙ РАУНД ЧЕРЕЗ: ${s}с`,
    nextRoundNowBtn: 'Далее →',
    chooseCardPrompt: (r, mod) => `РАУНД ${r}: ${mod.toUpperCase()} — ВЫБЕРИТЕ КАРТУ ДЛЯ ХОДА`,
    playCardAction: 'В ход →',
    roundWonMsg: (r, p, e, fast) =>
      `РАУНД ${r} ВЗЯТ! (★${p} против ★${e}) ${fast ? '• Пинг быстрее!' : ''}`,
    roundLostMsg: (r, p, e) => `РАУНД ${r} ПРОИГРАН (★${p} против ★${e})`,
    roundWonByPingMsg: (r, pPing, ePing) =>
      `РАУНД ${r} ВЗЯТ ПО ПИНГУ! (${pPing}ms против ${ePing}ms)`,
    roundLostByPingMsg: (r, pPing, ePing) =>
      `РАУНД ${r} УСТУПЛЕН ПО ПИНГУ (${pPing}ms против ${ePing}ms)`,
    roundDrawMsg: (r, pow) => `НИЧЬЯ В РАУНДЕ ${r} (★${pow} = ★${pow})`,
    reasonHigherPower: (pPow, bonus, ePow, faster) =>
      `Сила ★${pPow}${bonus ? ' (+2 бонус)' : ''} > ★${ePow}${faster ? ' · Пинг быстрее!' : ''}`,
    reasonEnemyHigherPower: (ePow, bonus, pPow) =>
      `Сила ОППОНЕНТА ★${ePow}${bonus ? ' (+2 бонус)' : ''} > ★${pPow}`,
    reasonFasterPing: (pow, pPing, ePing) =>
      `Равная сила ★${pow}, но ваш пинг быстрее (${pPing}ms < ${ePing}ms)!`,
    reasonEnemyFasterPing: (pow, ePing, pPing) =>
      `Равная сила ★${pow}, но пинг ОППОНЕНТА быстрее (${ePing}ms < ${pPing}ms)`,
    reasonExactTie: (pow, ping) => `Абсолютное равенство силы ★${pow} и пинга ${ping}ms`,
    matchVictoryStatus: 'ПОБЕДА В МАТЧЕ! (+25 RP)',
    matchDefeatStatus: 'ФИНАЛ МАТЧА: ПОРАЖЕНИЕ (-15 RP)',
    matchDrawStatus: 'БОЕВАЯ НИЧЬЯ В МАТЧЕ! (+5 RP)',

    modStandardTitle: 'Стандартный MEV-блок',
    modStandardRule: 'Прямое сравнение базовой силы ★ (при равенстве решает меньший Ping ms)',
    modLowLatencyTitle: 'Арбитраж низкой задержки',
    modLowLatencyRule: 'Бонус +2 ★ к силе слотам с Ping < 100 ms',
    modTurboSpeedTitle: 'Турбо-пропускная способность',
    modTurboSpeedRule: 'Бонус +2 ★ к силе слотам со Speed Boost ≥ 4.0x',
    modHighBidTitle: 'Приоритетный MEV-аукцион',
    modHighBidRule: 'Бонус +2 ★ к силе слотам с Bid Uplift ≥ 1.0%',

    postBattleBadge: 'ИТОГИ 3-РАУНДОВОЙ ДУЭЛИ',
    postBattleVictory: 'ПОБЕДА В МАТЧЕ',
    postBattleDefeat: 'ПОРАЖЕНИЕ В МАТЧЕ',
    postBattleDraw: 'БОЕВАЯ НИЧЬЯ',
    ratingChangeLabel: 'ИЗМЕНЕНИЕ РЕЙТИНГА',
    bonusBoosterEarnedMsg: '3/3 ПОБЕД! НАЧИСЛЕН +1 БОНУСНЫЙ БУСТЕР-ПАК!',
    downloadPngPoster: 'PNG Постер',
    shareOnXBtn: 'ПОДЕЛИТЬСЯ В X',
    returnToMainMenuBtn: 'В ГЛАВНОЕ МЕНЮ',

    rankingHeader: 'ТАБЛИЦА ЛИДЕРОВ РЕЙТИНГА (RP)',
    rankColumnTitle: 'Звание',
    youBadge: 'ВЫ',
    arenaWinsCount: (w) => `Побед в арене: ${w}`,

    catalogHeader: (total) => `База карт Turbo-Charging (${total} в игре)`,
    discoveredStat: (d, t, pct) => `Открыто: ${d}/${t} (${pct}%)`,
    ratingStat: (rp) => `Рейтинг: ★ ${rp} RP`,
    winsStat: (w) => `Побед: ${w}`,
    cardsFolderBtn: 'Папка cards',
    cardFileLabel: 'Карточка:',
    statSlotPower: 'Сила слота:',
    statLatency: 'Задержка (Ping):',
    statSpeedBoost: 'Speed Boost:',
    statBidUplift: 'Bid Uplift:',
    packsOpenedLabel: 'Вскрыто паков',
    winStreakLabel: (s) => `${s} подряд`,
    searchPlaceholder: 'Поиск по слоту или card_XXX.png...',
    filterDiscoveredBtn: (c) => `Открытые (${c})`,
    filterAllBtn: (c) => `Все (${c})`,
    noCardsFoundMsg: 'По выбранному фильтру слотов не найдено.',

    rulesBtnLabel: '📜 Правила & Формула',
    rulesModalTitle: '📜 ПРАВИЛА ИГРЫ И ФОРМУЛА БОЯ',
    rulesSec1Title: '1. СУТЬ МАТЧА (3 РАУНДА):',
    rulesSec1Bullet1: 'Матч длится до победы в 2 из 3 раундов (формат Best of 3).',
    rulesSec1Bullet2: 'Перед началом боя вы выбираете 3 карты из своей колоды.',
    rulesSec1Bullet3:
      'Каждый раунд — это «слепой майндгейм»: вы и оппонент одновременно и вслепую выкладываете по 1 карте. Карты вскрываются одновременно.',
    rulesSec2Title: '2. ФОРМУЛА СИЛЫ КАРТЫ (POWER):',
    rulesSec2Intro:
      'Каждая карта имеет итоговую Силу от 1 до 10, которая рассчитывается по формуле:',
    rulesSec2Formula:
      '⭐ Power = round( (Speed Boost × 1.5) + ((150 - Latency) / 20) + (Bid Uplift / 2) )',
    rulesSec2Bullet1: 'Чем выше Speed Boost и Bid Uplift, тем сильнее карта.',
    rulesSec2Bullet2: 'Чем ниже Latency (пинг), тем лучше для вас!',
    rulesSec3Title: '3. ПРАВИЛА РАЗРЕШЕНИЯ СПОРОВ (НИЧЬЯ):',
    rulesSec3Bullet1:
      'Если у обеих карт одинаковая итоговая Сила (например, ★8 и ★8), вступает в силу правило тай-брейка (Tie-Breaker).',
    rulesSec3Bullet2:
      'Победителем раунда автоматически становится тот, у кого ниже задержка (Latency / пинг), так как его валидатор сработал быстрее в сети Ethereum!',
    rulesCloseBtn: 'ПОНЯТНО',
  },

  EN: {
    brandLogo: 'Turbo-Charging',
    loginBadge: 'TURBO-CHARGING // SUPABASE CLOUD',
    loginTitle: 'PLAYER AUTHORIZATION',
    loginSubtitle:
      'Sign in or create a new profile in 1 click. New players receive 3 starter booster packs and ★ 1,000 RP.',
    nicknameLabel: 'Login (Nickname)',
    nicknamePlaceholder: 'e.g. CyberValidator',
    passwordLabel: 'Password',
    passwordPlaceholder: '••••••••',
    loginSubmitBtn: 'SIGN IN / CREATE',
    loginLoadingBtn: 'CONNECTING TO SUPABASE...',
    errEnterNickname: 'Please enter a nickname',
    errEnterPassword: 'Please enter a password',
    errWrongPassword: 'Incorrect password for this nickname',

    uploadAvatarHint: 'Click to upload custom avatar',
    collectionCount: 'Collection',
    winsCount: 'Wins',
    nextFreePackIn: 'Next free pack in:',
    winsToBonusBooster: 'Wins to bonus booster:',
    catalogBtn: 'Cards',
    muteTooltip: 'Mute Audio',
    unmuteTooltip: 'Unmute Audio',
    logoutTooltip: 'Switch Account / Log Out',
    dropCardsTitle: 'Drop the "cards" folder or card PNG files here',
    dropCardsSubtitle: 'All card_002.png ... card_104.png textures will automatically apply to 3D cards',

    tabBoosters: 'BOOSTERS',
    tabMyDeck: 'MY DECK',
    tabBattleArena: 'BATTLE ARENA',
    tabRanking: 'RANKING',

    boosterPedestalTitle: 'VALIDATOR BOOSTER PACK',
    boosterSwipeOrClickHint: 'Swipe across the top of the booster or click the button to open',
    openPackBtn: (count) => `OPEN PACK (Available: ${count})`,
    noPacksAvailableBtn: (timer) => `OPEN PACK (0) • ${timer}`,
    packTornPrompt: 'PACK OPENED! TAP CARDS IN 3D OR BELOW TO REVEAL',
    allCardsAddedPrompt: 'ALL 3 CARDS SAVED TO DATABASE! OPEN ANOTHER PACK OR BUILD YOUR DECK',
    openAll3Btn: 'Reveal All (3)',
    openNextPackBtn: (count) => `OPEN PACK (Available: ${count})`,
    backToPedestalBtn: 'BACK TO BOOSTER',
    slotHiddenLabel: (idx) => `Hidden Slot #${idx}`,
    revealCardBtn: 'Reveal →',
    inspectCardTooltip: 'Inspect Card',

    myDeckHeader: (sel, owned, total) =>
      `MY COMBAT DECK (${sel}/3) • DISCOVERED: ${owned}/${total}`,
    myDeckSubheader: 'Select 3 cards for your combat deck',
    all103CardsBtn: 'All 103 Cards',
    autoPickTop3Btn: 'Auto-Pick Top 3',
    hideDeckPanelBtn: 'Hide',
    showDeckPanelBtn: 'Show Deck',
    noCardsOwnedTitle: 'Your card collection is currently empty',
    noCardsOwnedSubtitle:
      'Go to the BOOSTERS tab to open your 3 starter packs and collect validator cards!',
    goToBoostersBtn: 'Go to Boosters',

    arenaMenuBadge: 'SUPABASE REALTIME PVP',
    arenaMenuTitle: 'SELECT BATTLE MODE',
    arenaMenuSubtitle: 'Challenge a real player online, create a private code lobby, or train against AI',
    quickMatchBtn: 'QUICK MATCH (PvP)',
    quickMatchDesc: 'Matchmake with a live opponent (50s timer with AI fallback)',
    createLobbyBtn: 'CREATE LOBBY',
    enterCodeBtn: 'ENTER CODE',
    aiTrainingBtn: 'AI TRAINING',
    aiTrainingDesc: 'Instant 3-round duel against the cyber opponent',
    searchingOpponentTitle: 'SEARCHING FOR ONLINE OPPONENT...',
    searchingCountdownLabel: (sec) => `Waiting for player: ${sec}s`,
    opponentNotFoundAiFallback: 'Opponent not found. Launching training AI...',
    roomCodeCreatedMsg: (code) => `Room Code: ${code}. Waiting for opponent...`,
    enterFriendCodePlaceholder: 'Enter 4-character room code',
    joinRoomSubmitBtn: 'JOIN MATCH',
    cancelSearchBtn: 'CANCEL',
    roomNotFoundError: 'Room with this code was not found or is already full',
    waitingForOpponentMove: 'CARD LOCKED • WAITING FOR OPPONENT MOVE...',

    youLabel: 'YOU',
    opponentLabel: 'OPPONENT',
    roundCounter: (r) => `ROUND ${r}/3`,
    matchFinalLabel: 'MATCH FINAL',
    countdownReadyLabel: 'GET READY',
    nextRoundBannerText: 'NEXT ROUND',
    turnTimerLabel: (s) => `TURN TIMER: ${s}s`,
    autoMoveNotice: 'TIME EXPIRED — AUTO-PLAYING CARD!',
    roundReviewPauseLabel: (s) => `NEXT ROUND IN: ${s}s`,
    nextRoundNowBtn: 'Continue →',
    chooseCardPrompt: (r, mod) => `ROUND ${r}: ${mod.toUpperCase()} — SELECT A CARD TO PLAY`,
    playCardAction: 'Play →',
    roundWonMsg: (r, p, e, fast) =>
      `ROUND ${r} WON! (★${p} vs ★${e}) ${fast ? '• Faster Ping!' : ''}`,
    roundLostMsg: (r, p, e) => `ROUND ${r} LOST (★${p} vs ★${e})`,
    roundWonByPingMsg: (r, pPing, ePing) =>
      `ROUND ${r} WON BY PING! (${pPing}ms vs ${ePing}ms)`,
    roundLostByPingMsg: (r, pPing, ePing) =>
      `ROUND ${r} LOST BY PING (${pPing}ms vs ${ePing}ms)`,
    roundDrawMsg: (r, pow) => `ROUND ${r} DRAW (★${pow} = ★${pow})`,
    reasonHigherPower: (pPow, bonus, ePow, faster) =>
      `Power ★${pPow}${bonus ? ' (+2 bonus)' : ''} > ★${ePow}${faster ? ' · Faster Ping!' : ''}`,
    reasonEnemyHigherPower: (ePow, bonus, pPow) =>
      `Opponent Power ★${ePow}${bonus ? ' (+2 bonus)' : ''} > ★${pPow}`,
    reasonFasterPing: (pow, pPing, ePing) =>
      `Tied Power ★${pow}, your Latency is faster (${pPing}ms < ${ePing}ms)!`,
    reasonEnemyFasterPing: (pow, ePing, pPing) =>
      `Tied Power ★${pow}, Opponent Latency is faster (${ePing}ms < ${pPing}ms)`,
    reasonExactTie: (pow, ping) => `Exact tie in Power ★${pow} and Latency ${ping}ms`,
    matchVictoryStatus: 'MATCH VICTORY! (+25 RP)',
    matchDefeatStatus: 'MATCH FINAL: DEFEAT (-15 RP)',
    matchDrawStatus: 'COMBAT DRAW! (+5 RP)',

    modStandardTitle: 'Standard MEV Block',
    modStandardRule: 'Direct base Power ★ comparison (lower Ping ms breaks ties)',
    modLowLatencyTitle: 'Low-Latency Arbitrage',
    modLowLatencyRule: '+2 ★ Power bonus to slots with Ping < 100 ms',
    modTurboSpeedTitle: 'Turbo Throughput',
    modTurboSpeedRule: '+2 ★ Power bonus to slots with Speed Boost ≥ 4.0x',
    modHighBidTitle: 'Priority MEV Auction',
    modHighBidRule: '+2 ★ Power bonus to slots with Bid Uplift ≥ 1.0%',

    postBattleBadge: '3-ROUND DUEL RESULTS',
    postBattleVictory: 'MATCH VICTORY',
    postBattleDefeat: 'MATCH DEFEAT',
    postBattleDraw: 'COMBAT DRAW',
    ratingChangeLabel: 'RATING CHANGE',
    bonusBoosterEarnedMsg: '3/3 WINS! +1 BONUS BOOSTER PACK AWARDED!',
    downloadPngPoster: 'PNG Poster',
    shareOnXBtn: 'SHARE ON X',
    returnToMainMenuBtn: 'MAIN MENU',

    rankingHeader: 'TOP PLAYERS LEADERBOARD (RP)',
    rankColumnTitle: 'Tier',
    youBadge: 'YOU',
    arenaWinsCount: (w) => `Arena Wins: ${w}`,

    catalogHeader: (total) => `Turbo-Charging Card Database (${total} Cards)`,
    discoveredStat: (d, t, pct) => `Discovered: ${d}/${t} (${pct}%)`,
    ratingStat: (rp) => `Rating: ★ ${rp} RP`,
    winsStat: (w) => `Wins: ${w}`,
    cardsFolderBtn: 'Folder "cards"',
    cardFileLabel: 'Card Asset:',
    statSlotPower: 'Slot Power:',
    statLatency: 'Latency (Ping):',
    statSpeedBoost: 'Speed Boost:',
    statBidUplift: 'Bid Uplift:',
    packsOpenedLabel: 'Packs Opened',
    winStreakLabel: (s) => `${s} Win Streak`,
    searchPlaceholder: 'Search by Slot or card_XXX.png...',
    filterDiscoveredBtn: (c) => `Discovered (${c})`,
    filterAllBtn: (c) => `All (${c})`,
    noCardsFoundMsg: 'No cards match the selected filter.',

    rulesBtnLabel: '📜 Rules & Formula',
    rulesModalTitle: '📜 GAME RULES & COMBAT FORMULA',
    rulesSec1Title: '1. MATCH FORMAT (3 ROUNDS):',
    rulesSec1Bullet1: 'Matches are played up to 2 wins out of 3 rounds (Best of 3 format).',
    rulesSec1Bullet2: 'Before entering battle, you select 3 cards from your deck.',
    rulesSec1Bullet3:
      'Every round is a "blind mindgame": you and your opponent simultaneously and blindly play 1 card each. Both cards are revealed at the same time.',
    rulesSec2Title: '2. CARD POWER FORMULA (POWER):',
    rulesSec2Intro:
      'Each card has a total Power rating from 1 to 10, calculated via the formula:',
    rulesSec2Formula:
      '⭐ Power = round( (Speed Boost × 1.5) + ((150 - Latency) / 20) + (Bid Uplift / 2) )',
    rulesSec2Bullet1: 'Higher Speed Boost and Bid Uplift make the card stronger.',
    rulesSec2Bullet2: 'Lower Latency (ping) gives you a decisive edge!',
    rulesSec3Title: '3. TIE-BREAKER RULES (DRAW RESOLUTION):',
    rulesSec3Bullet1:
      'If both played cards have the exact same Power (e.g. ★8 and ★8), the Tie-Breaker rule is triggered.',
    rulesSec3Bullet2:
      'The round is automatically won by the player with lower Latency (ping), as their validator executed faster on the Ethereum network!',
    rulesCloseBtn: 'GOT IT',
  },

  KO: {
    brandLogo: 'Turbo-Charging',
    loginBadge: 'TURBO-CHARGING // SUPABASE CLOUD',
    loginTitle: '플레이어 로그인',
    loginSubtitle:
      '원클릭으로 로그인하거나 새 프로필을 생성하세요. 신규 플레이어에게는 스타터 부스터 팩 3개와 ★ 1,000 RP가 지급됩니다.',
    nicknameLabel: '로그인 ID (닉네임)',
    nicknamePlaceholder: '예: CyberValidator',
    passwordLabel: '비밀번호',
    passwordPlaceholder: '••••••••',
    loginSubmitBtn: '로그인 / 계정 생성',
    loginLoadingBtn: 'SUPABASE 연결 중...',
    errEnterNickname: '닉네임을 입력해주세요',
    errEnterPassword: '비밀번호를 입력해주세요',
    errWrongPassword: '비밀번호가 일치하지 않습니다',

    uploadAvatarHint: '클릭하여 커스텀 아바타 업로드',
    collectionCount: '컬렉션',
    winsCount: '승리',
    nextFreePackIn: '다음 무료 팩까지:',
    winsToBonusBooster: '보너스 부스터까지 승리:',
    catalogBtn: '도감',
    muteTooltip: '음소거',
    unmuteTooltip: '소리 켜기',
    logoutTooltip: '계정 전환 / 로그아웃',
    dropCardsTitle: '"cards" 폴더 또는 PNG 카드 파일을 여기에 드롭하세요',
    dropCardsSubtitle: 'card_002.png ... card_104.png 텍스처가 3D 카드에 즉시 적용됩니다',

    tabBoosters: '부스터 팩',
    tabMyDeck: '나의 덱',
    tabBattleArena: '배틀 아레나',
    tabRanking: '랭킹',

    boosterPedestalTitle: '밸리데이터 부스터 팩',
    boosterSwipeOrClickHint: '부스터 상단을 스와이프하거나 버튼을 눌러 팩을 개봉하세요',
    openPackBtn: (count) => `팩 개봉 (보유: ${count})`,
    noPacksAvailableBtn: (timer) => `팩 개봉 (0) • ${timer}`,
    packTornPrompt: '부스터 개봉 완료! 3D 카드나 하단 슬롯을 탭하여 뒤집으세요',
    allCardsAddedPrompt: '카드 3장이 데이터베이스에 저장되었습니다! 다음 팩을 열거나 덱을 구성하세요',
    openAll3Btn: '모두 뒤집기 (3)',
    openNextPackBtn: (count) => `팩 개봉 (보유: ${count})`,
    backToPedestalBtn: '부스터로 돌아가기',
    slotHiddenLabel: (idx) => `숨겨진 슬롯 #${idx}`,
    revealCardBtn: '열기 →',
    inspectCardTooltip: '카드 상세보기',

    myDeckHeader: (sel, owned, total) =>
      `나의 배틀 덱 (${sel}/3) • 수집한 카드: ${owned}/${total}`,
    myDeckSubheader: '배틀 아레나에 사용할 카드 3장을 선택하세요',
    all103CardsBtn: '전체 103장 보기',
    autoPickTop3Btn: '상위 3장 자동선택',
    hideDeckPanelBtn: '숨기기',
    showDeckPanelBtn: '덱 패널 열기',
    noCardsOwnedTitle: '아직 수집한 카드가 없습니다',
    noCardsOwnedSubtitle:
      '부스터 팩 탭으로 이동해 스타터 부스터 3개를 개봉하고 카드를 획득하세요!',
    goToBoostersBtn: '부스터 탭으로 이동',

    arenaMenuBadge: 'SUPABASE REALTIME PVP',
    arenaMenuTitle: '배틀 모드 선택',
    arenaMenuSubtitle: '실시간 온라인 PvP 매칭, 코드 로비 생성 또는 AI 트레이닝을 선택하세요',
    quickMatchBtn: '빠른 매칭 (PvP)',
    quickMatchDesc: '실제 플레이어 검색 (50초 대기 후 AI 자동 전환)',
    createLobbyBtn: '로비 생성',
    enterCodeBtn: '코드 입력',
    aiTrainingBtn: 'AI 트레이닝',
    aiTrainingDesc: '사이버 상대를 대상으로 즉시 3라운드 듀얼 시작',
    searchingOpponentTitle: '온라인 상대 검색 중...',
    searchingCountdownLabel: (sec) => `플레이어 대기 시간: ${sec}초`,
    opponentNotFoundAiFallback: '상대를 찾지 못했습니다. 트레이닝 AI를 시작합니다...',
    roomCodeCreatedMsg: (code) => `방 코드: ${code}. 상대를 기다리는 중...`,
    enterFriendCodePlaceholder: '4자리 방 코드를 입력하세요',
    joinRoomSubmitBtn: '매치 입장',
    cancelSearchBtn: '취소',
    roomNotFoundError: '해당 코드의 방을 찾을 수 없거나 이미 시작되었습니다',
    waitingForOpponentMove: '카드 선택 완료 • 상대방의 선택을 기다리는 중...',

    youLabel: 'YOU',
    opponentLabel: '상대방',
    roundCounter: (r) => `라운드 ${r}/3`,
    matchFinalLabel: '매치 종료',
    countdownReadyLabel: '라운드 시작',
    nextRoundBannerText: '다음 라운드',
    turnTimerLabel: (s) => `선택 제한시간: ${s}초`,
    autoMoveNotice: '시간 초과 — 자동으로 카드를 제출합니다!',
    roundReviewPauseLabel: (s) => `다음 라운드까지: ${s}초`,
    nextRoundNowBtn: '계속하기 →',
    chooseCardPrompt: (r, mod) => `라운드 ${r}: ${mod} — 출전할 카드를 선택하세요`,
    playCardAction: '출전 →',
    roundWonMsg: (r, p, e, fast) =>
      `라운드 ${r} 승리! (★${p} vs ★${e}) ${fast ? '• 더 빠른 핑!' : ''}`,
    roundLostMsg: (r, p, e) => `라운드 ${r} 패배 (★${p} vs ★${e})`,
    roundWonByPingMsg: (r, pPing, ePing) =>
      `라운드 ${r} 핑 우위로 승리! (${pPing}ms vs ${ePing}ms)`,
    roundLostByPingMsg: (r, pPing, ePing) =>
      `라운드 ${r} 핑 차이로 패배 (${pPing}ms vs ${ePing}ms)`,
    roundDrawMsg: (r, pow) => `라운드 ${r} 무승부 (★${pow} = ★${pow})`,
    reasonHigherPower: (pPow, bonus, ePow, faster) =>
      `파워 ★${pPow}${bonus ? ' (+2 보너스)' : ''} > ★${ePow}${faster ? ' · 핑 우위!' : ''}`,
    reasonEnemyHigherPower: (ePow, bonus, pPow) =>
      `상대 파워 ★${ePow}${bonus ? ' (+2 보너스)' : ''} > ★${pPow}`,
    reasonFasterPing: (pow, pPing, ePing) =>
      `동일 파워 ★${pow}, 더 빠른 지연시간 (${pPing}ms < ${ePing}ms)!`,
    reasonEnemyFasterPing: (pow, ePing, pPing) =>
      `동일 파워 ★${pow}, 상대 지연시간이 더 빠름 (${ePing}ms < ${pPing}ms)`,
    reasonExactTie: (pow, ping) => `파워 ★${pow} 및 지연시간 ${ping}ms 완전 동률`,
    matchVictoryStatus: '매치 최종 승리! (+25 RP)',
    matchDefeatStatus: '매치 종료: 패배 (-15 RP)',
    matchDrawStatus: '매치 무승부! (+5 RP)',

    modStandardTitle: '표준 MEV 블록',
    modStandardRule: '기본 파워 ★ 직접 비교 (동점 시 더 낮은 Ping ms 승리)',
    modLowLatencyTitle: '저지연 아비트라지',
    modLowLatencyRule: 'Ping < 100 ms 슬롯에 파워 +2 ★ 보너스',
    modTurboSpeedTitle: '터보 처리량',
    modTurboSpeedRule: 'Speed Boost ≥ 4.0x 슬롯에 파워 +2 ★ 보너스',
    modHighBidTitle: '우선순위 MEV 경매',
    modHighBidRule: 'Bid Uplift ≥ 1.0% 슬롯에 파워 +2 ★ 보너스',

    postBattleBadge: '3라운드 듀얼 결과',
    postBattleVictory: '매치 승리',
    postBattleDefeat: '매치 패배',
    postBattleDraw: '매치 무승부',
    ratingChangeLabel: '레이팅 변동',
    bonusBoosterEarnedMsg: '3/3 승리 달성! +1 보너스 부스터 팩 지급!',
    downloadPngPoster: 'PNG 포스터',
    shareOnXBtn: 'X에 공유하기',
    returnToMainMenuBtn: '메인 메뉴로',

    rankingHeader: '톱 플레이어 랭킹 (RP)',
    rankColumnTitle: '티어',
    youBadge: '나',
    arenaWinsCount: (w) => `아레나 승리: ${w}`,

    catalogHeader: (total) => `Turbo-Charging 카드 데이터베이스 (${total}장)`,
    discoveredStat: (d, t, pct) => `수집률: ${d}/${t} (${pct}%)`,
    ratingStat: (rp) => `레이팅: ★ ${rp} RP`,
    winsStat: (w) => `승리: ${w}`,
    cardsFolderBtn: 'cards 폴더',
    cardFileLabel: '카드 파일:',
    statSlotPower: '슬롯 파워:',
    statLatency: '지연시간 (Latency):',
    statSpeedBoost: '속도 부스트 (Speed Boost):',
    statBidUplift: '입찰 상승 (Bid Uplift):',
    packsOpenedLabel: '개봉한 팩',
    winStreakLabel: (s) => `${s}연승`,
    searchPlaceholder: '슬롯 번호 또는 card_XXX.png 검색...',
    filterDiscoveredBtn: (c) => `보유 중 (${c})`,
    filterAllBtn: (c) => `전체 (${c})`,
    noCardsFoundMsg: '선택한 필터와 일치하는 카드가 없습니다.',

    rulesBtnLabel: '📜 규칙 & 공식',
    rulesModalTitle: '📜 게임 규칙 및 전투 공식',
    rulesSec1Title: '1. 매치 방식 (3 라운드):',
    rulesSec1Bullet1: '매치는 3판 2선승제(Best of 3) 방식으로 진행됩니다.',
    rulesSec1Bullet2: '전투 시작 전 나의 덱에서 3장의 카드를 선택합니다.',
    rulesSec1Bullet3:
      '매 라운드는 "블라인드 심리전"입니다: 플레이어와 상대방이 동시에 비공개로 카드 1장씩을 내고 동시에 공개합니다.',
    rulesSec2Title: '2. 카드 파워 계산 공식 (POWER):',
    rulesSec2Intro:
      '각 카드는 1에서 10까지의 최종 파워를 가지며 다음 공식으로 계산됩니다:',
    rulesSec2Formula:
      '⭐ Power = round( (Speed Boost × 1.5) + ((150 - Latency) / 20) + (Bid Uplift / 2) )',
    rulesSec2Bullet1: 'Speed Boost와 Bid Uplift가 높을수록 카드가 강력해집니다.',
    rulesSec2Bullet2: 'Latency(핑)가 낮을수록 훨씬 유리합니다!',
    rulesSec3Title: '3. 동점 시 타이브레이커 규칙 (무승부 판정):',
    rulesSec3Bullet1:
      '두 카드의 최종 파워가 동일할 경우(예: ★8 대 ★8) 타이브레이커 규칙이 적용됩니다.',
    rulesSec3Bullet2:
      '이더리움 네트워크에서 밸리데이터가 더 빠르게 작동한 쪽, 즉 지연시간(Latency / 핑)이 더 낮은 플레이어가 자동으로 라운드에서 승리합니다!',
    rulesCloseBtn: '확인',
  },

  VI: {
    brandLogo: 'Turbo-Charging',
    loginBadge: 'TURBO-CHARGING // SUPABASE CLOUD',
    loginTitle: 'ĐĂNG NHẬP NGƯỜI CHƠI',
    loginSubtitle:
      'Đăng nhập hoặc tạo hồ sơ mới chỉ với 1 cú nhấp. Người chơi mới nhận ngay 3 gói Booster khởi đầu và ★ 1,000 RP.',
    nicknameLabel: 'Tên đăng nhập (Biệt danh)',
    nicknamePlaceholder: 'VD: CyberValidator',
    passwordLabel: 'Mật khẩu',
    passwordPlaceholder: '••••••••',
    loginSubmitBtn: 'ĐĂNG NHẬP / TẠO MỚI',
    loginLoadingBtn: 'ĐANG KẾT NỐI SUPABASE...',
    errEnterNickname: 'Vui lòng nhập biệt danh',
    errEnterPassword: 'Vui lòng nhập mật khẩu',
    errWrongPassword: 'Mật khẩu không đúng cho biệt danh này',

    uploadAvatarHint: 'Nhấn để tải ảnh đại diện',
    collectionCount: 'Bộ sưu tập',
    winsCount: 'Thắng',
    nextFreePackIn: 'Gói miễn phí tiếp theo:',
    winsToBonusBooster: 'Thắng để nhận gói thưởng:',
    catalogBtn: 'Kho thẻ',
    muteTooltip: 'Tắt tiếng',
    unmuteTooltip: 'Bật tiếng',
    logoutTooltip: 'Đổi tài khoản / Đăng xuất',
    dropCardsTitle: 'Thả thư mục "cards" hoặc file PNG vào đây',
    dropCardsSubtitle: 'Tất cả ảnh card_002.png ... card_104.png sẽ tự động áp dụng lên thẻ 3D',

    tabBoosters: 'GÓI BOOSTER',
    tabMyDeck: 'BỘ BÀI',
    tabBattleArena: 'ĐẤU TRƯỜNG',
    tabRanking: 'XẾP HẠNG',

    boosterPedestalTitle: 'GÓI BOOSTER VALIDATOR',
    boosterSwipeOrClickHint: 'Vuốt ngang phần trên gói hoặc nhấn nút để mở gói',
    openPackBtn: (count) => `MỞ GÓI (Còn: ${count})`,
    noPacksAvailableBtn: (timer) => `MỞ GÓI (0) • ${timer}`,
    packTornPrompt: 'ĐÃ MỞ GÓI! CHẠM VÀO THẺ 3D HOẶC BÊN DƯỚI ĐỂ LẬT',
    allCardsAddedPrompt: 'ĐÃ LƯU 3 THẺ VÀO CƠ SỞ DỮ LIỆU! MỞ TIẾP HOẶC XẾP BỘ BÀI',
    openAll3Btn: 'Lật tất cả (3)',
    openNextPackBtn: (count) => `MỞ GÓI (Còn: ${count})`,
    backToPedestalBtn: 'QUAY LẠI BỆ BOOSTER',
    slotHiddenLabel: (idx) => `Thẻ ẩn #${idx}`,
    revealCardBtn: 'Lật mở →',
    inspectCardTooltip: 'Xem chi tiết thẻ',

    myDeckHeader: (sel, owned, total) =>
      `BỘ BÀI CHIẾN ĐẤU (${sel}/3) • ĐÃ SỞ HỮU: ${owned}/${total}`,
    myDeckSubheader: 'Chọn 3 thẻ bài mạnh nhất để vào Đấu Trường',
    all103CardsBtn: 'Tất cả 103 thẻ',
    autoPickTop3Btn: 'Tự chọn Top 3',
    hideDeckPanelBtn: 'Ẩn',
    showDeckPanelBtn: 'Hiện bộ bài',
    noCardsOwnedTitle: 'Bạn chưa có thẻ bài nào trong bộ sưu tập',
    noCardsOwnedSubtitle:
      'Hãy chuyển sang tab GÓI BOOSTER để mở 3 gói khởi đầu và thu thập thẻ bài!',
    goToBoostersBtn: 'Đến Gói Booster',

    arenaMenuBadge: 'SUPABASE REALTIME PVP',
    arenaMenuTitle: 'CHỌN CHẾ ĐỘ ĐẤU',
    arenaMenuSubtitle: 'Tìm đối thủ trực tuyến, tạo phòng bằng mã hoặc luyện tập cùng AI',
    quickMatchBtn: 'TÌM TRẬN NHANH (PvP)',
    quickMatchDesc: 'Ghép trận trực tuyến (50 giây chờ, tự động chuyển sang AI)',
    createLobbyBtn: 'TẠO PHÒNG',
    enterCodeBtn: 'NHẬP MÃ PHÒNG',
    aiTrainingBtn: 'LUYỆN TẬP VỚI AI',
    aiTrainingDesc: 'Đấu 3 hiệp tức thì với đối thủ máy',
    searchingOpponentTitle: 'ĐANG TÌM ĐỐI THỦ TRỰC TUYẾN...',
    searchingCountdownLabel: (sec) => `Đang chờ người chơi: ${sec}s`,
    opponentNotFoundAiFallback: 'Không tìm thấy đối thủ. Đang khởi động AI luyện tập...',
    roomCodeCreatedMsg: (code) => `Mã phòng: ${code}. Đang chờ đối thủ...`,
    enterFriendCodePlaceholder: 'Nhập mã phòng 4 ký tự',
    joinRoomSubmitBtn: 'VÀO PHÒNG',
    cancelSearchBtn: 'HỦY',
    roomNotFoundError: 'Không tìm thấy phòng với mã này hoặc phòng đã đầy',
    waitingForOpponentMove: 'ĐÃ CHỌN THẺ • ĐANG CHỜ ĐỐI THỦ RA ĐÒN...',

    youLabel: 'YOU',
    opponentLabel: 'ĐỐI THỦ',
    roundCounter: (r) => `HIỆP ${r}/3`,
    matchFinalLabel: 'KẾT THÚC TRẬN',
    countdownReadyLabel: 'CHUẨN BỊ',
    nextRoundBannerText: 'HIỆP TIẾP THEO',
    turnTimerLabel: (s) => `THỜI GIAN CHỌN: ${s}s`,
    autoMoveNotice: 'HẾT GIỜ — TỰ ĐỘNG ĐÁNH THẺ!',
    roundReviewPauseLabel: (s) => `HIỆP TIẾP THEO SAU: ${s}s`,
    nextRoundNowBtn: 'Tiếp tục →',
    chooseCardPrompt: (r, mod) => `HIỆP ${r}: ${mod.toUpperCase()} — CHỌN THẺ ĐỂ RA ĐÒN`,
    playCardAction: 'Đánh →',
    roundWonMsg: (r, p, e, fast) =>
      `THẮNG HIỆP ${r}! (★${p} vs ★${e}) ${fast ? '• Ping nhanh hơn!' : ''}`,
    roundLostMsg: (r, p, e) => `THUA HIỆP ${r} (★${p} vs ★${e})`,
    roundWonByPingMsg: (r, pPing, ePing) =>
      `THẮNG HIỆP ${r} NHỜ PING! (${pPing}ms vs ${ePing}ms)`,
    roundLostByPingMsg: (r, pPing, ePing) =>
      `THUA HIỆP ${r} DO PING (${pPing}ms vs ${ePing}ms)`,
    roundDrawMsg: (r, pow) => `HÒA HIỆP ${r} (★${pow} = ★${pow})`,
    reasonHigherPower: (pPow, bonus, ePow, faster) =>
      `Sức mạnh ★${pPow}${bonus ? ' (+2 thưởng)' : ''} > ★${ePow}${
        faster ? ' · Ping nhanh hơn!' : ''
      }`,
    reasonEnemyHigherPower: (ePow, bonus, pPow) =>
      `Sức mạnh Đối thủ ★${ePow}${bonus ? ' (+2 thưởng)' : ''} > ★${pPow}`,
    reasonFasterPing: (pow, pPing, ePing) =>
      `Hòa sức mạnh ★${pow}, nhưng Ping của bạn nhanh hơn (${pPing}ms < ${ePing}ms)!`,
    reasonEnemyFasterPing: (pow, ePing, pPing) =>
      `Hòa sức mạnh ★${pow}, nhưng Ping Đối thủ nhanh hơn (${ePing}ms < ${pPing}ms)`,
    reasonExactTie: (pow, ping) => `Hòa tuyệt đối Sức mạnh ★${pow} và Ping ${ping}ms`,
    matchVictoryStatus: 'CHIẾN THẮNG TRẬN ĐẤU! (+25 RP)',
    matchDefeatStatus: 'KẾT THÚC: THẤT BẠI (-15 RP)',
    matchDrawStatus: 'TRẬN ĐẤU HÒA! (+5 RP)',

    modStandardTitle: 'Khối MEV Tiêu Chuẩn',
    modStandardRule: 'So sánh Sức mạnh ★ trực tiếp (bằng nhau xét Ping ms thấp hơn)',
    modLowLatencyTitle: 'Chênh Lệch Độ Trễ Thấp',
    modLowLatencyRule: 'Cộng +2 ★ Sức mạnh cho thẻ có Latency (Ping) < 100 ms',
    modTurboSpeedTitle: 'Băng Thông Turbo',
    modTurboSpeedRule: 'Cộng +2 ★ Sức mạnh cho thẻ có Speed Boost ≥ 4.0x',
    modHighBidTitle: 'Đấu Giá MEV Ưu Tiên',
    modHighBidRule: 'Cộng +2 ★ Sức mạnh cho thẻ có Bid Uplift ≥ 1.0%',

    postBattleBadge: 'KẾT QUẢ ĐẤU 3 HIỆP',
    postBattleVictory: 'CHIẾN THẮNG',
    postBattleDefeat: 'THẤT BẠI',
    postBattleDraw: 'HÒA TRẬN',
    ratingChangeLabel: 'THAY ĐỔI XẾP HẠNG',
    bonusBoosterEarnedMsg: '3/3 TRẬN THẮNG! NHẬN +1 GÓI BOOSTER THƯỞNG!',
    downloadPngPoster: 'Tải Poster PNG',
    shareOnXBtn: 'CHIA SẺ LÊN X',
    returnToMainMenuBtn: 'MENU CHÍNH',

    rankingHeader: 'BẢNG XẾP HẠNG CAO THỦ (RP)',
    rankColumnTitle: 'Hạng',
    youBadge: 'BẠN',
    arenaWinsCount: (w) => `Thắng Đấu Trường: ${w}`,

    catalogHeader: (total) => `Cơ Sở Dữ Liệu Thẻ Turbo-Charging (${total} Thẻ)`,
    discoveredStat: (d, t, pct) => `Đã mở: ${d}/${t} (${pct}%)`,
    ratingStat: (rp) => `Hạng: ★ ${rp} RP`,
    winsStat: (w) => `Thắng: ${w}`,
    cardsFolderBtn: 'Thư mục cards',
    cardFileLabel: 'Tệp thẻ:',
    statSlotPower: 'Sức mạnh (Power):',
    statLatency: 'Độ trễ (Latency):',
    statSpeedBoost: 'Tăng tốc (Speed Boost):',
    statBidUplift: 'Tăng giá thầu (Bid Uplift):',
    packsOpenedLabel: 'Gói đã mở',
    winStreakLabel: (s) => `Chuỗi ${s} thắng`,
    searchPlaceholder: 'Tìm theo Slot hoặc card_XXX.png...',
    filterDiscoveredBtn: (c) => `Đã mở (${c})`,
    filterAllBtn: (c) => `Tất cả (${c})`,
    noCardsFoundMsg: 'Không tìm thấy thẻ phù hợp với bộ lọc.',

    rulesBtnLabel: '📜 Luật & Công thức',
    rulesModalTitle: '📜 LUẬT CHƠI & CÔNG THỨC CHIẾN ĐẤU',
    rulesSec1Title: '1. THỂ THỨC TRẬN ĐẤU (3 HIỆP):',
    rulesSec1Bullet1: 'Trận đấu diễn ra theo thể thức thắng 2 trên 3 hiệp (Best of 3).',
    rulesSec1Bullet2: 'Trước khi vào trận, bạn chọn 3 thẻ bài từ bộ bài của mình.',
    rulesSec1Bullet3:
      'Mỗi hiệp là một màn "đấu trí mù": bạn và đối thủ đồng thời úp 1 thẻ bài. Cả hai thẻ sẽ được lật mở cùng lúc.',
    rulesSec2Title: '2. CÔNG THỨC SỨC MẠNH THẺ (POWER):',
    rulesSec2Intro:
      'Mỗi thẻ có Sức mạnh tổng từ 1 đến 10, được tính theo công thức:',
    rulesSec2Formula:
      '⭐ Power = round( (Speed Boost × 1.5) + ((150 - Latency) / 20) + (Bid Uplift / 2) )',
    rulesSec2Bullet1: 'Speed Boost và Bid Uplift càng cao, thẻ càng mạnh.',
    rulesSec2Bullet2: 'Latency (ping) càng thấp, lợi thế càng lớn!',
    rulesSec3Title: '3. QUY TẮC PHÂN ĐỊNH HÒA (TIE-BREAKER):',
    rulesSec3Bullet1:
      'Nếu cả hai thẻ có cùng Sức mạnh (ví dụ ★8 và ★8), quy tắc Tie-Breaker sẽ được kích hoạt.',
    rulesSec3Bullet2:
      'Người chiến thắng hiệp đấu sẽ tự động là người có độ trễ (Latency / ping) thấp hơn, vì validator của họ xử lý nhanh hơn trên mạng Ethereum!',
    rulesCloseBtn: 'ĐÃ HIỂU',
  },
};
