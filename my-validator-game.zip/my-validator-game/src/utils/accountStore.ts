import { ValidatorCard } from '../data/cardsData';
import { renderCardFrontToCanvas } from './proceduralTextures';
import { cardImageStore } from './cardImageStore';
import { supabase } from './supabaseClient';

export interface UserProfile {
  id: string;
  nickname: string;
  password: string;
  packsAvailable: number;
  lastPackClaimTime: number;
  winsProgress: number; // 0 to 3
  ratingRP: number;
  avatarUrl: string;
  collection: number[]; // array of opened card IDs
  battleDeck: number[]; // 3 selected card IDs for battle
  matchesWon: number;
  matchesLost: number;
  winStreak: number;
  packsOpened: number;
}

export interface LeaderboardEntry {
  nickname: string;
  ratingRP: number;
  matchesWon: number;
  avatarUrl: string;
  isCurrentUser?: boolean;
}

const ACCOUNTS_STORAGE_KEY = 'optimum_tcg_accounts_v1';
const ACTIVE_USER_KEY = 'optimum_tcg_active_user_v1';
export const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;
export const MAX_DAILY_TIMER_PACKS = 2;

export function generateDefaultCyberMaskAvatar(seedName = 'OPTIMUM'): string {
  let hash = 0;
  for (let i = 0; i < seedName.length; i++) {
    hash = (hash << 5) - hash + seedName.charCodeAt(i);
    hash |= 0;
  }
  const hue = Math.abs(hash) % 360;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#1a1f2e"/>
        <stop offset="50%" stop-color="#090b11"/>
        <stop offset="100%" stop-color="#22293a"/>
      </linearGradient>
      <linearGradient id="chrome" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#f8fafc"/>
        <stop offset="40%" stop-color="#cbd5e1"/>
        <stop offset="70%" stop-color="#64748b"/>
        <stop offset="100%" stop-color="#e2e8f0"/>
      </linearGradient>
      <linearGradient id="visor" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="hsl(${hue}, 85%, 72%)"/>
        <stop offset="50%" stop-color="#ffffff"/>
        <stop offset="100%" stop-color="hsl(${(hue + 60) % 360}, 85%, 72%)"/>
      </linearGradient>
    </defs>
    <rect width="120" height="120" rx="24" fill="url(#bg)"/>
    <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,0.18)" stroke-width="2"/>
    <!-- Cyber Mask Helmet -->
    <path d="M32 42 L46 22 L74 22 L88 42 L84 82 L60 100 L36 82 Z" fill="url(#chrome)" stroke="#ffffff" stroke-width="1.5"/>
    <path d="M38 46 L60 36 L82 46 L78 78 L60 92 L42 78 Z" fill="#0d1018"/>
    <!-- Glowing Visor -->
    <polygon points="36,52 60,58 84,52 80,63 60,68 40,63" fill="url(#visor)"/>
    <!-- Respirator Vent Lines -->
    <line x1="50" y1="74" x2="70" y2="74" stroke="#cbd5e1" stroke-width="2.5" stroke-linecap="round"/>
    <line x1="53" y1="81" x2="67" y2="81" stroke="#94a3b8" stroke-width="2.5" stroke-linecap="round"/>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function loadAllAccounts(): Record<string, UserProfile> {
  try {
    const raw = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw) as Record<string, UserProfile>;
    }
  } catch {
    // ignore
  }
  return {};
}

export function saveAllAccounts(accounts: Record<string, UserProfile>): void {
  try {
    localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
  } catch {
    // ignore
  }
}

export function getActiveSessionNickname(): string | null {
  try {
    return localStorage.getItem(ACTIVE_USER_KEY);
  } catch {
    return null;
  }
}

export function setActiveSessionNickname(nickname: string | null): void {
  try {
    if (nickname) {
      localStorage.setItem(ACTIVE_USER_KEY, nickname);
    } else {
      localStorage.removeItem(ACTIVE_USER_KEY);
    }
  } catch {
    // ignore
  }
}

const PACK_TIMER_PREFIX = 'turbo_pack_timer_v2_';

export function getSavedPackTimerAnchor(nickname: string): number | null {
  try {
    const raw = localStorage.getItem(`${PACK_TIMER_PREFIX}${nickname.toLowerCase()}`);
    if (raw) {
      const parsed = Number(raw);
      if (Number.isFinite(parsed) && parsed > 0) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return null;
}

export function savePackTimerAnchor(nickname: string, timestampMs: number): void {
  try {
    if (Number.isFinite(timestampMs) && timestampMs > 0) {
      localStorage.setItem(
        `${PACK_TIMER_PREFIX}${nickname.toLowerCase()}`,
        String(timestampMs)
      );
    }
  } catch {
    // ignore
  }
}

/**
 * Evaluates 12-hour pack accrual (up to 2 packs accumulated per 24h) strictly against real time.
 * Never resets on page reload.
 */
export function syncPackEconomyTimer(profile: UserProfile, now = Date.now()): {
  updatedProfile: UserProfile;
  msUntilNextPack: number;
} {
  const savedAnchor = getSavedPackTimerAnchor(profile.nickname);
  const anchorTime =
    savedAnchor && savedAnchor > 0
      ? Math.min(savedAnchor, profile.lastPackClaimTime || savedAnchor)
      : profile.lastPackClaimTime > 0
      ? profile.lastPackClaimTime
      : now;

  if (!savedAnchor) {
    savePackTimerAnchor(profile.nickname, anchorTime);
  }

  const elapsed = Math.max(0, now - anchorTime);
  const periodsElapsed = Math.floor(elapsed / TWELVE_HOURS_MS);

  if (periodsElapsed > 0) {
    const packsToGrant = Math.min(MAX_DAILY_TIMER_PACKS, periodsElapsed);
    const newClaimTime = anchorTime + periodsElapsed * TWELVE_HOURS_MS;
    savePackTimerAnchor(profile.nickname, newClaimTime);
    const updated: UserProfile = {
      ...profile,
      packsAvailable: profile.packsAvailable + packsToGrant,
      lastPackClaimTime: newClaimTime,
    };
    const nextElapsed = Math.max(0, now - updated.lastPackClaimTime);
    const msUntilNextPack = Math.max(0, TWELVE_HOURS_MS - (nextElapsed % TWELVE_HOURS_MS));
    return { updatedProfile: updated, msUntilNextPack };
  }

  const msUntilNextPack = Math.max(0, TWELVE_HOURS_MS - elapsed);
  if (profile.lastPackClaimTime !== anchorTime) {
    return {
      updatedProfile: { ...profile, lastPackClaimTime: anchorTime },
      msUntilNextPack,
    };
  }
  return { updatedProfile: profile, msUntilNextPack };
}

export function formatCountdownHMS(ms: number): string {
  const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [
    String(hours).padStart(2, '0'),
    String(minutes).padStart(2, '0'),
    String(seconds).padStart(2, '0'),
  ].join(':');
}

export function formatRatingRP(rp: number): string {
  return rp.toLocaleString('en-US');
}

function generateFallbackUuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (ch) => {
    const r = (Math.random() * 16) | 0;
    const v = ch === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Async Supabase Login or 1-Click Account Creation:
 * Queries `profiles` and `user_cards` in Supabase.
 * If the user does not exist in `profiles`, creates them in 1 click with 3 starter packs and 1000 RP.
 */
export async function loginOrCreateAccountAsync(
  rawNickname: string,
  rawPassword: string
): Promise<{ profile?: UserProfile; error?: string; isNew?: boolean }> {
  const nickname = rawNickname.trim();
  const password = rawPassword.trim();

  if (!nickname) {
    return { error: 'EMPTY_NICKNAME' };
  }
  if (!password) {
    return { error: 'EMPTY_PASSWORD' };
  }

  const accounts = loadAllAccounts();
  const key = nickname.toLowerCase();
  const localExisting = accounts[key];
  const savedTimerAnchor = getSavedPackTimerAnchor(nickname);

  try {
    // 1. Query `profiles` table in Supabase
    const { data: existingRow, error: selectErr } = await supabase
      .from('profiles')
      .select('*')
      .ilike('username', nickname)
      .maybeSingle();

    if (!selectErr && existingRow) {
      if (existingRow.password && existingRow.password !== password) {
        return { error: 'WRONG_PASSWORD' };
      }

      // Fetch user's cards from `user_cards` table in Supabase
      const { data: cardRows } = await supabase
        .from('user_cards')
        .select('card_index')
        .eq('user_id', existingRow.id);

      const dbCardIds = Array.isArray(cardRows)
        ? cardRows.map((r: { card_index: number }) => Number(r.card_index)).filter(Boolean)
        : [];

      const mergedCollection = Array.from(
        new Set([...(localExisting?.collection || []), ...dbCardIds])
      );

      const dbClaimMs = existingRow.last_pack_time
        ? new Date(existingRow.last_pack_time).getTime()
        : NaN;

      // Preserve the real-time timer anchor so reload/re-login never resets the countdown
      const claimTimeMs =
        savedTimerAnchor ||
        localExisting?.lastPackClaimTime ||
        (Number.isFinite(dbClaimMs) ? dbClaimMs : Date.now());

      savePackTimerAnchor(nickname, claimTimeMs);

      const resolvedPacksAvailable =
        localExisting && typeof localExisting.packsAvailable === 'number'
          ? Math.min(
              localExisting.packsAvailable,
              typeof existingRow.packs_available === 'number'
                ? existingRow.packs_available
                : localExisting.packsAvailable
            )
          : typeof existingRow.packs_available === 'number'
          ? existingRow.packs_available
          : 3;

      const loadedProfile: UserProfile = {
        id: existingRow.id,
        nickname: existingRow.username || nickname,
        password,
        packsAvailable: resolvedPacksAvailable,
        lastPackClaimTime: claimTimeMs,
        winsProgress: (existingRow.wins_count ?? localExisting?.winsProgress ?? 0) % 3,
        ratingRP:
          typeof existingRow.rating === 'number'
            ? existingRow.rating
            : localExisting?.ratingRP ?? 1000,
        avatarUrl: localExisting?.avatarUrl || generateDefaultCyberMaskAvatar(nickname),
        collection: mergedCollection,
        battleDeck: localExisting?.battleDeck || mergedCollection.slice(0, 3),
        matchesWon: existingRow.wins_count ?? localExisting?.matchesWon ?? 0,
        matchesLost: localExisting?.matchesLost ?? 0,
        winStreak: localExisting?.winStreak ?? 0,
        packsOpened: localExisting?.packsOpened ?? 0,
      };

      const { updatedProfile } = syncPackEconomyTimer(loadedProfile);
      persistUserProfile(updatedProfile);
      setActiveSessionNickname(key);
      return { profile: updatedProfile, isNew: false };
    }

    // 2. If not in `profiles` table, check if local cache has password mismatch
    if (localExisting && localExisting.password !== password) {
      return { error: 'WRONG_PASSWORD' };
    }

    // 3. Create new profile in Supabase `profiles` table in 1 click (3 starter packs, 1000 RP)
    const initialClaimMs = savedTimerAnchor || localExisting?.lastPackClaimTime || Date.now();
    savePackTimerAnchor(nickname, initialClaimMs);
    const nowIso = new Date(initialClaimMs).toISOString();

    const { data: insertedRow, error: insertErr } = await supabase
      .from('profiles')
      .insert({
        username: nickname,
        password,
        packs_available: localExisting ? localExisting.packsAvailable : 3,
        rating: localExisting ? localExisting.ratingRP : 1000,
        wins_count: localExisting ? localExisting.matchesWon : 0,
        last_pack_time: nowIso,
      })
      .select('*')
      .single();

    if (!insertErr && insertedRow) {
      const createdProfile: UserProfile = {
        id: insertedRow.id,
        nickname: insertedRow.username || nickname,
        password,
        packsAvailable:
          localExisting?.packsAvailable ?? insertedRow.packs_available ?? 3,
        lastPackClaimTime: initialClaimMs,
        winsProgress: localExisting?.winsProgress ?? 0,
        ratingRP: localExisting?.ratingRP ?? insertedRow.rating ?? 1000,
        avatarUrl: localExisting?.avatarUrl || generateDefaultCyberMaskAvatar(nickname),
        collection: localExisting?.collection || [],
        battleDeck: localExisting?.battleDeck || [],
        matchesWon: localExisting?.matchesWon ?? 0,
        matchesLost: localExisting?.matchesLost ?? 0,
        winStreak: localExisting?.winStreak ?? 0,
        packsOpened: localExisting?.packsOpened ?? 0,
      };
      const { updatedProfile } = syncPackEconomyTimer(createdProfile);
      persistUserProfile(updatedProfile);
      setActiveSessionNickname(key);
      return { profile: updatedProfile, isNew: !localExisting };
    }
  } catch {
    // Fallback if offline or RLS policy restricts direct insert
  }

  // Fallback / Local cache sync if RLS policy restricted direct table insert
  if (localExisting) {
    if (localExisting.password !== password) {
      return { error: 'WRONG_PASSWORD' };
    }
    const anchorMs = savedTimerAnchor || localExisting.lastPackClaimTime || Date.now();
    savePackTimerAnchor(nickname, anchorMs);
    const { updatedProfile } = syncPackEconomyTimer({
      ...localExisting,
      lastPackClaimTime: anchorMs,
      id: localExisting.id || generateFallbackUuid(),
    });
    persistUserProfile(updatedProfile);
    setActiveSessionNickname(key);
    return { profile: updatedProfile, isNew: false };
  }

  const initialNow = savedTimerAnchor || Date.now();
  savePackTimerAnchor(nickname, initialNow);

  const newProfile: UserProfile = {
    id: generateFallbackUuid(),
    nickname,
    password,
    packsAvailable: 3, // 3 starter packs for new player
    lastPackClaimTime: initialNow,
    winsProgress: 0,
    ratingRP: 1000,
    avatarUrl: generateDefaultCyberMaskAvatar(nickname),
    collection: [],
    battleDeck: [],
    matchesWon: 0,
    matchesLost: 0,
    winStreak: 0,
    packsOpened: 0,
  };

  persistUserProfile(newProfile);
  setActiveSessionNickname(key);
  return { profile: newProfile, isNew: true };
}

/**
 * Saves newly opened cards to Supabase `user_cards` table (`user_id`, `card_index`).
 */
export async function saveOpenedCardsToSupabase(
  profile: UserProfile,
  cardIds: number[]
): Promise<void> {
  if (!profile.id || cardIds.length === 0) return;
  try {
    const rows = cardIds.map((cardId) => ({
      user_id: profile.id,
      card_index: cardId,
    }));
    await supabase.from('user_cards').insert(rows);
  } catch {
    // ignore if RLS restricts user_cards
  }
}

/**
 * Syncs profile stats (`packs_available`, `rating`, `wins_count`, `last_pack_time`) to Supabase `profiles`
 * and updates local cache + timer anchor.
 */
export function persistUserProfile(profile: UserProfile): void {
  const accounts = loadAllAccounts();
  const key = profile.nickname.toLowerCase();
  accounts[key] = profile;
  saveAllAccounts(accounts);
  savePackTimerAnchor(profile.nickname, profile.lastPackClaimTime);

  // Fire-and-forget async sync to Supabase `profiles`
  if (profile.id) {
    supabase
      .from('profiles')
      .update({
        packs_available: profile.packsAvailable,
        rating: profile.ratingRP,
        wins_count: profile.matchesWon,
        last_pack_time: new Date(profile.lastPackClaimTime).toISOString(),
      })
      .eq('id', profile.id)
      .then(() => {});
  }
}

const AI_LEADERBOARD_RIVALS: LeaderboardEntry[] = [
  {
    nickname: '0xHyperion_MEV',
    ratingRP: 1420,
    matchesWon: 38,
    avatarUrl: generateDefaultCyberMaskAvatar('0xHyperion_MEV'),
  },
  {
    nickname: 'SolanaTitan_99',
    ratingRP: 1315,
    matchesWon: 29,
    avatarUrl: generateDefaultCyberMaskAvatar('SolanaTitan_99'),
  },
  {
    nickname: 'ValidatorZero',
    ratingRP: 1240,
    matchesWon: 24,
    avatarUrl: generateDefaultCyberMaskAvatar('ValidatorZero'),
  },
  {
    nickname: 'Kroma_Flash',
    ratingRP: 1165,
    matchesWon: 19,
    avatarUrl: generateDefaultCyberMaskAvatar('Kroma_Flash'),
  },
  {
    nickname: 'NexusRelayer',
    ratingRP: 1085,
    matchesWon: 14,
    avatarUrl: generateDefaultCyberMaskAvatar('NexusRelayer'),
  },
  {
    nickname: 'AetherSlot_7',
    ratingRP: 1030,
    matchesWon: 9,
    avatarUrl: generateDefaultCyberMaskAvatar('AetherSlot_7'),
  },
  {
    nickname: 'CyberNode_15',
    ratingRP: 960,
    matchesWon: 5,
    avatarUrl: generateDefaultCyberMaskAvatar('CyberNode_15'),
  },
];

export function getLeaderboardEntries(
  currentUser: UserProfile | null,
  remoteProfiles: LeaderboardEntry[] = []
): LeaderboardEntry[] {
  const accounts = loadAllAccounts();
  const map = new Map<string, LeaderboardEntry>();

  for (const rival of AI_LEADERBOARD_RIVALS) {
    map.set(rival.nickname.toLowerCase(), { ...rival });
  }

  for (const remote of remoteProfiles) {
    map.set(remote.nickname.toLowerCase(), {
      ...remote,
      isCurrentUser:
        currentUser !== null &&
        remote.nickname.toLowerCase() === currentUser.nickname.toLowerCase(),
    });
  }

  Object.values(accounts).forEach((acc) => {
    map.set(acc.nickname.toLowerCase(), {
      nickname: acc.nickname,
      ratingRP: acc.ratingRP,
      matchesWon: acc.matchesWon,
      avatarUrl: acc.avatarUrl,
      isCurrentUser:
        currentUser !== null &&
        acc.nickname.toLowerCase() === currentUser.nickname.toLowerCase(),
    });
  });

  if (currentUser) {
    map.set(currentUser.nickname.toLowerCase(), {
      nickname: currentUser.nickname,
      ratingRP: currentUser.ratingRP,
      matchesWon: currentUser.matchesWon,
      avatarUrl: currentUser.avatarUrl,
      isCurrentUser: true,
    });
  }

  return Array.from(map.values()).sort((a, b) => b.ratingRP - a.ratingRP);
}

export async function fetchSupabaseLeaderboard(): Promise<LeaderboardEntry[]> {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('username, rating, wins_count')
      .order('rating', { ascending: false })
      .limit(30);

    if (error || !data) return [];
    return data
      .filter((row: { username?: string }) => Boolean(row.username))
      .map((row: { username: string; rating?: number; wins_count?: number }) => ({
        nickname: row.username,
        ratingRP: typeof row.rating === 'number' ? row.rating : 1000,
        matchesWon: typeof row.wins_count === 'number' ? row.wins_count : 0,
        avatarUrl: generateDefaultCyberMaskAvatar(row.username),
      }));
  } catch {
    return [];
  }
}

function drawRoundedRectPath(
  c: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  c.beginPath();
  c.moveTo(x + radius, y);
  c.arcTo(x + w, y, x + w, y + h, radius);
  c.arcTo(x + w, y + h, x, y + h, radius);
  c.arcTo(x, y + h, x, y, radius);
  c.arcTo(x, y, x + w, y, radius);
  c.closePath();
}

/**
 * Renders the Cyberpunk Luxury Esports 1200x675 Share Poster onto a Canvas.
 * - Deep void black (#020204) background
 * - Studio platinum/white overhead spotlight radial glow above cards
 * - Iridescent silver/pink/cyan mother-of-pearl chrome frame & divider lines
 * - Top-left: "TURBO-CHARGING // VALIDATOR ARENA" in pure white Lato Bold
 * - Top-right: Circular player avatar + Nickname + Rank & RP (e.g. "KK • 💎 985 RP")
 * - Center: Liquid silver match result & 3 ultra-sharp 3D-shaded cards
 * - Bottom-center pill: "TURBO-CHARGING VALIDATOR ARENA" (zero "3D TCG" text)
 */
function renderCyberpunkLuxuryPoster(
  params: {
    profile: UserProfile;
    oldRating: number;
    newRating: number;
    playerScore: number;
    enemyScore: number;
    deckCards: ValidatorCard[];
  },
  avatarImg?: HTMLImageElement | null
): string {
  const { profile, oldRating, newRating, playerScore, enemyScore, deckCards } = params;
  const cv = document.createElement('canvas');
  cv.width = 1200;
  cv.height = 675;
  const c = cv.getContext('2d')!;
  c.imageSmoothingEnabled = true;
  c.imageSmoothingQuality = 'high';

  // 1. Deep Void Black Background (#020204)
  c.fillStyle = '#020204';
  c.fillRect(0, 0, 1200, 675);

  // 2. Top-Center Studio Platinum/White Spotlight Radial Glow illuminating the cards
  const spotlight = c.createRadialGradient(600, 95, 10, 600, 275, 580);
  spotlight.addColorStop(0, 'rgba(255, 255, 255, 0.28)');
  spotlight.addColorStop(0.28, 'rgba(226, 232, 240, 0.14)');
  spotlight.addColorStop(0.6, 'rgba(192, 132, 252, 0.05)');
  spotlight.addColorStop(1, 'rgba(2, 2, 4, 0)');
  c.fillStyle = spotlight;
  c.fillRect(0, 0, 1200, 675);

  // Subtle Pink/Silver Mother-of-Pearl Edge Vignette Glow
  const leftEdgeGlow = c.createRadialGradient(0, 337, 10, 0, 337, 420);
  leftEdgeGlow.addColorStop(0, 'rgba(255, 139, 243, 0.14)');
  leftEdgeGlow.addColorStop(0.5, 'rgba(226, 232, 240, 0.05)');
  leftEdgeGlow.addColorStop(1, 'rgba(2, 2, 4, 0)');
  c.fillStyle = leftEdgeGlow;
  c.fillRect(0, 0, 1200, 675);

  const rightEdgeGlow = c.createRadialGradient(1200, 337, 10, 1200, 337, 420);
  rightEdgeGlow.addColorStop(0, 'rgba(0, 240, 255, 0.13)');
  rightEdgeGlow.addColorStop(0.5, 'rgba(255, 139, 243, 0.05)');
  rightEdgeGlow.addColorStop(1, 'rgba(2, 2, 4, 0)');
  c.fillStyle = rightEdgeGlow;
  c.fillRect(0, 0, 1200, 675);

  // 3. Outer Luxury 3D Chrome + Iridescent Silver/Pink Border Frame
  const outerChromeGrad = c.createLinearGradient(0, 0, 1200, 675);
  outerChromeGrad.addColorStop(0, '#ffffff');
  outerChromeGrad.addColorStop(0.22, '#cbd5e1');
  outerChromeGrad.addColorStop(0.45, '#ff8bf3');
  outerChromeGrad.addColorStop(0.55, '#ffffff');
  outerChromeGrad.addColorStop(0.78, '#bae6fd');
  outerChromeGrad.addColorStop(1, '#f1f5f9');

  c.save();
  c.shadowColor = 'rgba(255, 139, 243, 0.35)';
  c.shadowBlur = 22;
  drawRoundedRectPath(c, 16, 16, 1168, 643, 24);
  c.strokeStyle = outerChromeGrad;
  c.lineWidth = 3.5;
  c.stroke();
  c.restore();

  // Inner subtle chrome bevel line
  drawRoundedRectPath(c, 24, 24, 1152, 627, 18);
  c.strokeStyle = 'rgba(255, 255, 255, 0.16)';
  c.lineWidth = 1;
  c.stroke();

  // 4. Liquid Silver Header Divider Line with Iridescent Sheen
  const lineGrad = c.createLinearGradient(48, 96, 1152, 96);
  lineGrad.addColorStop(0, 'rgba(255,255,255,0.05)');
  lineGrad.addColorStop(0.2, 'rgba(226,232,240,0.65)');
  lineGrad.addColorStop(0.5, 'rgba(255,190,248,0.9)');
  lineGrad.addColorStop(0.8, 'rgba(186,230,253,0.65)');
  lineGrad.addColorStop(1, 'rgba(255,255,255,0.05)');
  c.fillStyle = lineGrad;
  c.fillRect(48, 96, 1104, 1.5);

  // 5. TOP-LEFT LOGO: "TURBO-CHARGING // VALIDATOR ARENA" (Pure White Lato Bold)
  c.save();
  c.fillStyle = '#ffffff';
  c.shadowColor = 'rgba(255, 255, 255, 0.35)';
  c.shadowBlur = 12;
  c.font = '900 24px "Lato", sans-serif';
  c.textAlign = 'left';
  c.textBaseline = 'middle';
  c.fillText('TURBO-CHARGING // VALIDATOR ARENA', 52, 60);
  c.restore();

  // 6. TOP-RIGHT: Player Circular Avatar + Nickname + Rank & RP (e.g. "KK • 💎 985 RP")
  const isWin = playerScore > enemyScore;
  const isDraw = playerScore === enemyScore;
  const diff = newRating - oldRating;
  const diffStr = diff >= 0 ? `+${diff} RP` : `${diff} RP`;
  const rightText = `${profile.nickname.toUpperCase()}  •  💎 ${formatRatingRP(newRating)} RP (${diffStr})`;

  c.save();
  c.font = '900 22px "Lato", sans-serif';
  c.textAlign = 'right';
  c.textBaseline = 'middle';
  const textRightX = 1148;
  const textWidth = c.measureText(rightText).width;

  const textSilverGrad = c.createLinearGradient(textRightX - textWidth, 44, textRightX, 76);
  textSilverGrad.addColorStop(0, '#ffffff');
  textSilverGrad.addColorStop(0.45, '#e2e8f0');
  textSilverGrad.addColorStop(0.75, '#f5d0fe');
  textSilverGrad.addColorStop(1, '#ffffff');
  c.fillStyle = textSilverGrad;
  c.shadowColor = 'rgba(255, 255, 255, 0.28)';
  c.shadowBlur = 10;
  c.fillText(rightText, textRightX, 60);
  c.restore();

  // Circular Mini-Portrait Avatar to the left of the nickname
  const avatarRadius = 20;
  const avatarCenterX = textRightX - textWidth - 32;
  const avatarCenterY = 60;

  c.save();
  c.beginPath();
  c.arc(avatarCenterX, avatarCenterY, avatarRadius, 0, Math.PI * 2);
  c.closePath();
  c.fillStyle = '#0d1018';
  c.fill();
  c.clip();

  if (avatarImg && avatarImg.complete && avatarImg.naturalWidth > 0) {
    c.drawImage(
      avatarImg,
      avatarCenterX - avatarRadius,
      avatarCenterY - avatarRadius,
      avatarRadius * 2,
      avatarRadius * 2
    );
  } else {
    // Stylized cyber emblem fallback if image not yet decoded
    const fallbackGrad = c.createLinearGradient(
      avatarCenterX - avatarRadius,
      avatarCenterY - avatarRadius,
      avatarCenterX + avatarRadius,
      avatarCenterY + avatarRadius
    );
    fallbackGrad.addColorStop(0, '#e2e8f0');
    fallbackGrad.addColorStop(1, '#475569');
    c.fillStyle = fallbackGrad;
    c.fillRect(
      avatarCenterX - avatarRadius,
      avatarCenterY - avatarRadius,
      avatarRadius * 2,
      avatarRadius * 2
    );
    c.fillStyle = '#020204';
    c.font = '900 16px "Lato", sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(profile.nickname.slice(0, 2).toUpperCase(), avatarCenterX, avatarCenterY);
  }
  c.restore();

  // Chrome Ring around Avatar
  c.save();
  c.beginPath();
  c.arc(avatarCenterX, avatarCenterY, avatarRadius + 1.5, 0, Math.PI * 2);
  c.strokeStyle = outerChromeGrad;
  c.lineWidth = 2.2;
  c.shadowColor = 'rgba(255, 255, 255, 0.45)';
  c.shadowBlur = 8;
  c.stroke();
  c.restore();

  // 7. Symmetrical Monolithic Center Match Score & Status Banner in Liquid Silver Chrome
  const resultLabel = isWin ? 'MATCH VICTORY' : isDraw ? 'COMBAT DRAW' : 'MATCH FINAL';
  const centerMiddleText = `•   ${resultLabel}   •`;

  c.save();
  c.textBaseline = 'middle';
  c.font = '900 36px "Lato", sans-serif';
  const bannerGrad = c.createLinearGradient(260, 122, 940, 166);
  bannerGrad.addColorStop(0, '#f8fafc');
  bannerGrad.addColorStop(0.3, '#cbd5e1');
  bannerGrad.addColorStop(0.5, '#ffffff');
  bannerGrad.addColorStop(0.7, '#f5d0fe');
  bannerGrad.addColorStop(1, '#e2e8f0');
  c.fillStyle = bannerGrad;
  c.shadowColor = 'rgba(255, 255, 255, 0.42)';
  c.shadowBlur = 18;

  // Center label strictly anchored at x = 600
  c.textAlign = 'center';
  c.fillText(centerMiddleText, 600, 142);
  const halfCenterW = c.measureText(centerMiddleText).width / 2;

  // Left side ("YOU 1") right-aligned to the left of center
  c.textAlign = 'right';
  c.fillText(`YOU  ${playerScore}`, 600 - halfCenterW - 24, 142);

  // Right side ("2 OPPONENT") left-aligned to the right of center
  c.textAlign = 'left';
  c.fillText(`${enemyScore}  OPPONENT`, 600 + halfCenterW + 24, 142);
  c.restore();

  // 8. Radial Gradient Stage Backdrop under the 3 Cards:
  // Smoothly transitions from deep black (#020204) in the center to shining silver metallic at the edges
  const stageX = 82;
  const stageY = 176;
  const stageW = 1036;
  const stageH = 384;

  c.save();
  drawRoundedRectPath(c, stageX, stageY, stageW, stageH, 24);
  const cardsStageRadial = c.createRadialGradient(600, 368, 45, 600, 368, 560);
  cardsStageRadial.addColorStop(0, '#020204');
  cardsStageRadial.addColorStop(0.42, '#06080f');
  cardsStageRadial.addColorStop(0.72, '#1e293b');
  cardsStageRadial.addColorStop(0.9, '#94a3b8');
  cardsStageRadial.addColorStop(1, '#f1f5f9');
  c.fillStyle = cardsStageRadial;
  c.fill();

  // Chrome metallic border around the card stage
  c.strokeStyle = 'rgba(255, 255, 255, 0.45)';
  c.lineWidth = 1.8;
  c.stroke();
  c.restore();

  // Render the 3 Battle Cards with High-Definition 3D Volume, Deep Shadow & Chrome Rim
  const cardsToDraw = deckCards.slice(0, 3);
  const cardW = 248;
  const cardH = 350;
  const totalWidth = cardsToDraw.length * cardW + (cardsToDraw.length - 1) * 52;
  const baseStartX = (1200 - totalWidth) / 2;
  const startY = 192;

  cardsToDraw.forEach((card, i) => {
    const cardCv = document.createElement('canvas');
    // High-res offscreen canvas for crisp, zero-blur rendering
    cardCv.width = 640;
    cardCv.height = 900;
    const loadedImg = cardImageStore.getLoadedImage(card.image);
    renderCardFrontToCanvas(card, cardCv, loadedImg);

    const cardX = baseStartX + i * (cardW + 52);
    const cardY = startY + (i === 1 ? -8 : 4); // Subtle 3D elevation for center card

    // Deep 3D Pedestal Drop Shadow + Ambient Neon Backlight
    c.save();
    c.shadowColor = 'rgba(0, 0, 0, 0.92)';
    c.shadowBlur = 34;
    c.shadowOffsetY = 18;
    drawRoundedRectPath(c, cardX, cardY, cardW, cardH, 16);
    c.fillStyle = '#05060a';
    c.fill();
    c.restore();

    // Soft Platinum/Pink/Cyan Backlight Halo behind each card
    c.save();
    c.shadowColor =
      i === 1 ? 'rgba(255, 255, 255, 0.32)' : 'rgba(255, 139, 243, 0.22)';
    c.shadowBlur = 24;
    drawRoundedRectPath(c, cardX, cardY, cardW, cardH, 16);
    c.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    c.lineWidth = 1.5;
    c.stroke();
    c.restore();

    // Draw Crisp Card Image clipped to rounded 3D corners
    c.save();
    drawRoundedRectPath(c, cardX, cardY, cardW, cardH, 16);
    c.clip();
    c.drawImage(cardCv, cardX, cardY, cardW, cardH);

    // Subtle Diagonal Glass Specular Reflection across card surface
    const sheen = c.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH);
    sheen.addColorStop(0, 'rgba(255, 255, 255, 0.14)');
    sheen.addColorStop(0.35, 'rgba(255, 255, 255, 0.02)');
    sheen.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
    sheen.addColorStop(1, 'rgba(255, 139, 243, 0.08)');
    c.fillStyle = sheen;
    c.fillRect(cardX, cardY, cardW, cardH);
    c.restore();

    // Metallic Chrome Bevel Border around each card
    c.save();
    drawRoundedRectPath(c, cardX, cardY, cardW, cardH, 16);
    const cardRimGrad = c.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH);
    cardRimGrad.addColorStop(0, '#ffffff');
    cardRimGrad.addColorStop(0.35, '#94a3b8');
    cardRimGrad.addColorStop(0.7, '#f5d0fe');
    cardRimGrad.addColorStop(1, '#e2e8f0');
    c.strokeStyle = cardRimGrad;
    c.lineWidth = 2.4;
    c.stroke();
    c.restore();
  });

  // 9. Bottom Divider & Center Luxury Badge: "TURBO-CHARGING VALIDATOR ARENA"
  c.fillStyle = lineGrad;
  c.fillRect(140, 578, 920, 1.2);

  const badgeW = 460;
  const badgeH = 38;
  const badgeX = (1200 - badgeW) / 2;
  const badgeY = 596;

  c.save();
  drawRoundedRectPath(c, badgeX, badgeY, badgeW, badgeH, 19);
  const pillFill = c.createLinearGradient(badgeX, badgeY, badgeX + badgeW, badgeY + badgeH);
  pillFill.addColorStop(0, 'rgba(255, 255, 255, 0.12)');
  pillFill.addColorStop(0.5, 'rgba(15, 23, 42, 0.85)');
  pillFill.addColorStop(1, 'rgba(255, 139, 243, 0.12)');
  c.fillStyle = pillFill;
  c.fill();
  c.strokeStyle = outerChromeGrad;
  c.lineWidth = 1.5;
  c.stroke();

  c.textAlign = 'center';
  c.textBaseline = 'middle';
  c.font = '900 16px "Lato", sans-serif';
  c.fillStyle = '#f8fafc';
  c.shadowColor = 'rgba(255, 255, 255, 0.35)';
  c.shadowBlur = 8;
  c.fillText('TURBO-CHARGING VALIDATOR ARENA', 600, badgeY + badgeH / 2 + 1);
  c.restore();

  return cv.toDataURL('image/png');
}

export function generateBattleSharePosterDataUrl(params: {
  profile: UserProfile;
  oldRating: number;
  newRating: number;
  playerScore: number;
  enemyScore: number;
  deckCards: ValidatorCard[];
}): string {
  return renderCyberpunkLuxuryPoster(params, null);
}

export async function generateBattleSharePosterAsync(params: {
  profile: UserProfile;
  oldRating: number;
  newRating: number;
  playerScore: number;
  enemyScore: number;
  deckCards: ValidatorCard[];
}): Promise<string> {
  if (!params.profile.avatarUrl) {
    return renderCyberpunkLuxuryPoster(params, null);
  }
  const avatarImg = await new Promise<HTMLImageElement | null>((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = params.profile.avatarUrl;
  });
  return renderCyberpunkLuxuryPoster(params, avatarImg);
}

