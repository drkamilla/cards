import * as THREE from 'three';
import { ValidatorCard, getCardRarity } from '../data/cardsData';
import { cardImageStore } from './cardImageStore';

export function createStarFlareTexture(): THREE.CanvasTexture {
  const cv = document.createElement('canvas');
  cv.width = 128;
  cv.height = 128;
  const c = cv.getContext('2d')!;

  const g = c.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, '#ffffff');
  g.addColorStop(0.2, '#ff8bf3');
  g.addColorStop(0.55, 'rgba(0, 240, 255, 0.25)');
  g.addColorStop(1, 'rgba(0, 0, 0, 0)');

  c.fillStyle = g;
  c.fillRect(0, 0, 128, 128);

  c.strokeStyle = '#ffffff';
  c.lineWidth = 2.5;
  c.beginPath();
  c.moveTo(64, 6);
  c.lineTo(64, 122);
  c.moveTo(6, 64);
  c.lineTo(122, 64);
  c.stroke();

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createContactShadowTexture(): THREE.CanvasTexture {
  const cv = document.createElement('canvas');
  cv.width = 256;
  cv.height = 256;
  const c = cv.getContext('2d')!;

  const g = c.createRadialGradient(128, 128, 10, 128, 128, 120);
  g.addColorStop(0, 'rgba(0, 240, 255, 0.32)');
  g.addColorStop(0.45, 'rgba(255, 139, 243, 0.14)');
  g.addColorStop(1, 'rgba(0, 0, 0, 0)');

  c.fillStyle = g;
  c.fillRect(0, 0, 256, 256);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function drawOptimumInfinityMark(
  c: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scale: number,
  strokeColor = '#07070c'
) {
  c.save();
  c.translate(cx, cy);
  c.scale(scale, scale);

  c.beginPath();
  c.moveTo(-55, -36);
  c.bezierCurveTo(-18, -36, -12, -16, 0, -16);
  c.bezierCurveTo(12, -16, 18, -36, 55, -36);
  c.bezierCurveTo(95, -36, 112, -18, 112, 0);
  c.bezierCurveTo(112, 18, 95, 36, 55, 36);
  c.bezierCurveTo(18, 36, 12, 16, 0, 16);
  c.bezierCurveTo(-12, 16, -18, 36, -55, 36);
  c.bezierCurveTo(-95, 36, -112, 18, -112, 0);
  c.bezierCurveTo(-112, -18, -95, -36, -55, -36);
  c.closePath();

  c.lineWidth = 28;
  c.strokeStyle = strokeColor;
  c.lineCap = 'round';
  c.lineJoin = 'round';
  c.stroke();
  c.restore();
}

export function createHolographicFoilTexture(
  maxAnisotropy: number,
  loadedPackImg?: HTMLImageElement
): THREE.CanvasTexture {
  const cv = document.createElement('canvas');
  cv.width = 768;
  cv.height = 1152;
  const c = cv.getContext('2d')!;

  const g = c.createLinearGradient(0, 0, 768, 1152);
  g.addColorStop(0.0, '#e8fbff');
  g.addColorStop(0.18, '#ffd6fa');
  g.addColorStop(0.36, '#c2f0ff');
  g.addColorStop(0.52, '#d8b4fe');
  g.addColorStop(0.7, '#b8ffe8');
  g.addColorStop(0.86, '#ffc8f0');
  g.addColorStop(1.0, '#ffffff');
  c.fillStyle = g;
  c.fillRect(0, 0, 768, 1152);

  const g2 = c.createLinearGradient(768, 0, 0, 1152);
  g2.addColorStop(0, 'rgba(0, 240, 255, 0.28)');
  g2.addColorStop(0.45, 'rgba(255, 255, 255, 0.05)');
  g2.addColorStop(0.7, 'rgba(255, 139, 243, 0.35)');
  g2.addColorStop(1, 'rgba(255, 240, 180, 0.25)');
  c.fillStyle = g2;
  c.fillRect(0, 0, 768, 1152);

  if (loadedPackImg && loadedPackImg.width > 0) {
    c.save();
    c.globalAlpha = 0.82;
    const sx = loadedPackImg.width * 0.335;
    const sy = loadedPackImg.height * 0.065;
    const sw = loadedPackImg.width * 0.325;
    const sh = loadedPackImg.height * 0.66;
    c.drawImage(loadedPackImg, sx, sy, sw, sh, 0, 0, 768, 1152);
    c.restore();
  } else {
    for (let i = 0; i < 18; i++) {
      const y = (i / 18) * 1152;
      const sheen = c.createLinearGradient(0, y, 768, y + 80);
      sheen.addColorStop(0, 'rgba(255,255,255,0.45)');
      sheen.addColorStop(0.5, 'rgba(255,255,255,0.0)');
      sheen.addColorStop(1, 'rgba(255,255,255,0.35)');
      c.fillStyle = sheen;
      c.fillRect(0, y, 768, 40);
    }

    drawOptimumInfinityMark(c, 384, 576, 1.45, '#09090f');
  }

  c.fillStyle = 'rgba(255, 255, 255, 0.35)';
  c.fillRect(0, 0, 768, 76);
  c.fillRect(0, 1076, 768, 76);

  c.strokeStyle = 'rgba(20, 24, 38, 0.22)';
  c.lineWidth = 3;
  for (let x = 0; x < 768; x += 12) {
    c.beginPath();
    c.moveTo(x, 0);
    c.lineTo(x, 74);
    c.moveTo(x, 1078);
    c.lineTo(x, 1152);
    c.stroke();
  }

  c.save();
  c.setLineDash([12, 10]);
  c.strokeStyle = 'rgba(0, 240, 255, 0.55)';
  c.lineWidth = 3;
  c.beginPath();
  c.moveTo(24, 96);
  c.lineTo(744, 96);
  c.stroke();
  c.restore();

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createCardBackTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const cv = document.createElement('canvas');
  cv.width = 512;
  cv.height = 720;
  const c = cv.getContext('2d')!;

  // 1. Outer Thin Iridescent Neon Rim (Silver - Blue - Pink)
  const rimGrad = c.createLinearGradient(0, 0, 512, 720);
  rimGrad.addColorStop(0, '#f8fafc');
  rimGrad.addColorStop(0.32, '#00f0ff');
  rimGrad.addColorStop(0.68, '#ff8bf3');
  rimGrad.addColorStop(1, '#e2e8f0');
  c.fillStyle = rimGrad;
  c.fillRect(0, 0, 512, 720);

  // 2. Deep Glossy Black Chamber
  const blackBg = c.createLinearGradient(0, 0, 512, 720);
  blackBg.addColorStop(0, '#090b12');
  blackBg.addColorStop(0.45, '#030407');
  blackBg.addColorStop(1, '#020205');
  c.fillStyle = blackBg;
  c.fillRect(8, 8, 496, 704);

  // 3. Glossy Diagonal Specular Sheen
  const gloss = c.createLinearGradient(0, 0, 512, 460);
  gloss.addColorStop(0, 'rgba(255, 255, 255, 0.09)');
  gloss.addColorStop(0.38, 'rgba(255, 255, 255, 0.02)');
  gloss.addColorStop(0.5, 'rgba(255, 255, 255, 0.0)');
  gloss.addColorStop(1, 'rgba(0, 0, 0, 0)');
  c.fillStyle = gloss;
  c.fillRect(8, 8, 496, 704);

  // 4. Inner Fine Iridescent Neon Piping (Silver - Blue - Pink)
  const neonGrad = c.createLinearGradient(22, 22, 490, 698);
  neonGrad.addColorStop(0, '#ffffff');
  neonGrad.addColorStop(0.35, '#00f0ff');
  neonGrad.addColorStop(0.7, '#ff8bf3');
  neonGrad.addColorStop(1, '#cbd5e1');
  c.strokeStyle = neonGrad;
  c.lineWidth = 2.5;
  c.strokeRect(22, 22, 468, 676);

  // Second hair-line inner accent
  c.strokeStyle = 'rgba(255, 255, 255, 0.14)';
  c.lineWidth = 1;
  c.strokeRect(32, 32, 448, 656);

  // Subtle corner cyber-ticks (no infinity symbol)
  c.strokeStyle = neonGrad;
  c.lineWidth = 2;
  const cornerLen = 22;
  // Top-left
  c.beginPath();
  c.moveTo(38, 38 + cornerLen);
  c.lineTo(38, 38);
  c.lineTo(38 + cornerLen, 38);
  // Top-right
  c.moveTo(474 - cornerLen, 38);
  c.lineTo(474, 38);
  c.lineTo(474, 38 + cornerLen);
  // Bottom-left
  c.moveTo(38, 682 - cornerLen);
  c.lineTo(38, 682);
  c.lineTo(38 + cornerLen, 682);
  // Bottom-right
  c.moveTo(474 - cornerLen, 682);
  c.lineTo(474, 682);
  c.lineTo(474, 682 - cornerLen);
  c.stroke();

  c.fillStyle = 'rgba(226, 232, 240, 0.65)';
  c.font = '900 15px "Lato", sans-serif';
  c.textAlign = 'center';
  c.fillText('TURBO-CHARGING', 256, 652);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function renderCardFrontToCanvas(
  data: ValidatorCard,
  cv: HTMLCanvasElement,
  customImg?: HTMLImageElement
) {
  cv.width = 512;
  cv.height = 720;
  const c = cv.getContext('2d')!;

  const loadedImg = customImg || cardImageStore.getLoadedImage(data.image);
  if (loadedImg && loadedImg.naturalWidth > 0) {
    try {
      c.fillStyle = '#07080e';
      c.fillRect(0, 0, 512, 720);
      c.drawImage(loadedImg, 0, 0, 512, 720);
      return;
    } catch {
      // Fallback to procedural canvas if image cannot be drawn
    }
  }

  const rarity = getCardRarity(data.power);

  // 1. Metallic Outer Frame
  const grad = c.createLinearGradient(0, 0, 512, 720);
  if (data.power >= 10) {
    grad.addColorStop(0, '#fff1f9');
    grad.addColorStop(0.35, '#ff8bf3');
    grad.addColorStop(0.7, '#00f0ff');
    grad.addColorStop(1, '#1e293b');
  } else if (data.power >= 8) {
    grad.addColorStop(0, '#e2e8f0');
    grad.addColorStop(0.5, '#94a3b8');
    grad.addColorStop(1, '#334155');
  } else {
    grad.addColorStop(0, '#cbd5e1');
    grad.addColorStop(0.5, '#64748b');
    grad.addColorStop(1, '#1e293b');
  }
  c.fillStyle = grad;
  c.fillRect(0, 0, 512, 720);

  // 2. Inner Dark Chamber
  c.fillStyle = '#090a10';
  c.fillRect(16, 16, 480, 688);

  // Top Header Strip
  c.fillStyle = '#121521';
  c.fillRect(28, 28, 456, 64);
  c.strokeStyle = 'rgba(255,255,255,0.12)';
  c.lineWidth = 1.5;
  c.strokeRect(28, 28, 456, 64);

  // Card Title (Slot #)
  c.fillStyle = '#ffffff';
  c.font = '900 26px "Lato", sans-serif';
  c.textAlign = 'left';
  c.fillText(`Slot ${data.slot}`, 44, 68);

  // Tier Tag on right of header
  c.fillStyle = rarity.primaryColor;
  c.font = '700 13px "Lato", sans-serif';
  c.textAlign = 'right';
  c.fillText(rarity.label, 468, 65);

  // 3. Artwork Chamber (Isometric 3D Cyber-Node Core)
  const artX = 36;
  const artY = 108;
  const artW = 440;
  const artH = 310;

  const artBg = c.createRadialGradient(256, artY + artH / 2, 15, 256, artY + artH / 2, 220);
  artBg.addColorStop(0, '#1e2238');
  artBg.addColorStop(1, '#0c0e17');
  c.fillStyle = artBg;
  c.fillRect(artX, artY, artW, artH);

  c.save();
  c.beginPath();
  c.rect(artX, artY, artW, artH);
  c.clip();

  c.strokeStyle = 'rgba(0, 240, 255, 0.12)';
  c.lineWidth = 1;
  for (let gx = artX; gx <= artX + artW; gx += 28) {
    c.beginPath();
    c.moveTo(gx, artY);
    c.lineTo(gx, artY + artH);
    c.stroke();
  }
  for (let gy = artY; gy <= artY + artH; gy += 28) {
    c.beginPath();
    c.moveTo(artX, gy);
    c.lineTo(artX + artW, gy);
    c.stroke();
  }

  const seed = data.slot % 997;
  const cx = 256;
  const cy = artY + artH / 2;

  const halo = c.createRadialGradient(cx, cy, 8, cx, cy, 125);
  halo.addColorStop(0, rarity.primaryColor);
  halo.addColorStop(0.45, rarity.secondaryColor + '55');
  halo.addColorStop(1, 'rgba(0,0,0,0)');
  c.fillStyle = halo;
  c.beginPath();
  c.arc(cx, cy, 125, 0, Math.PI * 2);
  c.fill();

  c.save();
  c.translate(cx, cy);
  c.rotate(((seed % 60) - 30) * (Math.PI / 180));
  c.strokeStyle = rarity.primaryColor;
  c.lineWidth = 2.5;
  c.beginPath();
  c.ellipse(0, 0, 118, 38, 0, 0, Math.PI * 2);
  c.stroke();

  c.rotate(Math.PI / 3);
  c.strokeStyle = rarity.secondaryColor;
  c.lineWidth = 2;
  c.beginPath();
  c.ellipse(0, 0, 105, 32, 0, 0, Math.PI * 2);
  c.stroke();
  c.restore();

  const r = 62;
  c.save();
  c.translate(cx, cy);

  c.fillStyle = rarity.primaryColor;
  c.beginPath();
  c.moveTo(0, -r);
  c.lineTo(r * 0.866, -r * 0.5);
  c.lineTo(0, 0);
  c.lineTo(-r * 0.866, -r * 0.5);
  c.closePath();
  c.fill();

  c.fillStyle = '#1e293b';
  c.beginPath();
  c.moveTo(-r * 0.866, -r * 0.5);
  c.lineTo(0, 0);
  c.lineTo(0, r);
  c.lineTo(-r * 0.866, r * 0.5);
  c.closePath();
  c.fill();

  c.fillStyle = rarity.secondaryColor;
  c.beginPath();
  c.moveTo(0, 0);
  c.lineTo(r * 0.866, -r * 0.5);
  c.lineTo(r * 0.866, r * 0.5);
  c.lineTo(0, r);
  c.closePath();
  c.fill();

  c.strokeStyle = '#ffffff';
  c.lineWidth = 3;
  c.beginPath();
  c.moveTo(0, -r);
  c.lineTo(r * 0.866, -r * 0.5);
  c.lineTo(r * 0.866, r * 0.5);
  c.lineTo(0, r);
  c.lineTo(-r * 0.866, r * 0.5);
  c.lineTo(-r * 0.866, -r * 0.5);
  c.closePath();
  c.moveTo(0, 0);
  c.lineTo(0, r);
  c.moveTo(0, 0);
  c.lineTo(r * 0.866, -r * 0.5);
  c.moveTo(0, 0);
  c.lineTo(-r * 0.866, -r * 0.5);
  c.stroke();

  c.restore();
  c.restore();

  c.strokeStyle = rarity.primaryColor;
  c.lineWidth = 2.5;
  c.strokeRect(artX, artY, artW, artH);

  // 4. Telemetry Stats Section
  const statsStartY = 456;
  const rowH = 50;

  const rows = [
    { label: 'Latency (Ping)', value: `${data.latency} ms`, color: data.latency < 100 ? '#10b981' : '#ffffff' },
    { label: 'Speed Boost', value: `${data.speedBoost}x`, color: '#00f0ff' },
    { label: 'Bid Uplift', value: `+${data.bidUplift}%`, color: '#ff8bf3' },
  ];

  rows.forEach((row, idx) => {
    const y = statsStartY + idx * rowH;
    c.fillStyle = 'rgba(255, 255, 255, 0.04)';
    c.fillRect(36, y - 30, 440, 40);

    c.font = '700 20px "Lato", sans-serif';
    c.textAlign = 'left';
    c.fillStyle = '#cbd5e1';
    c.fillText(row.label, 52, y - 3);

    c.textAlign = 'right';
    c.fillStyle = row.color;
    c.fillText(row.value, 460, y - 3);
  });

  // 5. Power Rating Footer Bar
  const footerY = 606;
  const barGrad = c.createLinearGradient(36, footerY, 476, footerY + 64);
  barGrad.addColorStop(0, rarity.badgeBg);
  barGrad.addColorStop(1, '#0f172a');
  c.fillStyle = barGrad;
  c.fillRect(36, footerY, 440, 66);

  c.strokeStyle = rarity.primaryColor;
  c.lineWidth = 2;
  c.strokeRect(36, footerY, 440, 66);

  c.fillStyle = '#ffffff';
  c.font = '900 25px "Lato", sans-serif';
  c.textAlign = 'center';
  c.fillText(`POWER RATING: ★ ${data.power}`, 256, footerY + 42);
}

const cardTextureCache = new Map<
  number,
  { tex: THREE.CanvasTexture; cv: HTMLCanvasElement; card: ValidatorCard }
>();

// Subscribe once to cardImageStore so any newly uploaded/loaded PNG refreshes existing 3D textures
cardImageStore.subscribe(() => {
  cardTextureCache.forEach((entry) => {
    const img = cardImageStore.getLoadedImage(entry.card.image);
    if (img) {
      renderCardFrontToCanvas(entry.card, entry.cv, img);
      entry.tex.needsUpdate = true;
    }
  });
});

export function getOrCreateCardFrontTexture(
  data: ValidatorCard,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const existing = cardTextureCache.get(data.id);
  if (existing) {
    return existing.tex;
  }

  const cv = document.createElement('canvas');
  renderCardFrontToCanvas(data, cv);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  cardTextureCache.set(data.id, { tex, cv, card: data });

  // Probe `/cards/<filename>` on the server or in memory store
  cardImageStore.probeServerImage(data.image, (loadedImg) => {
    renderCardFrontToCanvas(data, cv, loadedImg);
    tex.needsUpdate = true;
  });

  return tex;
}
