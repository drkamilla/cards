export interface ValidatorCard {
  id: number;
  name: string;
  slot: number;
  latency: number;
  speedBoost: number;
  bidUplift: number;
  power: number;
  image: string;
}

export type CardRarity = 'MYTHIC' | 'EPIC' | 'RARE' | 'COMMON';

export function calculatePower(speed: number, latency: number, bid: number): number {
  const p = Math.round(speed * 1.5 + (150 - latency) / 20 + bid / 2);
  return Math.max(1, Math.min(10, p));
}

export function getCardRarity(power: number): {
  tier: CardRarity;
  label: string;
  primaryColor: string;
  secondaryColor: string;
  badgeBg: string;
} {
  if (power >= 10) {
    return {
      tier: 'MYTHIC',
      label: 'MYTHIC NODE',
      primaryColor: '#00f0ff',
      secondaryColor: '#ff8bf3',
      badgeBg: '#ff0055',
    };
  }
  if (power >= 8) {
    return {
      tier: 'EPIC',
      label: 'TURBO RELAY',
      primaryColor: '#ff8bf3',
      secondaryColor: '#00f0ff',
      badgeBg: '#c81e64',
    };
  }
  if (power >= 6) {
    return {
      tier: 'RARE',
      label: 'OPTIMUM SLOT',
      primaryColor: '#00f0ff',
      secondaryColor: '#64748b',
      badgeBg: '#0284c7',
    };
  }
  return {
    tier: 'COMMON',
    label: 'BASE VALIDATOR',
    primaryColor: '#94a3b8',
    secondaryColor: '#475569',
    badgeBg: '#334155',
  };
}

export const INITIAL_CARDS_DB: ValidatorCard[] = [
  { id: 1, name: "Slot 15116975", slot: 15116975, latency: 96, speedBoost: 3.6, bidUplift: 0.5, power: 8, image: "cards/card_002.png" },
  { id: 2, name: "Slot 15116987", slot: 15116987, latency: 83, speedBoost: 4.2, bidUplift: 0.5, power: 10, image: "cards/card_003.png" },
  { id: 3, name: "Slot 15117393", slot: 15117393, latency: 130, speedBoost: 3.3, bidUplift: 0.0, power: 6, image: "cards/card_004.png" },
  { id: 4, name: "Slot 15117403", slot: 15117403, latency: 174, speedBoost: 2.9, bidUplift: 0.5, power: 3, image: "cards/card_005.png" },
  { id: 5, name: "Slot 15117350", slot: 15117350, latency: 130, speedBoost: 4.4, bidUplift: 0.5, power: 8, image: "cards/card_006.png" },
  { id: 6, name: "Slot 15116667", slot: 15116667, latency: 89, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_007.png" },
  { id: 7, name: "Slot 15116917", slot: 15116917, latency: 130, speedBoost: 4.8, bidUplift: 37.53, power: 10, image: "cards/card_008.png" },
  { id: 8, name: "Slot 15117009", slot: 15117009, latency: 130, speedBoost: 4.3, bidUplift: 0.5, power: 8, image: "cards/card_009.png" },
  { id: 9, name: "Slot 15116663", slot: 15116663, latency: 130, speedBoost: 7.9, bidUplift: 0.5, power: 10, image: "cards/card_011.png" },
  { id: 10, name: "Slot 15117325", slot: 15117325, latency: 97, speedBoost: 5.7, bidUplift: 0.5, power: 10, image: "cards/card_012.png" },
  { id: 11, name: "Slot 15116565", slot: 15116565, latency: 130, speedBoost: 5.2, bidUplift: 0.5, power: 9, image: "cards/card_013.png" },
  { id: 12, name: "Slot 15116626", slot: 15116626, latency: 130, speedBoost: 3.2, bidUplift: 0.5, power: 6, image: "cards/card_014.png" },
  { id: 13, name: "Slot 15116780", slot: 15116780, latency: 171, speedBoost: 3.2, bidUplift: 0.5, power: 4, image: "cards/card_015.png" },
  { id: 14, name: "Slot 15117238", slot: 15117238, latency: 85, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_016.png" },
  { id: 15, name: "Slot 15116409", slot: 15116409, latency: 130, speedBoost: 3.4, bidUplift: 0.0, power: 6, image: "cards/card_017.png" },
  { id: 16, name: "Slot 15116440", slot: 15116440, latency: 130, speedBoost: 3.8, bidUplift: 0.5, power: 7, image: "cards/card_018.png" },
  { id: 17, name: "Slot 15117278", slot: 15117278, latency: 88, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_019.png" },
  { id: 18, name: "Slot 15116671", slot: 15116671, latency: 130, speedBoost: 3.2, bidUplift: 1.89, power: 7, image: "cards/card_020.png" },
  { id: 19, name: "Slot 15116874", slot: 15116874, latency: 130, speedBoost: 5.2, bidUplift: 35.3, power: 10, image: "cards/card_021.png" },
  { id: 20, name: "Slot 15116476", slot: 15116476, latency: 130, speedBoost: 3.3, bidUplift: 4.63, power: 8, image: "cards/card_022.png" },
  { id: 21, name: "Slot 15116512", slot: 15116512, latency: 86, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_023.png" },
  { id: 22, name: "Slot 15116939", slot: 15116939, latency: 84, speedBoost: 3.2, bidUplift: 1.87, power: 9, image: "cards/card_024.png" },
  { id: 23, name: "Slot 15117347", slot: 15117347, latency: 83, speedBoost: 4.4, bidUplift: 1.27, power: 10, image: "cards/card_025.png" },
  { id: 24, name: "Slot 15117145", slot: 15117145, latency: 130, speedBoost: 3.1, bidUplift: 0.0, power: 6, image: "cards/card_026.png" },
  { id: 25, name: "Slot 15116560", slot: 15116560, latency: 130, speedBoost: 3.5, bidUplift: 2.71, power: 8, image: "cards/card_027.png" },
  { id: 26, name: "Slot 15117394", slot: 15117394, latency: 130, speedBoost: 3.2, bidUplift: 2.71, power: 7, image: "cards/card_028.png" },
  { id: 27, name: "Slot 15116751", slot: 15116751, latency: 130, speedBoost: 3.3, bidUplift: 16.68, power: 10, image: "cards/card_029.png" },
  { id: 28, name: "Slot 15117115", slot: 15117115, latency: 96, speedBoost: 3.2, bidUplift: 1.45, power: 8, image: "cards/card_030.png" },
  { id: 29, name: "Slot 15116647", slot: 15116647, latency: 130, speedBoost: 4.2, bidUplift: 0.5, power: 8, image: "cards/card_031.png" },
  { id: 30, name: "Slot 15117383", slot: 15117383, latency: 181, speedBoost: 2.6, bidUplift: 42.44, power: 10, image: "cards/card_032.png" },
  { id: 31, name: "Slot 15116828", slot: 15116828, latency: 130, speedBoost: 3.6, bidUplift: 0.5, power: 7, image: "cards/card_033.png" },
  { id: 32, name: "Slot 15117503", slot: 15117503, latency: 130, speedBoost: 3.2, bidUplift: 0.0, power: 6, image: "cards/card_034.png" },
  { id: 33, name: "Slot 15117066", slot: 15117066, latency: 187, speedBoost: 3.2, bidUplift: 0.5, power: 3, image: "cards/card_035.png" },
  { id: 34, name: "Slot 15116453", slot: 15116453, latency: 130, speedBoost: 3.5, bidUplift: 3.01, power: 8, image: "cards/card_036.png" },
  { id: 35, name: "Slot 15116731", slot: 15116731, latency: 130, speedBoost: 3.4, bidUplift: 8.79, power: 10, image: "cards/card_037.png" },
  { id: 36, name: "Slot 15117054", slot: 15117054, latency: 130, speedBoost: 5.7, bidUplift: 7.11, power: 10, image: "cards/card_038.png" },
  { id: 37, name: "Slot 15117441", slot: 15117441, latency: 130, speedBoost: 4.0, bidUplift: 0.5, power: 7, image: "cards/card_039.png" },
  { id: 38, name: "Slot 15117169", slot: 15117169, latency: 130, speedBoost: 2.5, bidUplift: 0.0, power: 5, image: "cards/card_040.png" },
  { id: 39, name: "Slot 15117332", slot: 15117332, latency: 130, speedBoost: 3.2, bidUplift: 0.01, power: 6, image: "cards/card_041.png" },
  { id: 40, name: "Slot 15117416", slot: 15117416, latency: 107, speedBoost: 3.9, bidUplift: 0.5, power: 8, image: "cards/card_042.png" },
  { id: 41, name: "Slot 15117", slot: 15117, latency: 130, speedBoost: 3.6, bidUplift: 0.0, power: 6, image: "cards/card_043.png" },
  { id: 42, name: "Slot 15116321", slot: 15116321, latency: 130, speedBoost: 3.4, bidUplift: 0.0, power: 6, image: "cards/card_044.png" },
  { id: 43, name: "Slot 15117163", slot: 15117163, latency: 130, speedBoost: 3.1, bidUplift: 0.5, power: 6, image: "cards/card_045.png" },
  { id: 44, name: "Slot 15117302", slot: 15117302, latency: 130, speedBoost: 3.9, bidUplift: 0.0, power: 7, image: "cards/card_046.png" },
  { id: 45, name: "Slot 15117102", slot: 15117102, latency: 130, speedBoost: 4.5, bidUplift: 1.6, power: 9, image: "cards/card_047.png" },
  { id: 46, name: "Slot 15116978", slot: 15116978, latency: 130, speedBoost: 3.2, bidUplift: 0.5, power: 6, image: "cards/card_048.png" },
  { id: 47, name: "Slot 15116954", slot: 15116954, latency: 130, speedBoost: 4.6, bidUplift: 0.5, power: 8, image: "cards/card_049.png" },
  { id: 48, name: "Slot 15117128", slot: 15117128, latency: 89, speedBoost: 4.6, bidUplift: 0.5, power: 10, image: "cards/card_050.png" },
  { id: 49, name: "Slot 15116678", slot: 15116678, latency: 140, speedBoost: 3.7, bidUplift: 2.12, power: 7, image: "cards/card_051.png" },
  { id: 50, name: "Slot 15116652", slot: 15116652, latency: 130, speedBoost: 4.5, bidUplift: 16.79, power: 10, image: "cards/card_052.png" },
  { id: 51, name: "Slot 15116606", slot: 15116606, latency: 99, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_053.png" },
  { id: 52, name: "Slot 15116624", slot: 15116624, latency: 316, speedBoost: 2.4, bidUplift: 0.5, power: 1, image: "cards/card_054.png" },
  { id: 53, name: "Slot 15117277", slot: 15117277, latency: 130, speedBoost: 4.2, bidUplift: 0.5, power: 8, image: "cards/card_055.png" },
  { id: 54, name: "Slot 151171174", slot: 151171174, latency: 130, speedBoost: 5.4, bidUplift: 0.01, power: 9, image: "cards/card_056.png" },
  { id: 55, name: "Slot 15117079", slot: 15117079, latency: 90, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_057.png" },
  { id: 56, name: "Slot 15116845", slot: 15116845, latency: 116, speedBoost: 3.1, bidUplift: 0.5, power: 7, image: "cards/card_058.png" },
  { id: 57, name: "Slot 15116675", slot: 15116675, latency: 140, speedBoost: 4.3, bidUplift: 0.06, power: 7, image: "cards/card_059.png" },
  { id: 58, name: "Slot 15116973", slot: 15116973, latency: 130, speedBoost: 3.5, bidUplift: 0.0, power: 6, image: "cards/card_060.png" },
  { id: 59, name: "Slot 15117048", slot: 15117048, latency: 181, speedBoost: 3.2, bidUplift: 0.5, power: 4, image: "cards/card_061.png" },
  { id: 60, name: "Slot 15117419", slot: 15117419, latency: 130, speedBoost: 3.2, bidUplift: 0.5, power: 6, image: "cards/card_062.png" },
  { id: 61, name: "Slot 15116539", slot: 15116539, latency: 130, speedBoost: 2.7, bidUplift: 2.24, power: 6, image: "cards/card_063.png" },
  { id: 62, name: "Slot 15117180", slot: 15117180, latency: 97, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_064.png" },
  { id: 63, name: "Slot 15116534", slot: 15116534, latency: 1, speedBoost: 4.2, bidUplift: 0.5, power: 10, image: "cards/card_065.png" },
  { id: 64, name: "Slot 15117421", slot: 15117421, latency: 130, speedBoost: 3.5, bidUplift: 0.0, power: 6, image: "cards/card_066.png" },
  { id: 65, name: "Slot 15117024", slot: 15117024, latency: 96, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_067.png" },
  { id: 66, name: "Slot 15117215", slot: 15117215, latency: 92, speedBoost: 3.2, bidUplift: 1.55, power: 8, image: "cards/card_068.png" },
  { id: 67, name: "Slot 15116760", slot: 15116760, latency: 130, speedBoost: 4.7, bidUplift: 0.5, power: 8, image: "cards/card_069.png" },
  { id: 68, name: "Slot 15116941", slot: 15116941, latency: 130, speedBoost: 3.1, bidUplift: 0.5, power: 6, image: "cards/card_070.png" },
  { id: 69, name: "Slot 15117292", slot: 15117292, latency: 105, speedBoost: 4.6, bidUplift: 1.44, power: 10, image: "cards/card_071.png" },
  { id: 70, name: "Slot 15117077", slot: 15117077, latency: 1, speedBoost: 4.2, bidUplift: 0.2, power: 10, image: "cards/card_072.png" },
  { id: 71, name: "Slot 15116438", slot: 15116438, latency: 1, speedBoost: 4.8, bidUplift: 0.0, power: 10, image: "cards/card_073.png" },
  { id: 72, name: "Slot 154117331", slot: 154117331, latency: 130, speedBoost: 3.6, bidUplift: 0.5, power: 7, image: "cards/card_074.png" },
  { id: 73, name: "Slot 15117020", slot: 15117020, latency: 130, speedBoost: 4.0, bidUplift: 13.89, power: 10, image: "cards/card_075.png" },
  { id: 74, name: "Slot 15116836", slot: 15116836, latency: 130, speedBoost: 4.1, bidUplift: 0.5, power: 7, image: "cards/card_076.png" },
  { id: 75, name: "Slot 15116502", slot: 15116502, latency: 130, speedBoost: 3.8, bidUplift: 27.93, power: 10, image: "cards/card_077.png" },
  { id: 76, name: "Slot 15117420", slot: 15117420, latency: 168, speedBoost: 2.8, bidUplift: 0.5, power: 4, image: "cards/card_078.png" },
  { id: 77, name: "Slot 15117131", slot: 15117131, latency: 130, speedBoost: 4.3, bidUplift: 0.5, power: 8, image: "cards/card_079.png" },
  { id: 78, name: "Slot 15117357", slot: 15117357, latency: 130, speedBoost: 3.2, bidUplift: 0.5, power: 6, image: "cards/card_080.png" },
  { id: 79, name: "Slot 15116830", slot: 15116830, latency: 130, speedBoost: 3.7, bidUplift: 0.5, power: 7, image: "cards/card_081.png" },
  { id: 80, name: "Slot 15116847", slot: 15116847, latency: 88, speedBoost: 3.2, bidUplift: 0.5, power: 8, image: "cards/card_082.png" },
  { id: 81, name: "Slot 15117453", slot: 15117453, latency: 130, speedBoost: 2.2, bidUplift: 24.68, power: 10, image: "cards/card_083.png" },
  { id: 82, name: "Slot 15116581", slot: 15116581, latency: 40, speedBoost: 4.2, bidUplift: 0.5, power: 10, image: "cards/card_084.png" },
  { id: 83, name: "Slot 15117439", slot: 15117439, latency: 130, speedBoost: 3.2, bidUplift: 4.47, power: 8, image: "cards/card_085.png" },
  { id: 84, name: "Slot 15117055", slot: 15117055, latency: 130, speedBoost: 2.5, bidUplift: 0.5, power: 5, image: "cards/card_086.png" },
  { id: 85, name: "Slot 15117235", slot: 15117235, latency: 109, speedBoost: 2.7, bidUplift: 0.5, power: 6, image: "cards/card_087.png" },
  { id: 86, name: "Slot 15116773", slot: 15116773, latency: 130, speedBoost: 4.4, bidUplift: 0.5, power: 8, image: "cards/card_088.png" },
  { id: 87, name: "Slot 15117281", slot: 15117281, latency: 130, speedBoost: 3.2, bidUplift: 94.74, power: 10, image: "cards/card_089.png" },
  { id: 88, name: "Slot 15117176", slot: 15117176, latency: 71, speedBoost: 7.3, bidUplift: 1.5, power: 10, image: "cards/card_090.png" },
  { id: 89, name: "Slot 15116578", slot: 15116578, latency: 130, speedBoost: 2.8, bidUplift: 9.42, power: 10, image: "cards/card_091.png" },
  { id: 90, name: "Slot 15116719", slot: 15116719, latency: 130, speedBoost: 3.3, bidUplift: 0.61, power: 6, image: "cards/card_092.png" },
  { id: 91, name: "Slot 15116820", slot: 15116820, latency: 130, speedBoost: 3.3, bidUplift: 1.26, power: 7, image: "cards/card_093.png" },
  { id: 92, name: "Slot 15117187", slot: 15117187, latency: 95, speedBoost: 4.6, bidUplift: 0.5, power: 10, image: "cards/card_094.png" },
  { id: 93, name: "Slot 15116535", slot: 15116535, latency: 84, speedBoost: 5.7, bidUplift: 0.5, power: 10, image: "cards/card_095.png" },
  { id: 94, name: "Slot 15117461", slot: 15117461, latency: 95, speedBoost: 2.8, bidUplift: 0.5, power: 7, image: "cards/card_096 (1).png" },
  { id: 95, name: "Slot 15116836", slot: 15116836, latency: 130, speedBoost: 3.2, bidUplift: 0.2, power: 6, image: "cards/card_096.png" },
  { id: 96, name: "Slot 15416846", slot: 15416846, latency: 130, speedBoost: 3.6, bidUplift: 0.5, power: 7, image: "cards/card_097.png" },
  { id: 97, name: "Slot 15116915", slot: 15116915, latency: 1, speedBoost: 3.8, bidUplift: 0.01, power: 10, image: "cards/card_098.png" },
  { id: 98, name: "Slot 15117223", slot: 15117223, latency: 130, speedBoost: 3.9, bidUplift: 0.5, power: 7, image: "cards/card_099.png" },
  { id: 99, name: "Slot 15117121", slot: 15117121, latency: 130, speedBoost: 4.6, bidUplift: 2.34, power: 9, image: "cards/card_100 (1).png" },
  { id: 100, name: "Slot 15117357", slot: 15117357, latency: 130, speedBoost: 3.2, bidUplift: 0.5, power: 6, image: "cards/card_100.png" },
  { id: 101, name: "Slot 15116563", slot: 15116563, latency: 130, speedBoost: 5.3, bidUplift: 0.5, power: 9, image: "cards/card_101 (1).png" },
  { id: 102, name: "Slot 15116830", slot: 15116830, latency: 130, speedBoost: 3.7, bidUplift: 0.5, power: 7, image: "cards/card_101.png" },
  { id: 103, name: "Slot 15116840", slot: 15116840, latency: 130, speedBoost: 3.7, bidUplift: 0.11, power: 7, image: "cards/card_102.png" }
].map(item => {
  const cleanImg = item.image.replace(/\\/g, '/').replace(/^\.?\/+/, '');
  return {
    ...item,
    image: `./${cleanImg}`,
    power: calculatePower(item.speedBoost, item.latency, item.bidUplift),
  };
});

export async function fetchCardsDatabase(): Promise<ValidatorCard[]> {
  try {
    const res = await fetch('./cards.json');
    if (!res.ok) return INITIAL_CARDS_DB;
    const raw = (await res.json()) as ValidatorCard[];
    if (!Array.isArray(raw) || raw.length === 0) return INITIAL_CARDS_DB;
    return raw.map((item, idx) => {
      const cleanImg = String(item.image || `cards/card_${String(idx + 2).padStart(3, '0')}.png`)
        .replace(/\\/g, '/')
        .replace(/^\.?\/+/, '');
      const latency = Number(item.latency) || 130;
      const speedBoost = Number(item.speedBoost) || 3.2;
      const bidUplift = Number(item.bidUplift) || 0;
      return {
        id: Number(item.id) || idx + 1,
        name: item.name || `Slot ${item.slot || idx + 1}`,
        slot: Number(item.slot) || idx + 1,
        latency,
        speedBoost,
        bidUplift,
        power: calculatePower(speedBoost, latency, bidUplift),
        image: `./${cleanImg}`,
      };
    });
  } catch {
    return INITIAL_CARDS_DB;
  }
}

