import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import confetti from 'canvas-confetti';
import {
  INITIAL_CARDS_DB,
  ValidatorCard,
  fetchCardsDatabase,
} from './data/cardsData';
import { Sound } from './utils/soundEngine';
import {
  createCardBackTexture,
  createContactShadowTexture,
  createHolographicFoilTexture,
  createStarFlareTexture,
  getOrCreateCardFrontTexture,
} from './utils/proceduralTextures';
import { cardImageStore } from './utils/cardImageStore';
import {
  CardCatalogModal,
  CardCanvasPreview,
  PlayerStats,
} from './components/CardCatalogModal';
import {
  UserProfile,
  LeaderboardEntry,
  loadAllAccounts,
  getActiveSessionNickname,
  setActiveSessionNickname,
  loginOrCreateAccountAsync,
  saveOpenedCardsToSupabase,
  persistUserProfile,
  syncPackEconomyTimer,
  formatCountdownHMS,
  formatRatingRP,
  getLeaderboardEntries,
  fetchSupabaseLeaderboard,
  TWELVE_HOURS_MS,
} from './utils/accountStore';
import {
  MatchRow,
  findOrCreateQuickMatch,
  createPrivateLobbyMatch,
  joinPrivateLobbyByCode,
  cancelWaitingMatch,
  submitPvPMove,
  completePvPMatch,
  subscribeToMatchUpdates,
} from './utils/supabaseClient';
import {
  LanguageCode,
  TRANSLATIONS,
  getInitialLanguage,
  saveLanguage,
  getRankTitle,
} from './utils/i18n';
import {
  LoginScreenModal,
  BattleModeSelectView,
  MatchmakingSubState,
  PostBattleModal,
  LeaderboardView,
  MyDeckView,
  RulesFormulaModal,
} from './components/HubModals';
import {
  Volume2,
  VolumeX,
  Sparkles,
  Zap,
  Eye,
  ShieldAlert,
  Camera,
  LogOut,
  Layers,
  Clock,
  Loader2,
} from 'lucide-react';

type HubTab = 'BOOSTERS' | 'DECK' | 'ARENA' | 'LEADERBOARD';
type GamePhase = 'PACK_IDLE' | 'PACK_OPENED' | 'ARENA_MODE_SELECT' | 'BATTLE' | 'GAME_OVER';
type ArenaSubPhase =
  | 'IDLE'
  | 'NEXT_ROUND_BANNER'
  | 'PRE_ROUND_COUNTDOWN'
  | 'TURN_TIMER'
  | 'WAITING_OPPONENT_MOVE'
  | 'ROUND_RESULT_PAUSE';

type RoundModifierType = 'STANDARD' | 'LOW_LATENCY' | 'TURBO_SPEED' | 'HIGH_BID';

interface RoundModifierSpec {
  type: RoundModifierType;
  checkBonus: (card: ValidatorCard) => boolean;
}

const ROUND_MODIFIER_SPECS: RoundModifierSpec[] = [
  {
    type: 'STANDARD',
    checkBonus: () => false,
  },
  {
    type: 'LOW_LATENCY',
    checkBonus: (c) => c.latency < 100,
  },
  {
    type: 'TURBO_SPEED',
    checkBonus: (c) => c.speedBoost >= 4.0,
  },
  {
    type: 'HIGH_BID',
    checkBonus: (c) => c.bidUplift >= 1.0,
  },
];

function getDeterministicModifiersForSeed(seedStr: string): RoundModifierSpec[] {
  let hash = 0;
  for (let i = 0; i < seedStr.length; i++) {
    hash = (hash * 31 + seedStr.charCodeAt(i)) >>> 0;
  }
  const pool = [...ROUND_MODIFIER_SPECS];
  const chosen: RoundModifierSpec[] = [];
  for (let i = 0; i < 3; i++) {
    const idx = (hash + i * 7) % pool.length;
    chosen.push(pool.splice(idx, 1)[0]);
  }
  return chosen;
}

interface RoundHistoryItem {
  round: number;
  modifierType: RoundModifierType;
  playerCard: ValidatorCard;
  enemyCard: ValidatorCard;
  playerEffectivePower: number;
  enemyEffectivePower: number;
  playerBonus: boolean;
  enemyBonus: boolean;
  winner: 'PLAYER' | 'ENEMY' | 'DRAW';
  tieBreakByPing: boolean;
}

interface Card3DActor {
  mesh: THREE.Mesh;
  cardData: ValidatorCard;
  targetPos: THREE.Vector3;
  targetRot: THREE.Euler;
  targetScale: number;
  flipped: boolean;
  index: number;
  isEnemy?: boolean;
}

interface PostBattleResultState {
  oldRating: number;
  newRating: number;
  playerScore: number;
  enemyScore: number;
  winsProgressAfter: number;
  bonusPackEarned: boolean;
  deckCards: ValidatorCard[];
}

export default function App() {
  // Language State
  const [lang, setLang] = useState<LanguageCode>(() => getInitialLanguage());
  const t = TRANSLATIONS[lang];

  const handleChangeLang = useCallback((nextLang: LanguageCode) => {
    Sound.select();
    setLang(nextLang);
    saveLanguage(nextLang);
  }, []);

  // Database state (loaded automatically from ./cards.json)
  const [cardsDb, setCardsDb] = useState<ValidatorCard[]>(INITIAL_CARDS_DB);
  const cardsDbRef = useRef<ValidatorCard[]>(INITIAL_CARDS_DB);
  const [customPngCount, setCustomPngCount] = useState<number>(0);
  const avatarInputRef = useRef<HTMLInputElement | null>(null);

  // User Profile & Auth State
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    const activeNick = getActiveSessionNickname();
    if (!activeNick) return null;
    const accounts = loadAllAccounts();
    const existing = accounts[activeNick.toLowerCase()];
    if (!existing) return null;
    const { updatedProfile } = syncPackEconomyTimer(existing);
    persistUserProfile(updatedProfile);
    return updatedProfile;
  });

  const [remoteLeaderboard, setRemoteLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [msUntilNextPack, setMsUntilNextPack] = useState<number>(() => {
    const activeNick = getActiveSessionNickname();
    if (!activeNick) return TWELVE_HOURS_MS;
    const accounts = loadAllAccounts();
    const existing = accounts[activeNick.toLowerCase()];
    if (!existing) return TWELVE_HOURS_MS;
    return syncPackEconomyTimer(existing, Date.now()).msUntilNextPack;
  });
  // Strict Hub Rule: Always start in 'BOOSTERS' tab
  const [activeTab, setActiveTab] = useState<HubTab>('BOOSTERS');

  // Automatically fetch './cards.json' and preload all card PNGs from './cards/...' via THREE.TextureLoader
  useEffect(() => {
    fetchCardsDatabase().then((loadedCards) => {
      setCardsDb(loadedCards);
      cardsDbRef.current = loadedCards;
      cardImageStore.init(loadedCards).then(() => {
        setCustomPngCount(cardImageStore.getCustomCount());
      });
    });
    const unsub = cardImageStore.subscribe(() => {
      setCustomPngCount(cardImageStore.getCustomCount());
    });
    return unsub;
  }, []);

  // Load Supabase Leaderboard when opening Ranking tab or logging in
  useEffect(() => {
    if (userProfile) {
      fetchSupabaseLeaderboard().then((entries) => {
        if (entries.length > 0) {
          setRemoteLeaderboard(entries);
        }
      });
    }
  }, [userProfile?.nickname, activeTab]);

  // Live 1-second ticking timer for 12-hour booster economy
  useEffect(() => {
    if (!userProfile) return;

    const updateTimer = () => {
      setUserProfile((prev) => {
        if (!prev) return null;
        const { updatedProfile, msUntilNextPack: remainingMs } = syncPackEconomyTimer(
          prev,
          Date.now()
        );
        setMsUntilNextPack(remainingMs);
        if (
          updatedProfile.packsAvailable !== prev.packsAvailable ||
          updatedProfile.lastPackClaimTime !== prev.lastPackClaimTime
        ) {
          persistUserProfile(updatedProfile);
          return updatedProfile;
        }
        return prev;
      });
    };

    updateTimer();
    const interval = window.setInterval(updateTimer, 1000);
    return () => window.clearInterval(interval);
  }, [userProfile?.nickname]);

  // Helper to update and persist profile (both local and Supabase `profiles`)
  const updateProfile = useCallback((updater: (prev: UserProfile) => UserProfile) => {
    setUserProfile((prev) => {
      if (!prev) return null;
      const next = updater(prev);
      persistUserProfile(next);
      return next;
    });
  }, []);

  // Game & 3D Scene state
  const [phase, setPhase] = useState<GamePhase>('PACK_IDLE');
  const [packTorn, setPackTorn] = useState<boolean>(false);
  const [currentPackCards, setCurrentPackCards] = useState<ValidatorCard[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [battleHand, setBattleHand] = useState<ValidatorCard[]>([]);
  const [battleStartingDeck, setBattleStartingDeck] = useState<ValidatorCard[]>([]);
  const [enemyHand, setEnemyHand] = useState<ValidatorCard[]>([]);
  const [roundModifiers, setRoundModifiers] = useState<RoundModifierSpec[]>([
    ROUND_MODIFIER_SPECS[0],
    ROUND_MODIFIER_SPECS[1],
    ROUND_MODIFIER_SPECS[2],
  ]);
  const [scores, setScores] = useState<{ player: number; enemy: number }>({ player: 0, enemy: 0 });
  const [roundIndex, setRoundIndex] = useState<number>(1);
  const [roundHistory, setRoundHistory] = useState<RoundHistoryItem[]>([]);
  const [statusBannerText, setStatusBannerText] = useState<string>('');
  const [postBattleResult, setPostBattleResult] = useState<PostBattleResultState | null>(null);

  // Matchmaking & Online PvP State (`matches` table)
  const [matchmakingSubState, setMatchmakingSubState] = useState<MatchmakingSubState>('MENU');
  const [quickSearchSecondsLeft, setQuickSearchSecondsLeft] = useState<number>(50);
  const [createdRoomCode, setCreatedRoomCode] = useState<string | null>(null);
  const [codeError, setCodeError] = useState<string | null>(null);
  const [isMatchmakingBusy, setIsMatchmakingBusy] = useState<boolean>(false);
  const [pvpMatch, setPvpMatch] = useState<MatchRow | null>(null);
  const [pvpRole, setPvpRole] = useState<'p1' | 'p2' | null>(null);
  const [pendingMyCard, setPendingMyCard] = useState<ValidatorCard | null>(null);
  const resolvedRoundsRef = useRef<Set<number>>(new Set());

  // Arena Timers State
  // 1) Pre-round 3..2..1 cinematic countdown
  // 2) 12-second turn decision timer (auto-plays if expired)
  // 3) 10-second post-clash review pause
  const [arenaSubPhase, setArenaSubPhase] = useState<ArenaSubPhase>('IDLE');
  const [preCountdown, setPreCountdown] = useState<number>(3);
  const [turnTimeLeft, setTurnTimeLeft] = useState<number>(12);
  const [resultPauseLeft, setResultPauseLeft] = useState<number>(10);

  // UI state
  const [catalogOpen, setCatalogOpen] = useState<boolean>(false);
  const [rulesOpen, setRulesOpen] = useState<boolean>(false);
  const [inspectedCard, setInspectedCard] = useState<ValidatorCard | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Laser tear state
  const [laserLine, setLaserLine] = useState<{
    visible: boolean;
    left: number;
    top: number;
    width: number;
  }>({ visible: false, left: 0, top: 0, width: 0 });

  // Refs for Three.js scene synchronization
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const phaseRef = useRef<GamePhase>(phase);
  const packTornRef = useRef<boolean>(packTorn);
  const activeTabRef = useRef<HubTab>(activeTab);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  useEffect(() => {
    packTornRef.current = packTorn;
  }, [packTorn]);

  useEffect(() => {
    activeTabRef.current = activeTab;
  }, [activeTab]);

  // Helper to get localized modifier title & rule
  const getModifierCopy = useCallback(
    (modType: RoundModifierType): { title: string; ruleText: string } => {
      switch (modType) {
        case 'LOW_LATENCY':
          return { title: t.modLowLatencyTitle, ruleText: t.modLowLatencyRule };
        case 'TURBO_SPEED':
          return { title: t.modTurboSpeedTitle, ruleText: t.modTurboSpeedRule };
        case 'HIGH_BID':
          return { title: t.modHighBidTitle, ruleText: t.modHighBidRule };
        default:
          return { title: t.modStandardTitle, ruleText: t.modStandardRule };
      }
    },
    [t]
  );

  const formatHistoryReason = useCallback(
    (item: RoundHistoryItem): string => {
      if (item.winner === 'PLAYER') {
        if (item.tieBreakByPing) {
          return t.reasonFasterPing(
            item.playerEffectivePower,
            item.playerCard.latency,
            item.enemyCard.latency
          );
        }
        return t.reasonHigherPower(
          item.playerEffectivePower,
          item.playerBonus,
          item.enemyEffectivePower,
          item.playerCard.latency < item.enemyCard.latency
        );
      }
      if (item.winner === 'ENEMY') {
        if (item.tieBreakByPing) {
          return t.reasonEnemyFasterPing(
            item.enemyEffectivePower,
            item.enemyCard.latency,
            item.playerCard.latency
          );
        }
        return t.reasonEnemyHigherPower(
          item.enemyEffectivePower,
          item.enemyBonus,
          item.playerEffectivePower
        );
      }
      return t.reasonExactTie(item.playerEffectivePower, item.playerCard.latency);
    },
    [t]
  );

  // Scene controller ref so React actions can command 3D actors
  const sceneCtrlRef = useRef<{
    resetPackForPhase: () => void;
    setPackCutTension: (ratio: number) => void;
    triggerPackTear3D: (onDone: () => void) => void;
    spawnPackCards3D: (cards: ValidatorCard[]) => void;
    flipCard3D: (idx: number) => void;
    flipAllCards3D: () => void;
    arrangeDraftCards3D: (cards: ValidatorCard[], selectedIds: number[]) => void;
    clearCards3D: () => void;
    playBattleClash3D: (pCard: ValidatorCard, eCard: ValidatorCard) => void;
    pulseCameraImpact: (winnerColorHex?: number) => void;
  } | null>(null);

  // Callback ref for when user clicks a 3D card in the viewport
  const onCard3DClickedRef = useRef<(actor: Card3DActor) => void>(() => {});

  // Initialize Three.js Scene once
  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x030306);
    scene.fog = new THREE.FogExp2(0x030306, 0.04);

    const camera = new THREE.PerspectiveCamera(
      44,
      window.innerWidth / window.innerHeight,
      0.1,
      100
    );
    camera.position.set(0, 1.15, 5.4);
    const cameraTargetPos = new THREE.Vector3(0, 1.15, 5.4);
    const cameraLookAt = new THREE.Vector3(0, 0.35, 0);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x090a10, 0.65);
    scene.add(hemiLight);

    const pinkLight = new THREE.PointLight(0xff8bf3, 4.2, 16);
    pinkLight.position.set(3.2, 3.8, 3.2);
    scene.add(pinkLight);

    const cyanLight = new THREE.PointLight(0x00f0ff, 4.5, 16);
    cyanLight.position.set(-3.2, 2.2, 2.5);
    scene.add(cyanLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 1.4);
    rimLight.position.set(0, 5, -4);
    scene.add(rimLight);

    const pedestalGroup = new THREE.Group();

    const mainCylinder = new THREE.Mesh(
      new THREE.CylinderGeometry(1.85, 2.05, 2.8, 64),
      new THREE.MeshStandardMaterial({
        color: 0x07080d,
        roughness: 0.32,
        metalness: 0.88,
      })
    );
    mainCylinder.position.y = -2.35;
    pedestalGroup.add(mainCylinder);

    const upperPlinth = new THREE.Mesh(
      new THREE.CylinderGeometry(1.76, 1.84, 0.14, 64),
      new THREE.MeshStandardMaterial({
        color: 0x0f121d,
        roughness: 0.18,
        metalness: 0.95,
      })
    );
    upperPlinth.position.y = -0.92;
    pedestalGroup.add(upperPlinth);

    const chromeBezel = new THREE.Mesh(
      new THREE.TorusGeometry(1.83, 0.026, 20, 96),
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        metalness: 1.0,
        roughness: 0.08,
      })
    );
    chromeBezel.rotation.x = Math.PI / 2;
    chromeBezel.position.y = -0.94;
    pedestalGroup.add(chromeBezel);

    const neonGrooveMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
    const neonGroove = new THREE.Mesh(
      new THREE.TorusGeometry(1.77, 0.014, 16, 96),
      neonGrooveMat
    );
    neonGroove.rotation.x = Math.PI / 2;
    neonGroove.position.y = -0.85;
    pedestalGroup.add(neonGroove);

    const shockwaveMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    });
    const shockwaveRing = new THREE.Mesh(
      new THREE.RingGeometry(0.4, 0.55, 64),
      shockwaveMat
    );
    shockwaveRing.rotation.x = -Math.PI / 2;
    shockwaveRing.position.y = -0.83;
    pedestalGroup.add(shockwaveRing);

    const shockwaveState = {
      active: false,
      scale: 0.5,
      opacity: 0,
    };

    function triggerShockwave(colorHex = 0x00f0ff) {
      shockwaveMat.color.setHex(colorHex);
      shockwaveState.active = true;
      shockwaveState.scale = 0.4;
      shockwaveState.opacity = 0.95;
      shockwaveRing.scale.set(0.4, 0.4, 0.4);
      shockwaveMat.opacity = 0.95;
    }

    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(3.2, 3.2),
      new THREE.MeshBasicMaterial({
        map: createContactShadowTexture(),
        transparent: true,
        depthWrite: false,
        opacity: 0.65,
      })
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -0.84;
    pedestalGroup.add(shadowPlane);

    scene.add(pedestalGroup);

    const ringGroup = new THREE.Group();
    ringGroup.position.y = 0.45;

    const r1 = new THREE.Mesh(
      new THREE.TorusGeometry(2.25, 0.016, 16, 120),
      new THREE.MeshBasicMaterial({ color: 0xff8bf3 })
    );
    r1.rotation.x = Math.PI / 2.3;
    r1.rotation.y = -Math.PI / 6;
    ringGroup.add(r1);

    const r2 = new THREE.Mesh(
      new THREE.TorusGeometry(2.42, 0.012, 16, 120),
      new THREE.MeshBasicMaterial({ color: 0x00f0ff })
    );
    r2.rotation.x = Math.PI / 2.1;
    r2.rotation.y = Math.PI / 5;
    ringGroup.add(r2);

    scene.add(ringGroup);

    const starMat = new THREE.SpriteMaterial({
      map: createStarFlareTexture(),
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const starPositions: [number, number, number][] = [
      [-1.85, 1.35, 0.5],
      [1.95, 1.85, -0.4],
      [1.75, -0.15, 0.8],
      [-1.55, -0.45, -0.5],
    ];
    const stars = starPositions.map((pos) => {
      const sp = new THREE.Sprite(starMat);
      sp.position.set(pos[0], pos[1], pos[2]);
      sp.scale.set(0.55, 0.55, 0.55);
      scene.add(sp);
      return sp;
    });

    const packGroup = new THREE.Group();
    packGroup.position.set(0, 0.55, 0);

    const initialFoilTex = createHolographicFoilTexture(maxAnisotropy);
    const packFoilMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      map: initialFoilTex,
      metalness: 0.78,
      roughness: 0.18,
      iridescence: 1.0,
      iridescenceIOR: 1.35,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
    });

    const packSideMat = new THREE.MeshStandardMaterial({
      color: 0xd8f3ff,
      metalness: 0.92,
      roughness: 0.15,
    });

    const packTextureLoader = new THREE.TextureLoader();
    packTextureLoader.load('./pack.png', (loadedPackTex) => {
      const packImg = loadedPackTex.image as HTMLImageElement | undefined;
      if (packImg && packImg.width > 0) {
        const blendedTex = createHolographicFoilTexture(maxAnisotropy, packImg);
        packFoilMat.map = blendedTex;
        packFoilMat.needsUpdate = true;
      }
    });

    const packBodyMats = [
      packSideMat,
      packSideMat,
      packSideMat,
      packSideMat,
      packFoilMat,
      packFoilMat,
    ];

    const packBodyMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.62, 2.15, 0.12, 16, 16, 4),
      packBodyMats
    );
    packGroup.add(packBodyMesh);

    const bottomCrimpMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.66, 0.14, 0.03),
      packSideMat
    );
    bottomCrimpMesh.position.y = -1.12;
    packGroup.add(bottomCrimpMesh);

    const topStripGroup = new THREE.Group();
    topStripGroup.position.set(0, 1.12, 0);
    const topCrimpMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.66, 0.18, 0.04),
      packSideMat
    );
    topStripGroup.add(topCrimpMesh);
    packGroup.add(topStripGroup);

    scene.add(packGroup);

    const packState = {
      visible: true,
      tearing: false,
      cutTension: 0,
      targetY: 0.55,
      topStripVel: new THREE.Vector3(0, 0, 0),
      topStripRotVel: new THREE.Vector3(0, 0, 0),
      topDetached: false,
    };

    // Glossy deep black card back with iridescent neon border
    const cardBackTex = createCardBackTexture(maxAnisotropy);
    const cardEdgeMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.92,
      roughness: 0.12,
    });
    const cardBackMat = new THREE.MeshPhysicalMaterial({
      map: cardBackTex,
      roughness: 0.08,
      metalness: 0.85,
      clearcoat: 1.0,
      clearcoatRoughness: 0.06,
      iridescence: 0.65,
    });

    const activeCards: Card3DActor[] = [];
    const cardGeometry = new THREE.BoxGeometry(1.08, 1.52, 0.025);
    let hoveredActor: Card3DActor | null = null;
    const pointerOffset = new THREE.Vector2(0, 0);

    function clearCards3D() {
      hoveredActor = null;
      while (activeCards.length > 0) {
        const actor = activeCards.pop()!;
        scene.remove(actor.mesh);
      }
    }

    function createCardActor(
      cardData: ValidatorCard,
      index: number,
      startPos: THREE.Vector3,
      targetPos: THREE.Vector3,
      faceUp: boolean,
      isEnemy = false
    ): Card3DActor {
      const frontTex = getOrCreateCardFrontTexture(cardData, maxAnisotropy);
      const frontMat = new THREE.MeshBasicMaterial({
        map: frontTex,
      });

      const mats = [
        cardEdgeMat,
        cardEdgeMat,
        cardEdgeMat,
        cardEdgeMat,
        frontMat,
        cardBackMat,
      ];

      const mesh = new THREE.Mesh(cardGeometry, mats);
      mesh.position.copy(startPos);
      mesh.rotation.set(0, faceUp ? 0 : Math.PI, 0);

      const actor: Card3DActor = {
        mesh,
        cardData,
        targetPos: targetPos.clone(),
        targetRot: new THREE.Euler(0, faceUp ? 0 : Math.PI, 0),
        targetScale: 1,
        flipped: faceUp,
        index,
        isEnemy,
      };
      mesh.userData.actor = actor;
      scene.add(mesh);
      activeCards.push(actor);
      return actor;
    }

    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();
    let lastHoverCheck = 0;

    const handleCanvasMove = (e: MouseEvent) => {
      const now = performance.now();
      if (now - lastHoverCheck < 40) return;
      lastHoverCheck = now;

      const rect = renderer.domElement.getBoundingClientRect();
      pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      pointerOffset.set(pointerNdc.x, pointerNdc.y);

      if (activeCards.length === 0) {
        hoveredActor = null;
        renderer.domElement.style.cursor = 'default';
        return;
      }

      raycaster.setFromCamera(pointerNdc, camera);
      const meshes = activeCards.map((a) => a.mesh);
      const hits = raycaster.intersectObjects(meshes, false);
      if (hits.length > 0) {
        const hitActor = hits[0].object.userData.actor as Card3DActor | undefined;
        hoveredActor = hitActor || null;
        renderer.domElement.style.cursor = 'pointer';
        if (hitActor && hitActor.flipped) {
          neonGrooveMat.color.set(hitActor.cardData.power >= 8 ? 0xff8bf3 : 0x00f0ff);
        }
      } else {
        hoveredActor = null;
        renderer.domElement.style.cursor = 'default';
      }
    };

    const handleCanvasClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointerNdc, camera);

      if (activeCards.length > 0) {
        const meshes = activeCards.map((a) => a.mesh);
        const hits = raycaster.intersectObjects(meshes, false);
        if (hits.length > 0) {
          const hitActor = hits[0].object.userData.actor as Card3DActor | undefined;
          if (hitActor) {
            onCard3DClickedRef.current(hitActor);
          }
        }
      }
    };

    renderer.domElement.addEventListener('mousemove', handleCanvasMove);
    renderer.domElement.addEventListener('click', handleCanvasClick);

    sceneCtrlRef.current = {
      resetPackForPhase: () => {
        clearCards3D();
        ringGroup.visible = true;
        packGroup.visible = true;
        packGroup.position.set(0, 2.8, 0);
        packGroup.rotation.set(0, 0, 0);
        topStripGroup.position.set(0, 1.12, 0);
        topStripGroup.rotation.set(0, 0, 0);
        packState.visible = true;
        packState.tearing = false;
        packState.cutTension = 0;
        packState.topDetached = false;
        packState.targetY = 0.55;
        neonGrooveMat.color.setHex(0x00f0ff);
        cameraTargetPos.set(0, 1.15, 5.4);
      },
      setPackCutTension: (ratio: number) => {
        packState.cutTension = Math.min(1, Math.max(0, ratio));
      },
      triggerPackTear3D: (onDone: () => void) => {
        packState.tearing = true;
        packState.cutTension = 0;
        packState.topDetached = true;
        packState.topStripVel.set(2.2, 3.2, 1.2);
        packState.topStripRotVel.set(1.5, 2.5, -4.5);
        packState.targetY = -3.4;
        triggerShockwave(0xff8bf3);
        cameraTargetPos.set(0, 1.15, 4.95);
        window.setTimeout(() => {
          cameraTargetPos.set(0, 1.15, 5.4);
          packGroup.visible = false;
          packState.visible = false;
          onDone();
        }, 520);
      },
      spawnPackCards3D: (cards: ValidatorCard[]) => {
        clearCards3D();
        ringGroup.visible = false;
        cards.forEach((c, i) => {
          const targetX = (i - 1) * 1.38;
          createCardActor(
            c,
            i,
            new THREE.Vector3(0, -0.3, 0.2),
            new THREE.Vector3(targetX, 0.78, 1.45),
            false
          );
        });
      },
      flipCard3D: (idx: number) => {
        const actor = activeCards.find((a) => a.index === idx);
        if (actor && !actor.flipped) {
          actor.flipped = true;
          actor.targetRot.y = 0;
          actor.mesh.position.z += 0.38;
          if (actor.cardData.power >= 9) {
            triggerShockwave(0x00f0ff);
          }
        }
      },
      flipAllCards3D: () => {
        activeCards.forEach((actor, idx) => {
          if (!actor.flipped) {
            actor.flipped = true;
            actor.targetRot.y = 0;
            actor.mesh.position.z += 0.25 + idx * 0.06;
          }
        });
        triggerShockwave(0x00f0ff);
      },
      arrangeDraftCards3D: (cards: ValidatorCard[], selectedIds: number[]) => {
        packGroup.visible = false;
        packState.visible = false;
        ringGroup.visible = false;
        const centerOffset = (cards.length - 1) / 2;
        const stepX = cards.length <= 3 ? 1.28 : 0.86;
        clearCards3D();
        cards.forEach((c, i) => {
          const isSelected = selectedIds.includes(c.id);
          const spreadX = (i - centerOffset) * stepX;
          const archY = 0.85 - Math.abs(i - centerOffset) * 0.05 + (isSelected ? 0.16 : 0);
          const archZ = 1.15 + (isSelected ? 0.3 : 0);
          const actor = createCardActor(
            c,
            i,
            new THREE.Vector3(spreadX, 0.2, 0),
            new THREE.Vector3(spreadX, archY, archZ),
            true
          );
          actor.targetRot.z = -(i - centerOffset) * 0.04;
          actor.targetScale = cards.length <= 3 ? 0.92 : isSelected ? 0.86 : 0.76;
        });
      },
      clearCards3D,
      playBattleClash3D: (pCard: ValidatorCard, eCard: ValidatorCard) => {
        clearCards3D();
        packGroup.visible = false;
        packState.visible = false;
        ringGroup.visible = false;

        const pActor = createCardActor(
          pCard,
          0,
          new THREE.Vector3(-2.4, -0.5, 2.2),
          new THREE.Vector3(-0.76, 0.72, 1.38),
          true,
          false
        );
        pActor.targetRot.y = 0.18;
        pActor.targetScale = 0.94;

        const eActor = createCardActor(
          eCard,
          1,
          new THREE.Vector3(2.4, 1.5, -1.0),
          new THREE.Vector3(0.76, 0.72, 1.38),
          true,
          true
        );
        eActor.targetRot.y = -0.18;
        eActor.targetScale = 0.94;
      },
      pulseCameraImpact: (winnerColorHex = 0x00f0ff) => {
        camera.position.y += 0.24;
        camera.position.z -= 0.25;
        neonGrooveMat.color.setHex(winnerColorHex);
        triggerShockwave(winnerColorHex);
      },
    };

    const clock = new THREE.Clock();
    let frameId = 0;
    let isDisposed = false;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (gl && typeof gl.fenceSync === 'function') {
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (isDisposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      } else {
        frameId = window.setTimeout(cb, 80);
      }
    }

    function tick() {
      if (isDisposed) return;
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      camera.position.x = THREE.MathUtils.damp(camera.position.x, cameraTargetPos.x, 6, dt);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, cameraTargetPos.y, 6, dt);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, cameraTargetPos.z, 6, dt);
      camera.lookAt(cameraLookAt);

      if (shockwaveState.active) {
        shockwaveState.scale = THREE.MathUtils.damp(shockwaveState.scale, 4.2, 5, dt);
        shockwaveState.opacity = THREE.MathUtils.damp(shockwaveState.opacity, 0, 5, dt);
        shockwaveRing.scale.set(
          shockwaveState.scale,
          shockwaveState.scale,
          shockwaveState.scale
        );
        shockwaveMat.opacity = shockwaveState.opacity;
        if (shockwaveState.opacity < 0.02) {
          shockwaveState.active = false;
          shockwaveMat.opacity = 0;
        }
      }

      if (packGroup.visible) {
        if (!packState.tearing) {
          const quiverX =
            packState.cutTension > 0
              ? Math.sin(elapsed * 45) * 0.035 * packState.cutTension
              : 0;
          const floatTargetY = packState.targetY + Math.sin(elapsed * 1.9) * 0.08;
          packGroup.position.x = THREE.MathUtils.damp(packGroup.position.x, quiverX, 15, dt);
          packGroup.position.y = THREE.MathUtils.damp(packGroup.position.y, floatTargetY, 7, dt);
          packGroup.rotation.y =
            Math.sin(elapsed * 0.85) * 0.18 + packState.cutTension * 0.12;
          packGroup.rotation.z = Math.cos(elapsed * 1.1) * 0.03;
        } else {
          packGroup.position.y = THREE.MathUtils.damp(
            packGroup.position.y,
            packState.targetY,
            5,
            dt
          );
          if (packState.topDetached) {
            topStripGroup.position.x += packState.topStripVel.x * dt;
            topStripGroup.position.y += packState.topStripVel.y * dt;
            topStripGroup.position.z += packState.topStripVel.z * dt;
            topStripGroup.rotation.x += packState.topStripRotVel.x * dt;
            topStripGroup.rotation.y += packState.topStripRotVel.y * dt;
            topStripGroup.rotation.z += packState.topStripRotVel.z * dt;
          }
        }
      }

      for (let i = 0; i < activeCards.length; i++) {
        const actor = activeCards[i];
        const isHovered = hoveredActor === actor;
        const hoverBob =
          Math.sin(elapsed * 2.2 + i * 0.9) * 0.025 + (isHovered ? 0.08 : 0);
        const hoverZ = isHovered ? 0.16 : 0;

        actor.mesh.position.x = THREE.MathUtils.damp(
          actor.mesh.position.x,
          actor.targetPos.x,
          8,
          dt
        );
        actor.mesh.position.y = THREE.MathUtils.damp(
          actor.mesh.position.y,
          actor.targetPos.y + hoverBob,
          8,
          dt
        );
        actor.mesh.position.z = THREE.MathUtils.damp(
          actor.mesh.position.z,
          actor.targetPos.z + hoverZ,
          8,
          dt
        );

        const tiltX = isHovered ? -pointerOffset.y * 0.14 : 0;
        const tiltY = isHovered && actor.flipped ? pointerOffset.x * 0.18 : 0;

        actor.mesh.rotation.x = THREE.MathUtils.damp(
          actor.mesh.rotation.x,
          actor.targetRot.x + tiltX,
          9,
          dt
        );
        actor.mesh.rotation.y = THREE.MathUtils.damp(
          actor.mesh.rotation.y,
          actor.targetRot.y + tiltY,
          9,
          dt
        );
        actor.mesh.rotation.z = THREE.MathUtils.damp(
          actor.mesh.rotation.z,
          actor.targetRot.z,
          9,
          dt
        );

        const s = THREE.MathUtils.damp(
          actor.mesh.scale.x,
          actor.targetScale * (isHovered ? 1.04 : 1),
          9,
          dt
        );
        actor.mesh.scale.set(s, s, s);
      }

      ringGroup.rotation.z = elapsed * 0.32;
      ringGroup.rotation.y = elapsed * 0.22;

      for (let i = 0; i < stars.length; i++) {
        const sc = 0.48 + Math.sin(elapsed * 2.8 + i * 1.3) * 0.22;
        stars[i].scale.set(sc, sc, sc);
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    tick();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      isDisposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('mousemove', handleCanvasMove);
      renderer.domElement.removeEventListener('click', handleCanvasClick);
      renderer.dispose();
    };
  }, []);

  const drawRandomCards = useCallback((count: number, excludeIds: number[] = []) => {
    const pool = cardsDbRef.current.filter((c) => !excludeIds.includes(c.id));
    const source = pool.length >= count ? [...pool] : [...cardsDbRef.current];
    const picked: ValidatorCard[] = [];
    for (let i = 0; i < count; i++) {
      const randIdx = Math.floor(Math.random() * source.length);
      picked.push(source.splice(randIdx, 1)[0]);
    }
    return picked;
  }, []);

  // Prepare 3-card combat deck for current user
  const getPlayerCombatDeck = useCallback((): ValidatorCard[] => {
    if (!userProfile) return drawRandomCards(3);
    let chosenIds = [...userProfile.battleDeck];
    if (chosenIds.length < 3) {
      const owned = cardsDbRef.current
        .filter((c) => userProfile.collection.includes(c.id) && !chosenIds.includes(c.id))
        .sort((a, b) => (b.power !== a.power ? b.power - a.power : a.latency - b.latency));
      for (const c of owned) {
        if (chosenIds.length < 3) chosenIds.push(c.id);
      }
    }
    let chosenHand = cardsDbRef.current.filter((c) => chosenIds.includes(c.id)).slice(0, 3);
    if (chosenHand.length < 3) {
      const extra = drawRandomCards(3 - chosenHand.length, chosenHand.map((c) => c.id));
      chosenHand = [...chosenHand, ...extra];
    }
    return chosenHand;
  }, [userProfile, drawRandomCards]);

  // Login / Create Account handler (Async Supabase `profiles` + `user_cards`)
  const handleLogin = useCallback(
    async (nickname: string, password: string): Promise<{ error?: string }> => {
      Sound.init();
      const res = await loginOrCreateAccountAsync(nickname, password);
      if (res.error || !res.profile) {
        return { error: res.error || 'Auth error' };
      }
      Sound.chime(1.1);
      const { updatedProfile, msUntilNextPack: remainingMs } = syncPackEconomyTimer(
        res.profile,
        Date.now()
      );
      setMsUntilNextPack(remainingMs);
      setUserProfile(updatedProfile);
      setActiveTab('BOOSTERS');
      setPhase('PACK_IDLE');
      setArenaSubPhase('IDLE');
      setPackTorn(false);
      packTornRef.current = false;
      setCurrentPackCards([]);
      setFlippedIndices([]);
      sceneCtrlRef.current?.resetPackForPhase();
      return {};
    },
    []
  );

  // Logout / Switch Player handler
  const handleLogout = useCallback(() => {
    Sound.select();
    if (pvpMatch && pvpMatch.status === 'waiting') {
      cancelWaitingMatch(pvpMatch.id);
    }
    setActiveSessionNickname(null);
    setUserProfile(null);
    setPvpMatch(null);
    setPvpRole(null);
    setPostBattleResult(null);
    setActiveTab('BOOSTERS');
    setPhase('PACK_IDLE');
    setArenaSubPhase('IDLE');
    setPackTorn(false);
    packTornRef.current = false;
    sceneCtrlRef.current?.resetPackForPhase();
  }, [pvpMatch]);

  // Custom Avatar Upload Handler
  const handleAvatarUpload = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file || !userProfile) return;
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          Sound.chime(1.15);
          updateProfile((prev) => ({
            ...prev,
            avatarUrl: reader.result as string,
          }));
        }
      };
      reader.readAsDataURL(file);
    },
    [userProfile, updateProfile]
  );

  // Open Booster Pack (decrements packsAvailable by 1, spawns 3 cards in 3D, saves to Supabase `user_cards` & `profiles`)
  const handleTearPack = useCallback(() => {
    if (!userProfile) return;
    if (packTornRef.current) return;
    if (activeTabRef.current !== 'BOOSTERS') return;

    if (userProfile.packsAvailable <= 0) {
      return;
    }

    setPackTorn(true);
    packTornRef.current = true;
    setPhase('PACK_OPENED');
    Sound.init();
    Sound.tear();

    if (navigator.vibrate) {
      navigator.vibrate([40, 80]);
    }

    confetti({
      particleCount: 65,
      spread: 80,
      origin: { y: 0.45 },
      colors: ['#ff8bf3', '#00f0ff', '#ffffff'],
    });

    sceneCtrlRef.current?.triggerPackTear3D(() => {
      const newCards = drawRandomCards(3);
      const newCardIds = newCards.map((c) => c.id);
      setCurrentPackCards(newCards);
      setFlippedIndices([]);

      // Save opened cards to Supabase `user_cards` table
      saveOpenedCardsToSupabase(userProfile, newCardIds);

      updateProfile((prev) => {
        const mergedCollection = Array.from(new Set([...prev.collection, ...newCardIds]));
        let nextDeck = [...prev.battleDeck];
        if (nextDeck.length < 3) {
          const allOwned = cardsDbRef.current
            .filter((c) => mergedCollection.includes(c.id))
            .sort((a, b) => (b.power !== a.power ? b.power - a.power : a.latency - b.latency));
          nextDeck = allOwned.slice(0, 3).map((c) => c.id);
        }
        return {
          ...prev,
          packsAvailable: Math.max(0, prev.packsAvailable - 1),
          packsOpened: prev.packsOpened + 1,
          collection: mergedCollection,
          battleDeck: nextDeck,
        };
      });

      sceneCtrlRef.current?.spawnPackCards3D(newCards);
    });
  }, [userProfile, drawRandomCards, updateProfile]);

  const handlePrepareNextBooster = useCallback(() => {
    Sound.select();
    setPhase('PACK_IDLE');
    setPackTorn(false);
    packTornRef.current = false;
    setCurrentPackCards([]);
    setFlippedIndices([]);
    sceneCtrlRef.current?.resetPackForPhase();
  }, []);

  const handleFlipPackCard = useCallback(
    (idx: number) => {
      if (flippedIndices.includes(idx)) return;
      Sound.chime(1 + idx * 0.08);
      sceneCtrlRef.current?.flipCard3D(idx);

      const updated = [...flippedIndices, idx];
      setFlippedIndices(updated);
    },
    [flippedIndices]
  );

  const handleFlipAllPackCards = useCallback(() => {
    if (currentPackCards.length === 0 || flippedIndices.length === 3) return;
    Sound.chime(1.1);
    sceneCtrlRef.current?.flipAllCards3D();
    setFlippedIndices([0, 1, 2]);
  }, [currentPackCards.length, flippedIndices.length]);

  // Toggle card in player's 3-card battleDeck
  const handleToggleDeckCard = useCallback(
    (cardId: number) => {
      if (!userProfile) return;
      Sound.select();
      updateProfile((prev) => {
        let nextDeck: number[];
        if (prev.battleDeck.includes(cardId)) {
          nextDeck = prev.battleDeck.filter((id) => id !== cardId);
        } else if (prev.battleDeck.length < 3) {
          nextDeck = [...prev.battleDeck, cardId];
        } else {
          nextDeck = [...prev.battleDeck.slice(1), cardId];
        }
        const deckCards = cardsDbRef.current.filter((c) => nextDeck.includes(c.id));
        if (activeTabRef.current === 'DECK') {
          sceneCtrlRef.current?.arrangeDraftCards3D(deckCards, nextDeck);
        }
        return {
          ...prev,
          battleDeck: nextDeck,
        };
      });
    },
    [userProfile, updateProfile]
  );

  const handleAutoPickBestDeck = useCallback(() => {
    if (!userProfile) return;
    Sound.select();
    updateProfile((prev) => {
      const owned = cardsDbRef.current
        .filter((c) => prev.collection.includes(c.id))
        .sort((a, b) => (b.power !== a.power ? b.power - a.power : a.latency - b.latency));
      const best3 = owned.slice(0, 3).map((c) => c.id);
      const deckCards = cardsDbRef.current.filter((c) => best3.includes(c.id));
      if (activeTabRef.current === 'DECK') {
        sceneCtrlRef.current?.arrangeDraftCards3D(deckCards, best3);
      }
      return {
        ...prev,
        battleDeck: best3,
      };
    });
  }, [userProfile, updateProfile]);

  // Launch 3-Round Battle vs AI Bot
  const launchAiBattle = useCallback(() => {
    if (!userProfile) return;
    Sound.chime(1.2);

    const chosenHand = getPlayerCombatDeck();
    const aiCards = drawRandomCards(
      3,
      chosenHand.map((c) => c.id)
    );
    const shuffledMods = [...ROUND_MODIFIER_SPECS].sort(() => Math.random() - 0.5).slice(0, 3);

    resolvedRoundsRef.current = new Set();
    setPvpMatch(null);
    setPvpRole(null);
    setPendingMyCard(null);
    setRoundModifiers(shuffledMods);
    setBattleStartingDeck(chosenHand);
    setBattleHand(chosenHand);
    setEnemyHand(aiCards);
    setScores({ player: 0, enemy: 0 });
    setRoundIndex(1);
    setRoundHistory([]);
    setPostBattleResult(null);
    setStatusBannerText('');
    setPhase('BATTLE');
    setPreCountdown(3);
    setTurnTimeLeft(12);
    setResultPauseLeft(10);
    setArenaSubPhase('PRE_ROUND_COUNTDOWN');
    sceneCtrlRef.current?.clearCards3D();
  }, [userProfile, getPlayerCombatDeck, drawRandomCards]);

  // Launch 3-Round Online PvP Battle (`matches` row is in `playing` state)
  const launchOnlinePvPBattle = useCallback(
    (match: MatchRow, role: 'p1' | 'p2') => {
      if (!userProfile) return;
      Sound.chime(1.25);

      const chosenHand = getPlayerCombatDeck();
      const deterministicMods = getDeterministicModifiersForSeed(match.id);

      resolvedRoundsRef.current = new Set();
      setPvpMatch(match);
      setPvpRole(role);
      setPendingMyCard(null);
      setRoundModifiers(deterministicMods);
      setBattleStartingDeck(chosenHand);
      setBattleHand(chosenHand);
      setEnemyHand([]);
      setScores({ player: 0, enemy: 0 });
      setRoundIndex(1);
      setRoundHistory([]);
      setPostBattleResult(null);
      setStatusBannerText('');
      setPhase('BATTLE');
      setPreCountdown(3);
      setTurnTimeLeft(12);
      setResultPauseLeft(10);
      setArenaSubPhase('PRE_ROUND_COUNTDOWN');
      sceneCtrlRef.current?.clearCards3D();
    },
    [userProfile, getPlayerCombatDeck]
  );

  // Matchmaking Option 1: Quick Search (PvP) with 50-second timer & AI Fallback
  const handleStartQuickMatch = useCallback(async () => {
    if (!userProfile || isMatchmakingBusy) return;
    Sound.select();
    setIsMatchmakingBusy(true);
    setCodeError(null);

    try {
      const { match, role, joinedImmediately } = await findOrCreateQuickMatch(
        userProfile.nickname
      );
      if (joinedImmediately) {
        setIsMatchmakingBusy(false);
        launchOnlinePvPBattle(match, role);
      } else {
        setPvpMatch(match);
        setPvpRole(role);
        setQuickSearchSecondsLeft(50);
        setMatchmakingSubState('QUICK_SEARCHING');
        setIsMatchmakingBusy(false);
      }
    } catch {
      setIsMatchmakingBusy(false);
      // If Supabase network unreachable, fallback to AI
      launchAiBattle();
    }
  }, [userProfile, isMatchmakingBusy, launchOnlinePvPBattle, launchAiBattle]);

  // Matchmaking Option 2A: Create Private Lobby by Code
  const handleCreateLobby = useCallback(async () => {
    if (!userProfile || isMatchmakingBusy) return;
    Sound.select();
    setIsMatchmakingBusy(true);
    setCodeError(null);

    try {
      const { match, role } = await createPrivateLobbyMatch(userProfile.nickname);
      setPvpMatch(match);
      setPvpRole(role);
      setCreatedRoomCode(match.room_code);
      setMatchmakingSubState('LOBBY_WAITING');
    } catch {
      setCodeError('Error creating lobby');
    } finally {
      setIsMatchmakingBusy(false);
    }
  }, [userProfile, isMatchmakingBusy]);

  // Matchmaking Option 2B: Join Private Lobby by Code
  const handleSubmitJoinCode = useCallback(
    async (code: string) => {
      if (!userProfile || isMatchmakingBusy) return;
      Sound.select();
      setIsMatchmakingBusy(true);
      setCodeError(null);

      try {
        const res = await joinPrivateLobbyByCode(code, userProfile.nickname);
        if (res.error || !res.match || !res.role) {
          setCodeError(t.roomNotFoundError);
        } else {
          launchOnlinePvPBattle(res.match, res.role);
        }
      } finally {
        setIsMatchmakingBusy(false);
      }
    },
    [userProfile, isMatchmakingBusy, t, launchOnlinePvPBattle]
  );

  // Cancel Waiting Matchmaking / Lobby
  const handleCancelMatchmaking = useCallback(() => {
    Sound.select();
    if (pvpMatch && pvpMatch.status === 'waiting') {
      cancelWaitingMatch(pvpMatch.id);
    }
    setPvpMatch(null);
    setPvpRole(null);
    setCreatedRoomCode(null);
    setCodeError(null);
    setMatchmakingSubState('MENU');
  }, [pvpMatch]);

  // 50-Second Quick Search Countdown Timer -> Automatic AI Fallback
  useEffect(() => {
    if (
      activeTab !== 'ARENA' ||
      phase !== 'ARENA_MODE_SELECT' ||
      matchmakingSubState !== 'QUICK_SEARCHING'
    ) {
      return;
    }

    if (quickSearchSecondsLeft <= 0) {
      if (pvpMatch && pvpMatch.status === 'waiting') {
        cancelWaitingMatch(pvpMatch.id);
      }
      setMatchmakingSubState('AI_FALLBACK_NOTICE');
      const fallbackTimer = window.setTimeout(() => {
        setMatchmakingSubState('MENU');
        launchAiBattle();
      }, 1700);
      return () => window.clearTimeout(fallbackTimer);
    }

    const timer = window.setTimeout(() => {
      setQuickSearchSecondsLeft((prev) => prev - 1);
    }, 1000);

    return () => window.clearTimeout(timer);
  }, [
    activeTab,
    phase,
    matchmakingSubState,
    quickSearchSecondsLeft,
    pvpMatch,
    launchAiBattle,
  ]);

  // Subscribe via Supabase Realtime (.channel()) to `matches` while waiting in Quick Search or Private Lobby
  useEffect(() => {
    if (
      activeTab !== 'ARENA' ||
      phase !== 'ARENA_MODE_SELECT' ||
      (matchmakingSubState !== 'QUICK_SEARCHING' && matchmakingSubState !== 'LOBBY_WAITING') ||
      !pvpMatch
    ) {
      return;
    }

    const unsub = subscribeToMatchUpdates(pvpMatch.id, (updatedMatch) => {
      if (updatedMatch.status === 'playing' && updatedMatch.player2) {
        launchOnlinePvPBattle(updatedMatch, pvpRole || 'p1');
      }
    });

    return unsub;
  }, [activeTab, phase, matchmakingSubState, pvpMatch, pvpRole, launchOnlinePvPBattle]);

  // Switch Hub Tabs (Manual user action only)
  const handleSelectTab = useCallback(
    (tab: HubTab) => {
      Sound.select();
      if (pvpMatch && pvpMatch.status === 'waiting') {
        cancelWaitingMatch(pvpMatch.id);
      }
      setPostBattleResult(null);
      setActiveTab(tab);

      if (tab === 'BOOSTERS') {
        setArenaSubPhase('IDLE');
        setPhase('PACK_IDLE');
        setPvpMatch(null);
        setPvpRole(null);
        setPackTorn(false);
        packTornRef.current = false;
        setCurrentPackCards([]);
        setFlippedIndices([]);
        sceneCtrlRef.current?.resetPackForPhase();
      } else if (tab === 'DECK') {
        setArenaSubPhase('IDLE');
        setPhase('PACK_IDLE');
        setPvpMatch(null);
        setPvpRole(null);
        const deckIds = userProfile?.battleDeck || [];
        const deckCards = cardsDbRef.current.filter((c) => deckIds.includes(c.id));
        if (deckCards.length > 0) {
          sceneCtrlRef.current?.arrangeDraftCards3D(deckCards, deckIds);
        } else {
          sceneCtrlRef.current?.clearCards3D();
        }
      } else if (tab === 'ARENA') {
        setArenaSubPhase('IDLE');
        setPvpMatch(null);
        setPvpRole(null);
        setCreatedRoomCode(null);
        setCodeError(null);
        setMatchmakingSubState('MENU');
        setPhase('ARENA_MODE_SELECT');
        sceneCtrlRef.current?.clearCards3D();
      } else if (tab === 'LEADERBOARD') {
        setArenaSubPhase('IDLE');
        setPhase('PACK_IDLE');
        setPvpMatch(null);
        setPvpRole(null);
        sceneCtrlRef.current?.resetPackForPhase();
      }
    },
    [userProfile, pvpMatch]
  );

  useEffect(() => {
    onCard3DClickedRef.current = (actor: Card3DActor) => {
      if (activeTab === 'BOOSTERS' && phase === 'PACK_OPENED') {
        handleFlipPackCard(actor.index);
      } else {
        setInspectedCard(actor.cardData);
        setCatalogOpen(true);
      }
    };
  }, [activeTab, phase, handleFlipPackCard]);

  // Resolve a combat round once both player card (`pCard`) and opponent card (`eCard`) are ready
  const resolveCombatRound = useCallback(
    (pCard: ValidatorCard, eCard: ValidatorCard, roundNum: number) => {
      if (resolvedRoundsRef.current.has(roundNum)) return;
      resolvedRoundsRef.current.add(roundNum);

      const currentMod = roundModifiers[roundNum - 1] || ROUND_MODIFIER_SPECS[0];
      const pBonus = currentMod.checkBonus(pCard) ? 2 : 0;
      const eBonus = currentMod.checkBonus(eCard) ? 2 : 0;
      const pEffPower = pCard.power + pBonus;
      const eEffPower = eCard.power + eBonus;

      Sound.impact();
      sceneCtrlRef.current?.playBattleClash3D(pCard, eCard);

      const pAdvantage = pCard.latency < eCard.latency;
      let winner: 'PLAYER' | 'ENEMY' | 'DRAW' = 'DRAW';
      let tieBreakByPing = false;
      let resultText = '';

      if (pEffPower > eEffPower) {
        winner = 'PLAYER';
        resultText = t.roundWonMsg(roundNum, pEffPower, eEffPower, pAdvantage);
        sceneCtrlRef.current?.pulseCameraImpact(0x00f0ff);
        confetti({ particleCount: 40, spread: 60, origin: { y: 0.5 } });
      } else if (pEffPower < eEffPower) {
        winner = 'ENEMY';
        resultText = t.roundLostMsg(roundNum, pEffPower, eEffPower);
        sceneCtrlRef.current?.pulseCameraImpact(0xff0055);
      } else {
        if (pCard.latency < eCard.latency) {
          winner = 'PLAYER';
          tieBreakByPing = true;
          resultText = t.roundWonByPingMsg(roundNum, pCard.latency, eCard.latency);
          sceneCtrlRef.current?.pulseCameraImpact(0x00f0ff);
          confetti({ particleCount: 35, spread: 55, origin: { y: 0.5 } });
        } else if (eCard.latency < pCard.latency) {
          winner = 'ENEMY';
          tieBreakByPing = true;
          resultText = t.roundLostByPingMsg(roundNum, pCard.latency, eCard.latency);
          sceneCtrlRef.current?.pulseCameraImpact(0xff0055);
        } else {
          winner = 'DRAW';
          resultText = t.roundDrawMsg(roundNum, pEffPower);
          sceneCtrlRef.current?.pulseCameraImpact(0xff8bf3);
        }
      }

      setScores((prev) => ({
        player: prev.player + (winner === 'PLAYER' ? 1 : 0),
        enemy: prev.enemy + (winner === 'ENEMY' ? 1 : 0),
      }));

      setRoundHistory((prev) => [
        ...prev,
        {
          round: roundNum,
          modifierType: currentMod.type,
          playerCard: pCard,
          enemyCard: eCard,
          playerEffectivePower: pEffPower,
          enemyEffectivePower: eEffPower,
          playerBonus: pBonus > 0,
          enemyBonus: eBonus > 0,
          winner,
          tieBreakByPing,
        },
      ]);
      setStatusBannerText(resultText);
      setPendingMyCard(null);

      // Enter 10-second post-clash review pause
      setResultPauseLeft(10);
      setArenaSubPhase('ROUND_RESULT_PAUSE');
    },
    [roundModifiers, t]
  );

  // Execute a combat round (called manually by clicking a card or automatically when 12s timer expires)
  const handlePlayCombatRound = useCallback(
    async (cardIdx: number) => {
      if (
        phase !== 'BATTLE' ||
        (arenaSubPhase !== 'TURN_TIMER' && arenaSubPhase !== 'PRE_ROUND_COUNTDOWN') ||
        !userProfile
      ) {
        return;
      }
      const pCard = battleHand[cardIdx] || battleHand[0];
      if (!pCard) return;

      const nextPlayerHand = battleHand.filter((c) => c.id !== pCard.id);
      setBattleHand(nextPlayerHand);

      // CASE A: Online PvP Match via Supabase `matches` (`p1_moves` / `p2_moves`)
      if (pvpMatch && pvpRole) {
        setPendingMyCard(pCard);
        setArenaSubPhase('WAITING_OPPONENT_MOVE');

        const currentMyMoves =
          pvpRole === 'p1' ? [...(pvpMatch.p1_moves || [])] : [...(pvpMatch.p2_moves || [])];
        const nextMyMoves = [...currentMyMoves.slice(0, roundIndex - 1), pCard.id];

        const updatedRow = await submitPvPMove(pvpMatch.id, pvpRole, nextMyMoves);
        const latestMatch = updatedRow || pvpMatch;
        if (updatedRow) {
          setPvpMatch(updatedRow);
        }

        const oppMoves =
          pvpRole === 'p1' ? latestMatch.p2_moves || [] : latestMatch.p1_moves || [];
        const oppCardId = oppMoves[roundIndex - 1];
        if (typeof oppCardId === 'number') {
          const eCard =
            cardsDbRef.current.find((c) => c.id === oppCardId) || cardsDbRef.current[0];
          resolveCombatRound(pCard, eCard, roundIndex);
        }
        return;
      }

      // CASE B: AI Bot Battle
      if (enemyHand.length === 0) return;
      const eIdx = Math.floor(Math.random() * enemyHand.length);
      const eCard = enemyHand[eIdx];
      const nextEnemyHand = enemyHand.filter((_, i) => i !== eIdx);
      setEnemyHand(nextEnemyHand);

      resolveCombatRound(pCard, eCard, roundIndex);
    },
    [
      phase,
      arenaSubPhase,
      userProfile,
      battleHand,
      pvpMatch,
      pvpRole,
      roundIndex,
      enemyHand,
      resolveCombatRound,
    ]
  );

  // Subscribe to Realtime updates on `matches` during an active Online PvP Battle
  useEffect(() => {
    if (activeTab !== 'ARENA' || phase !== 'BATTLE' || !pvpMatch || !pvpRole) {
      return;
    }

    const unsub = subscribeToMatchUpdates(pvpMatch.id, (updatedMatch) => {
      setPvpMatch(updatedMatch);

      if (arenaSubPhase === 'WAITING_OPPONENT_MOVE' && pendingMyCard) {
        const oppMoves =
          pvpRole === 'p1' ? updatedMatch.p2_moves || [] : updatedMatch.p1_moves || [];
        const oppCardId = oppMoves[roundIndex - 1];
        if (typeof oppCardId === 'number') {
          const eCard =
            cardsDbRef.current.find((c) => c.id === oppCardId) || cardsDbRef.current[0];
          resolveCombatRound(pendingMyCard, eCard, roundIndex);
        }
      }
    });

    return unsub;
  }, [
    activeTab,
    phase,
    pvpMatch,
    pvpRole,
    arenaSubPhase,
    pendingMyCard,
    roundIndex,
    resolveCombatRound,
  ]);

  // Advance after the 10-second round review pause completes (or user clicks Continue)
  const advanceAfterRoundPause = useCallback(() => {
    if (!userProfile || phase !== 'BATTLE' || arenaSubPhase !== 'ROUND_RESULT_PAUSE') return;

    const nextRound = roundIndex + 1;
    if (nextRound <= 3) {
      setRoundIndex(nextRound);
      setStatusBannerText('');
      sceneCtrlRef.current?.clearCards3D();
      setPreCountdown(3);
      setTurnTimeLeft(12);
      // Show centered "СЛЕДУЮЩИЙ РАУНД" banner for 1.5 seconds before 3..2..1 countdown
      setArenaSubPhase('NEXT_ROUND_BANNER');
    } else {
      // End of Round 3 -> Transition to GAME_OVER & show PostBattleModal
      setArenaSubPhase('IDLE');
      setPhase('GAME_OVER');
      const wonMatch = scores.player > scores.enemy;
      const lostMatch = scores.player < scores.enemy;
      const rpDelta = wonMatch ? 25 : lostMatch ? -15 : 5;

      if (pvpMatch && pvpRole) {
        const oppName = pvpRole === 'p1' ? pvpMatch.player2 : pvpMatch.player1;
        const winnerName = wonMatch
          ? userProfile.nickname
          : lostMatch
          ? oppName || 'Opponent'
          : 'DRAW';
        completePvPMatch(pvpMatch.id, winnerName);
      }

      const oldRP = userProfile.ratingRP;
      const newRP = Math.max(100, oldRP + rpDelta);
      const rawWinsProgress = wonMatch
        ? userProfile.winsProgress + 1
        : userProfile.winsProgress;
      const earnedBonusBooster = wonMatch && rawWinsProgress >= 3;
      const nextWinsProgress = earnedBonusBooster ? 0 : rawWinsProgress;

      updateProfile((prev) => ({
        ...prev,
        ratingRP: Math.max(100, prev.ratingRP + rpDelta),
        matchesWon: prev.matchesWon + (wonMatch ? 1 : 0),
        matchesLost: prev.matchesLost + (lostMatch ? 1 : 0),
        winStreak: wonMatch ? prev.winStreak + 1 : lostMatch ? 0 : prev.winStreak,
        winsProgress: nextWinsProgress,
        packsAvailable: prev.packsAvailable + (earnedBonusBooster ? 1 : 0),
      }));

      setPostBattleResult({
        oldRating: oldRP,
        newRating: newRP,
        playerScore: scores.player,
        enemyScore: scores.enemy,
        winsProgressAfter: nextWinsProgress,
        bonusPackEarned: earnedBonusBooster,
        deckCards: battleStartingDeck,
      });

      if (wonMatch) {
        Sound.victory();
        setStatusBannerText(t.matchVictoryStatus);
        confetti({ particleCount: 140, spread: 100, origin: { y: 0.45 } });
      } else if (lostMatch) {
        setStatusBannerText(t.matchDefeatStatus);
      } else {
        setStatusBannerText(t.matchDrawStatus);
      }
    }
  }, [
    userProfile,
    phase,
    arenaSubPhase,
    roundIndex,
    scores,
    pvpMatch,
    pvpRole,
    battleStartingDeck,
    updateProfile,
    t,
  ]);

  // Timer 0: 1.5-Second Centered "СЛЕДУЮЩИЙ РАУНД" Neon Banner Transition
  useEffect(() => {
    if (activeTab !== 'ARENA' || phase !== 'BATTLE' || arenaSubPhase !== 'NEXT_ROUND_BANNER') {
      return;
    }

    Sound.chime(1.12);
    const timer = window.setTimeout(() => {
      setPreCountdown(3);
      setArenaSubPhase('PRE_ROUND_COUNTDOWN');
    }, 1500);

    return () => window.clearTimeout(timer);
  }, [activeTab, phase, arenaSubPhase]);

  // Timer 1: Cinematic 3..2..1 Pre-Round Countdown
  useEffect(() => {
    if (activeTab !== 'ARENA' || phase !== 'BATTLE' || arenaSubPhase !== 'PRE_ROUND_COUNTDOWN') {
      return;
    }

    Sound.select();
    const timer = window.setTimeout(() => {
      if (preCountdown > 1) {
        setPreCountdown((prev) => prev - 1);
      } else {
        Sound.chime(1.18);
        setTurnTimeLeft(12);
        setArenaSubPhase('TURN_TIMER');
      }
    }, 950);

    return () => window.clearTimeout(timer);
  }, [activeTab, phase, arenaSubPhase, preCountdown]);

  // Timer 2: 12-Second Turn Timer (Auto-plays card at 0s)
  useEffect(() => {
    if (activeTab !== 'ARENA' || phase !== 'BATTLE' || arenaSubPhase !== 'TURN_TIMER') {
      return;
    }

    if (turnTimeLeft <= 0) {
      setStatusBannerText(t.autoMoveNotice);
      handlePlayCombatRound(0);
      return;
    }

    const timer = window.setTimeout(() => {
      setTurnTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => window.clearTimeout(timer);
  }, [activeTab, phase, arenaSubPhase, turnTimeLeft, handlePlayCombatRound, t]);

  // Timer 3: 10-Second Post-Clash Review Pause
  useEffect(() => {
    if (activeTab !== 'ARENA' || phase !== 'BATTLE' || arenaSubPhase !== 'ROUND_RESULT_PAUSE') {
      return;
    }

    if (resultPauseLeft <= 0) {
      advanceAfterRoundPause();
      return;
    }

    const timer = window.setTimeout(() => {
      setResultPauseLeft((prev) => prev - 1);
    }, 1000);

    return () => window.clearTimeout(timer);
  }, [activeTab, phase, arenaSubPhase, resultPauseLeft, advanceAfterRoundPause]);

  const swipeRef = useRef<{ active: boolean; startX: number; startY: number }>({
    active: false,
    startX: 0,
    startY: 0,
  });

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (catalogOpen || !userProfile || postBattleResult) return;
    if (
      activeTab === 'BOOSTERS' &&
      phase === 'PACK_IDLE' &&
      !packTorn &&
      userProfile.packsAvailable > 0
    ) {
      if ((e.target as HTMLElement).closest('button, header, nav, input')) return;
      Sound.init();
      swipeRef.current = { active: true, startX: e.clientX, startY: e.clientY };
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!swipeRef.current.active || packTorn) return;
    const dx = Math.abs(e.clientX - swipeRef.current.startX);
    sceneCtrlRef.current?.setPackCutTension(dx / 135);
    setLaserLine({
      visible: true,
      left: Math.min(swipeRef.current.startX, e.clientX),
      top: swipeRef.current.startY - 2,
      width: dx,
    });

    if (dx > 135) {
      swipeRef.current.active = false;
      setLaserLine({ visible: false, left: 0, top: 0, width: 0 });
      handleTearPack();
    }
  };

  const handlePointerUp = () => {
    if (swipeRef.current.active) {
      swipeRef.current.active = false;
      sceneCtrlRef.current?.setPackCutTension(0);
      setLaserLine({ visible: false, left: 0, top: 0, width: 0 });
    }
  };

  const toggleMute = () => {
    Sound.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const activeRoundModifier = roundModifiers[roundIndex - 1] || ROUND_MODIFIER_SPECS[0];
  const activeModifierCopy = getModifierCopy(activeRoundModifier.type);

  const derivedPlayerStats: PlayerStats = {
    packsOpened: userProfile?.packsOpened || 0,
    matchesWon: userProfile?.matchesWon || 0,
    matchesLost: userProfile?.matchesLost || 0,
    winStreak: userProfile?.winStreak || 0,
    mevRating: userProfile?.ratingRP || 1000,
  };

  const leaderboardEntries = getLeaderboardEntries(userProfile, remoteLeaderboard);

  const opponentDisplayName =
    pvpMatch && pvpRole
      ? (pvpRole === 'p1' ? pvpMatch.player2 : pvpMatch.player1) || t.opponentLabel
      : t.opponentLabel;

  return (
    <div
      className="relative w-full h-[100dvh] max-h-[100dvh] overflow-hidden bg-[#030306] select-none"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* Hidden Avatar Upload Input */}
      <input
        ref={avatarInputRef}
        type="file"
        accept="image/*"
        onChange={handleAvatarUpload}
        className="hidden"
      />

      {/* 1. Dedicated 3D WebGL Canvas Mount */}
      <div ref={canvasMountRef} className="absolute inset-0 z-0" />

      {/* 2. Laser Tear Line Overlay */}
      {laserLine.visible && (
        <div
          className="fixed z-40 pointer-events-none h-[3px] bg-white"
          style={{
            left: `${laserLine.left}px`,
            top: `${laserLine.top}px`,
            width: `${laserLine.width}px`,
            boxShadow: '0 0 18px rgba(255,255,255,0.9), 0 0 32px rgba(203,213,225,0.7)',
          }}
        />
      )}

      {/* 3. Login Modal if not authenticated */}
      {!userProfile && (
        <LoginScreenModal
          lang={lang}
          onChangeLang={handleChangeLang}
          onLoginSuccess={handleLogin}
        />
      )}

      {/* 4. Top Hub Bar (Brand "Turbo-Charging" + Player Info + Economy Timers + Language Selector [ RU ] [ EN ] [ KO ] [ VI ]) */}
      {userProfile && (
        <header className="relative z-20 flex flex-wrap items-center justify-between gap-2 sm:gap-4 px-3 sm:px-6 py-2.5 sm:py-3 panel-silver-chrome border-t-0 border-x-0">
          {/* Left: Brand Logo "Turbo-Charging" + Clickable Player Avatar, Nickname, ★ RP */}
          <div className="flex items-center gap-2.5 sm:gap-4 min-w-0">
            <button
              type="button"
              onClick={() => handleSelectTab('BOOSTERS')}
              className="text-sm sm:text-lg font-black tracking-[1.5px] text-white whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.brandLogo}
            </button>

            <span className="text-white/25 hidden sm:inline">|</span>

            <div className="flex items-center gap-2.5 min-w-0">
              <button
                type="button"
                onClick={() => avatarInputRef.current?.click()}
                className="relative group w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden border border-white/40 bg-black/40 cursor-pointer shrink-0"
                title={t.uploadAvatarHint}
              >
                <img
                  src={userProfile.avatarUrl}
                  alt={userProfile.nickname}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <Camera className="w-3.5 h-3.5 text-white" />
                </div>
              </button>

              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="text-xs sm:text-sm font-black tracking-[0.8px] text-white uppercase truncate max-w-[95px] sm:max-w-[140px]">
                    {userProfile.nickname}
                  </span>
                  <span className="px-2 py-0.5 rounded-lg card-slot-silver-active text-[11px] font-black text-white whitespace-nowrap">
                    ★ {formatRatingRP(userProfile.ratingRP)} RP
                  </span>
                </div>
                <div className="text-[10px] sm:text-[11px] text-slate-300 flex items-center gap-1.5 whitespace-nowrap">
                  <span>{getRankTitle(userProfile.ratingRP)}</span>
                  <span>•</span>
                  <span>
                    {t.collectionCount}: {userProfile.collection.length}/103
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Center: Economy Timers (12h Pack Countdown + Wins Progress X/3) */}
          <div className="hidden xl:flex items-center justify-center gap-2.5">
            <div className="card-slot-silver px-3.5 py-1.5 rounded-xl text-xs text-slate-200 flex items-center gap-2">
              <span className="text-slate-300">{t.nextFreePackIn}</span>
              <span className="font-black text-white tracking-wider">
                {formatCountdownHMS(msUntilNextPack)}
              </span>
            </div>

            <div className="card-slot-silver px-3.5 py-1.5 rounded-xl text-xs text-slate-200 flex items-center gap-2">
              <span className="text-slate-300">{t.winsToBonusBooster}</span>
              <span className="font-black text-white">{userProfile.winsProgress}/3</span>
            </div>
          </div>

          {/* Right: Language Selector [ RU ] [ EN ] [ KO ] [ VI ] + Quick Tools */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <div className="flex items-center gap-1 bg-black/45 p-1 rounded-xl border border-white/25">
              {(['RU', 'EN', 'KO', 'VI'] as LanguageCode[]).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => handleChangeLang(code)}
                  className={`px-2 sm:px-2.5 py-1 rounded-lg text-[10px] sm:text-[11px] font-black uppercase transition-all cursor-pointer ${
                    lang === code
                      ? 'btn-liquid-silver'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {code}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                Sound.select();
                setRulesOpen(true);
              }}
              className="card-slot-silver px-2.5 sm:px-3.5 py-2 rounded-xl text-xs font-black text-white hover:border-white/70 flex items-center gap-1.5 cursor-pointer transition-all"
              title={t.rulesBtnLabel}
            >
              <span>{t.rulesBtnLabel}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setInspectedCard(null);
                setCatalogOpen(true);
              }}
              className="card-slot-silver px-2.5 sm:px-3 py-2 rounded-xl text-xs text-slate-200 hover:text-white flex items-center gap-1.5 cursor-pointer"
              title={t.catalogBtn}
            >
              <Layers className="w-3.5 h-3.5 text-white" />
              <span className="hidden md:inline">
                {t.catalogBtn} ({cardsDb.length})
              </span>
            </button>

            <button
              type="button"
              onClick={toggleMute}
              className="card-slot-silver p-2 rounded-xl text-slate-200 hover:text-white cursor-pointer"
              title={isMuted ? t.unmuteTooltip : t.muteTooltip}
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-slate-400" />
              ) : (
                <Volume2 className="w-4 h-4 text-white" />
              )}
            </button>

            <button
              type="button"
              onClick={handleLogout}
              className="card-slot-silver p-2 rounded-xl text-slate-200 hover:text-white cursor-pointer"
              title={t.logoutTooltip}
            >
              <LogOut className="w-4 h-4 text-white" />
            </button>
          </div>
        </header>
      )}

      {/* Sub-header Economy Timers for Mobile / Tablet */}
      {userProfile && activeTab === 'BOOSTERS' && (
        <div className="xl:hidden relative z-10 flex flex-wrap items-center justify-center gap-2 px-3 pt-2 pointer-events-none">
          <div className="card-slot-silver px-3 py-1 rounded-xl text-[11px] text-slate-200 flex items-center gap-1.5">
            <span className="text-slate-300">{t.nextFreePackIn}</span>
            <span className="font-black text-white">{formatCountdownHMS(msUntilNextPack)}</span>
          </div>
          <div className="card-slot-silver px-3 py-1 rounded-xl text-[11px] text-slate-200 flex items-center gap-1.5">
            <span className="text-slate-300">{t.winsToBonusBooster}</span>
            <span className="font-black text-white">{userProfile.winsProgress}/3</span>
          </div>
        </div>
      )}

      {/* 5A. ARENA Mode Selection & Online PvP Matchmaking Modal */}
      {userProfile && activeTab === 'ARENA' && phase === 'ARENA_MODE_SELECT' && (
        <BattleModeSelectView
          lang={lang}
          subState={matchmakingSubState}
          quickSearchSecondsLeft={quickSearchSecondsLeft}
          createdRoomCode={createdRoomCode}
          codeError={codeError}
          isBusy={isMatchmakingBusy}
          onStartQuickMatch={handleStartQuickMatch}
          onCreateLobby={handleCreateLobby}
          onOpenEnterCode={() => {
            Sound.select();
            setCodeError(null);
            setMatchmakingSubState('ENTER_CODE_FORM');
          }}
          onSubmitJoinCode={handleSubmitJoinCode}
          onStartAiTraining={launchAiBattle}
          onCancelMatchmaking={handleCancelMatchmaking}
          onOpenRules={() => {
            Sound.select();
            setRulesOpen(true);
          }}
        />
      )}

      {/* 5B. Compact Semi-Transparent Top-Center Battle Scoreboard & Arbitrage Log (Never overlaps 3D cards) */}
      {userProfile &&
        activeTab === 'ARENA' &&
        (phase === 'BATTLE' || phase === 'GAME_OVER') && (
          <div className="relative z-10 pointer-events-none flex flex-col items-center justify-center pt-1 px-2 gap-1 w-full">
            <div className="pointer-events-auto grid grid-cols-[1fr_auto_1fr] items-center bg-black/55 backdrop-blur-md border border-white/25 px-4 sm:px-6 py-1.5 rounded-2xl shadow-lg w-full max-w-[540px]">
              <div className="flex items-center justify-end gap-2 pr-2 sm:pr-4">
                <span className="text-[11px] sm:text-xs font-black tracking-[1.4px] text-slate-300 uppercase">
                  {t.youLabel}
                </span>
                <span className="text-lg sm:text-2xl score-platinum leading-none">
                  {scores.player}
                </span>
              </div>

              <div className="flex items-center justify-center gap-2 sm:gap-3">
                <span className="text-slate-400 text-xs" aria-hidden="true">
                  •
                </span>
                <div className="text-[11px] sm:text-xs font-black tracking-[1.4px] text-slate-200 uppercase text-center whitespace-nowrap">
                  {phase === 'GAME_OVER' ? t.matchFinalLabel : t.roundCounter(roundIndex)}
                </div>
                <span className="text-slate-400 text-xs" aria-hidden="true">
                  •
                </span>
              </div>

              <div className="flex items-center justify-start gap-2 pl-2 sm:pl-4">
                <span className="text-lg sm:text-2xl score-platinum leading-none">
                  {scores.enemy}
                </span>
                <span className="text-[11px] sm:text-xs font-black tracking-[1.4px] text-slate-300 uppercase truncate max-w-[100px] sm:max-w-[150px]">
                  {opponentDisplayName}
                </span>
              </div>
            </div>

            {phase === 'BATTLE' && (
              <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-2">
                <div className="flex flex-wrap items-center justify-center gap-1.5 bg-black/45 backdrop-blur-md border border-white/20 px-3 py-1 rounded-xl text-[10px] sm:text-[11px] text-slate-200 max-w-[82vw] text-center">
                  <ShieldAlert className="w-3 h-3 text-white shrink-0" />
                  <span className="font-black text-white uppercase">{activeModifierCopy.title}:</span>
                  <span className="text-slate-300">{activeModifierCopy.ruleText}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    Sound.select();
                    setRulesOpen(true);
                  }}
                  className="card-slot-silver px-2.5 py-1 rounded-xl text-[10px] sm:text-[11px] font-black text-white hover:border-white/70 cursor-pointer transition-all"
                >
                  {t.rulesBtnLabel}
                </button>
              </div>
            )}

            {roundHistory.length > 0 && (
              <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-1.5 bg-black/45 backdrop-blur-md border border-white/15 px-3 py-0.5 rounded-xl text-[10px] sm:text-[11px] max-w-[92vw] text-center">
                {(() => {
                  const last = roundHistory[roundHistory.length - 1];
                  return (
                    <>
                      <span className="text-white font-black">
                        {t.youLabel}: {last.playerCard.name} (★{last.playerEffectivePower} •{' '}
                        {last.playerCard.latency}ms)
                      </span>
                      <span className="text-slate-400">•</span>
                      <span className="text-slate-200 font-black">
                        {opponentDisplayName}: {last.enemyCard.name} (★{last.enemyEffectivePower} •{' '}
                        {last.enemyCard.latency}ms)
                      </span>
                      <span className="text-slate-300 hidden md:inline">
                        — {formatHistoryReason(last)}
                      </span>
                    </>
                  );
                })()}
              </div>
            )}
          </div>
        )}

      {/* 5C-0. 1.5-Second Centered "СЛЕДУЮЩИЙ РАУНД" Banner over Dark Semi-Transparent Neon */}
      {userProfile &&
        activeTab === 'ARENA' &&
        phase === 'BATTLE' &&
        arenaSubPhase === 'NEXT_ROUND_BANNER' && (
          <div className="fixed inset-0 z-30 pointer-events-none flex items-center justify-center p-4">
            <div
              className="px-8 sm:px-14 py-5 sm:py-7 rounded-3xl bg-black/80 backdrop-blur-xl border border-white/45 flex flex-col items-center justify-center gap-1.5 text-center animate-countdown-pulse"
              style={{
                boxShadow:
                  '0 0 60px rgba(0, 240, 255, 0.32), 0 0 90px rgba(255, 139, 243, 0.22), inset 0 0 28px rgba(255, 255, 255, 0.18)',
              }}
            >
              <span className="text-xs sm:text-sm font-black tracking-[3px] text-slate-300 uppercase">
                {t.roundCounter(roundIndex)}
              </span>
              <div className="text-3xl sm:text-5xl font-black tracking-[3px] text-white score-platinum uppercase">
                {t.nextRoundBannerText}
              </div>
            </div>
          </div>
        )}

      {/* 5C. Cinematic Center Screen Countdown ("3" ... "2" ... "1") before each round */}
      {userProfile &&
        activeTab === 'ARENA' &&
        phase === 'BATTLE' &&
        arenaSubPhase === 'PRE_ROUND_COUNTDOWN' && (
          <div className="fixed inset-0 z-30 pointer-events-none flex flex-col items-center justify-center gap-2">
            <span className="px-4 py-1 rounded-full bg-black/65 backdrop-blur-md border border-white/30 text-xs font-black tracking-[2px] text-slate-200 uppercase">
              {t.roundCounter(roundIndex)} • {t.countdownReadyLabel}
            </span>
            <div
              key={preCountdown}
              className="text-8xl sm:text-9xl font-black text-white score-platinum animate-countdown-pulse"
            >
              {preCountdown}
            </div>
          </div>
        )}

      {/* 6. BOOSTERS Tab Center/Lower Controls (Strict Hub Flow — Never redirects to Arena) */}
      {userProfile && activeTab === 'BOOSTERS' && (
        <div
          className="fixed bottom-18 sm:bottom-20 inset-x-0 mx-auto z-20 w-[94vw] max-w-[920px] flex flex-col items-center justify-center gap-3 pointer-events-auto"
          style={{ margin: '0 auto' }}
        >
          {phase === 'PACK_IDLE' && !packTorn && (
            <div className="panel-silver-chrome rounded-2xl px-5 py-3.5 sm:px-6 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-3.5 w-full max-w-xl">
              <div className="flex flex-col text-center sm:text-left gap-0.5">
                <span className="text-xs font-black tracking-[1.2px] text-white uppercase">
                  {t.boosterPedestalTitle}
                </span>
                <span className="text-[11px] text-slate-300">
                  {userProfile.packsAvailable > 0
                    ? t.boosterSwipeOrClickHint
                    : `${t.nextFreePackIn} ${formatCountdownHMS(msUntilNextPack)}`}
                </span>
              </div>

              {userProfile.packsAvailable > 0 ? (
                <button
                  type="button"
                  onClick={handleTearPack}
                  className="btn-liquid-silver px-6 py-3 rounded-xl text-xs sm:text-sm uppercase flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 w-full sm:w-auto justify-center"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{t.openPackBtn(userProfile.packsAvailable)}</span>
                </button>
              ) : (
                <button
                  type="button"
                  disabled
                  className="card-slot-silver opacity-60 px-5 py-3 rounded-xl text-xs text-slate-300 uppercase cursor-not-allowed whitespace-nowrap shrink-0 w-full sm:w-auto text-center"
                >
                  {t.noPacksAvailableBtn(formatCountdownHMS(msUntilNextPack))}
                </button>
              )}
            </div>
          )}

          {phase === 'PACK_OPENED' && currentPackCards.length > 0 && (
            <div className="w-full panel-silver-chrome rounded-2xl p-3.5 sm:p-4 flex flex-col items-center justify-center gap-3">
              <div className="w-full flex flex-wrap items-center justify-between gap-2 border-b border-white/15 pb-2.5">
                <span className="text-[11px] sm:text-xs font-black tracking-[1.1px] text-white uppercase">
                  {flippedIndices.length === 3 ? t.allCardsAddedPrompt : t.packTornPrompt}
                </span>

                <div className="flex items-center gap-2">
                  {flippedIndices.length < 3 ? (
                    <button
                      type="button"
                      onClick={handleFlipAllPackCards}
                      className="btn-liquid-silver px-4 py-2 rounded-xl text-xs uppercase flex items-center gap-1.5 cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>{t.openAll3Btn}</span>
                    </button>
                  ) : (
                    <>
                      {userProfile.packsAvailable > 0 ? (
                        <button
                          type="button"
                          onClick={handlePrepareNextBooster}
                          className="btn-liquid-silver px-4 py-2 rounded-xl text-xs uppercase flex items-center gap-1.5 cursor-pointer"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>{t.openNextPackBtn(userProfile.packsAvailable)}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={handlePrepareNextBooster}
                          className="btn-liquid-silver px-4 py-2 rounded-xl text-xs uppercase cursor-pointer"
                        >
                          {t.backToPedestalBtn}
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>

              <div className="w-full grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3 justify-items-center">
                {currentPackCards.map((card, idx) => {
                  const isFlipped = flippedIndices.includes(idx);
                  return (
                    <div
                      key={card.id}
                      onClick={() => handleFlipPackCard(idx)}
                      className={`w-full p-2.5 rounded-xl text-left transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isFlipped
                          ? 'card-slot-silver-active'
                          : 'card-slot-silver hover:border-white/55'
                      }`}
                    >
                      {isFlipped ? (
                        <>
                          <div className="w-11 shrink-0 rounded-md overflow-hidden border border-white/25">
                            <CardCanvasPreview card={card} version={customPngCount} />
                          </div>
                          <div className="flex flex-col gap-0.5 min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-1">
                              <span className="font-black text-xs text-white truncate">
                                {card.name}
                              </span>
                              <span className="text-xs font-black text-white shrink-0">
                                ★ {card.power}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-300">
                              {card.latency}ms • {card.speedBoost}x • +{card.bidUplift}%
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setInspectedCard(card);
                              setCatalogOpen(true);
                            }}
                            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white shrink-0"
                            title={t.inspectCardTooltip}
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <div className="w-full flex items-center justify-between py-2 px-1">
                          <span className="text-xs text-slate-300 uppercase tracking-wider">
                            {t.slotHiddenLabel(idx + 1)}
                          </span>
                          <span className="text-xs font-black text-white uppercase tracking-wider">
                            {t.revealCardBtn}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 7. MY DECK Tab View */}
      {userProfile && activeTab === 'DECK' && (
        <MyDeckView
          lang={lang}
          allCards={cardsDb}
          collectionIds={userProfile.collection}
          battleDeckIds={userProfile.battleDeck}
          customPngCount={customPngCount}
          onToggleDeckCard={handleToggleDeckCard}
          onAutoPickBest={handleAutoPickBestDeck}
          onInspectCard={(card) => {
            setInspectedCard(card);
            setCatalogOpen(true);
          }}
          onOpenFullCatalog={() => {
            setInspectedCard(null);
            setCatalogOpen(true);
          }}
          onGoToBoosters={() => handleSelectTab('BOOSTERS')}
        />
      )}

      {/* 8. Compact Semi-Transparent ARENA Tab Combat Hand Dock (Positioned lower so it never overlaps central 3D duel cards) */}
      {userProfile && activeTab === 'ARENA' && phase === 'BATTLE' && (
        <div
          className="fixed bottom-14 sm:bottom-15 inset-x-0 mx-auto z-20 w-[94vw] max-w-[780px] flex flex-col items-center justify-center pointer-events-auto"
          style={{ margin: '0 auto' }}
        >
          <div className="w-full bg-black/60 backdrop-blur-md border border-white/25 rounded-2xl px-3 py-2 flex flex-col items-center justify-center gap-1.5 shadow-xl">
            {/* Compact Header & Active Combat Timers */}
            <div className="w-full flex flex-wrap items-center justify-between gap-2 border-b border-white/15 pb-1">
              <span className="text-[10px] sm:text-[11px] font-black tracking-[1px] text-white uppercase truncate">
                {arenaSubPhase === 'WAITING_OPPONENT_MOVE'
                  ? t.waitingForOpponentMove
                  : arenaSubPhase === 'ROUND_RESULT_PAUSE' && statusBannerText
                  ? statusBannerText
                  : t.chooseCardPrompt(roundIndex, activeModifierCopy.title)}
              </span>

              {arenaSubPhase === 'TURN_TIMER' && (
                <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg card-slot-silver-active text-[11px] font-black text-white">
                  <Clock className="w-3 h-3 text-white" />
                  <span>{t.turnTimerLabel(turnTimeLeft)}</span>
                </div>
              )}

              {arenaSubPhase === 'WAITING_OPPONENT_MOVE' && (
                <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg card-slot-silver-active text-[11px] font-black text-white">
                  <Loader2 className="w-3 h-3 text-white animate-spin" />
                  <span>PVP SYNC</span>
                </div>
              )}

              {arenaSubPhase === 'ROUND_RESULT_PAUSE' && (
                <div className="flex items-center gap-1.5">
                  <div className="px-2.5 py-0.5 rounded-lg card-slot-silver text-[11px] font-black text-white flex items-center gap-1">
                    <Clock className="w-3 h-3 text-white" />
                    <span>{t.roundReviewPauseLabel(resultPauseLeft)}</span>
                  </div>
                  <button
                    type="button"
                    onClick={advanceAfterRoundPause}
                    className="btn-liquid-silver px-3 py-0.5 rounded-lg text-[11px] uppercase cursor-pointer"
                  >
                    {t.nextRoundNowBtn}
                  </button>
                </div>
              )}
            </div>

            {battleHand.length > 0 && (
              <div className="w-full grid grid-cols-1 sm:grid-cols-3 gap-2 justify-items-center">
                {battleHand.map((card, idx) => {
                  const hasModBonus = activeRoundModifier.checkBonus(card);
                  const canPlayCard = arenaSubPhase === 'TURN_TIMER';
                  return (
                    <button
                      key={card.id}
                      disabled={!canPlayCard}
                      onClick={() => handlePlayCombatRound(idx)}
                      className={`w-full p-1.5 sm:p-2 rounded-xl transition-all text-left cursor-pointer disabled:opacity-50 flex items-center gap-2.5 hover:-translate-y-0.5 ${
                        hasModBonus
                          ? 'card-slot-silver-active'
                          : 'bg-white/10 border border-white/25 hover:border-white/60'
                      }`}
                    >
                      <div className="w-8 sm:w-9 shrink-0 rounded overflow-hidden border border-white/25">
                        <CardCanvasPreview card={card} version={customPngCount} />
                      </div>
                      <div className="flex flex-col justify-between gap-0.5 min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-black text-[11px] sm:text-xs text-white truncate">
                            {card.name}
                          </span>
                          <span className="text-[11px] font-black text-white shrink-0">
                            ★ {card.power}
                            {hasModBonus ? ' (+2)' : ''}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-slate-300">
                          <span>
                            {card.latency}ms • {card.speedBoost}x
                          </span>
                          <span className="text-white font-black shrink-0 uppercase">
                            {t.playCardAction}
                          </span>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 9. RANKING / LEADERBOARD Tab View */}
      {userProfile && activeTab === 'LEADERBOARD' && (
        <LeaderboardView lang={lang} entries={leaderboardEntries} />
      )}

      {/* 10. Bottom Hub Tab Bar (Pokemon TCG Style - Silver Chrome & Lato Bold, Clean Text) */}
      {userProfile && (
        <nav
          className="fixed bottom-2.5 sm:bottom-3 inset-x-0 mx-auto z-30 w-[95vw] max-w-[840px] panel-silver-chrome rounded-2xl p-1.5 grid grid-cols-4 gap-1.5 sm:gap-2"
          style={{ margin: '0 auto' }}
        >
          <button
            type="button"
            onClick={() => handleSelectTab('BOOSTERS')}
            className={`py-2.5 px-1.5 sm:px-3 rounded-xl text-[10px] sm:text-xs uppercase transition-all cursor-pointer flex items-center justify-center text-center leading-tight ${
              activeTab === 'BOOSTERS'
                ? 'btn-liquid-silver'
                : 'card-slot-silver text-slate-200 hover:text-white'
            }`}
          >
            <span>
              {t.tabBoosters} ({userProfile.packsAvailable})
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectTab('DECK')}
            className={`py-2.5 px-1.5 sm:px-3 rounded-xl text-[10px] sm:text-xs uppercase transition-all cursor-pointer flex items-center justify-center text-center leading-tight ${
              activeTab === 'DECK'
                ? 'btn-liquid-silver'
                : 'card-slot-silver text-slate-200 hover:text-white'
            }`}
          >
            <span>
              {t.tabMyDeck} ({userProfile.battleDeck.length}/3)
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectTab('ARENA')}
            className={`py-2.5 px-1.5 sm:px-3 rounded-xl text-[10px] sm:text-xs uppercase transition-all cursor-pointer flex items-center justify-center text-center leading-tight ${
              activeTab === 'ARENA'
                ? 'btn-liquid-silver'
                : 'card-slot-silver text-slate-200 hover:text-white'
            }`}
          >
            <span>{t.tabBattleArena}</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectTab('LEADERBOARD')}
            className={`py-2.5 px-1.5 sm:px-3 rounded-xl text-[10px] sm:text-xs uppercase transition-all cursor-pointer flex items-center justify-center text-center leading-tight ${
              activeTab === 'LEADERBOARD'
                ? 'btn-liquid-silver'
                : 'card-slot-silver text-slate-200 hover:text-white'
            }`}
          >
            <span>{t.tabRanking}</span>
          </button>
        </nav>
      )}

      {/* 11. Post-Battle Modal (End of Round 3) */}
      {userProfile && postBattleResult && (
        <PostBattleModal
          isOpen={true}
          lang={lang}
          profile={userProfile}
          oldRating={postBattleResult.oldRating}
          newRating={postBattleResult.newRating}
          playerScore={postBattleResult.playerScore}
          enemyScore={postBattleResult.enemyScore}
          winsProgressAfter={postBattleResult.winsProgressAfter}
          bonusPackEarned={postBattleResult.bonusPackEarned}
          deckCards={postBattleResult.deckCards}
          onReturnToHub={() => {
            setPostBattleResult(null);
            handleSelectTab('BOOSTERS');
          }}
        />
      )}

      {/* 12. Full 103-Card Database & Collection Inspector Modal */}
      <CardCatalogModal
        isOpen={catalogOpen}
        onClose={() => setCatalogOpen(false)}
        cards={cardsDb}
        discoveredIds={userProfile?.collection || []}
        playerStats={derivedPlayerStats}
        initialSelectedCard={inspectedCard}
        customPngCount={customPngCount}
        lang={lang}
      />

      {/* 13. Rules & Formula Modal */}
      <RulesFormulaModal
        isOpen={rulesOpen}
        lang={lang}
        onClose={() => {
          Sound.select();
          setRulesOpen(false);
        }}
      />
    </div>
  );
}
